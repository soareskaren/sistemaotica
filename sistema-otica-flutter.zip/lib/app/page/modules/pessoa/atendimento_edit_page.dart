import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:flutter_spinbox/flutter_spinbox.dart';
import 'package:otica/app/page/shared_widget/shared_widget_imports.dart';
import 'package:otica/app/controller/atendimento_controller.dart';
import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/page/shared_widget/input/input_imports.dart';
import 'package:supercharged/supercharged.dart';

class AtendimentoEditPage extends StatelessWidget {
	AtendimentoEditPage({Key? key}) : super(key: key);
	final atendimentoController = Get.find<AtendimentoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: atendimentoController.scaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('Atendimento - ${'editing'.tr}'),
					actions: [
            printButton(onPressed: atendimentoController.printAvaliacao),
						saveButton(onPressed: atendimentoController.save),
						cancelAndExitButton(onPressed: atendimentoController.preventDataLoss),
					]
				),				
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: atendimentoController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: atendimentoController.scrollController,
							child: SingleChildScrollView(
								controller: atendimentoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															controller: atendimentoController.talaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Talao',
																labelText: 'Talão',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																atendimentoController.atendimentoModel.talao = int.tryParse(text);
																atendimentoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Atendimento',
																labelText: 'Data Atendimento',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																dateTime: atendimentoController.atendimentoModel.dataAtendimento,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	atendimentoController.atendimentoModel.dataAtendimento = value;
																	atendimentoController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Retorno',
																labelText: 'Data Retorno',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																dateTime: atendimentoController.atendimentoModel.dataRetorno,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	atendimentoController.atendimentoModel.dataRetorno = value;
																	atendimentoController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: SpinBox( 
                              readOnly: false,
                              autofocus: true,
                              textStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 16.0
                              ),
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Esférico OD',
																labelText: 'Valor Esférico OD',
																usePadding: true,
															),                              
                              max: 20,
                              min: -20,
                              value: atendimentoController.valorEsfericoOdController.text.toDouble() ?? 0,
                              decimals: 2,
                              step: 0.25,
                              onChanged: (value) { 
																atendimentoController.atendimentoModel.valorEsfericoOd = value;
																atendimentoController.formWasChanged = true;
                              },
                            ),
													),
												),
												
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: SpinBox( 
                              readOnly: false,
                              autofocus: true,
                              textStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 16.0
                              ),
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Cilindrico OD',
																labelText: 'Valor Cilíndrico OD',
																usePadding: true,
															),                            
                              max: 0,
                              min: -20,
                              value: atendimentoController.valorCilindricoOdController.text.toDouble() ?? 0,
                              decimals: 2,
                              step: 0.25,
                              onChanged: (value) { 
																atendimentoController.atendimentoModel.valorCilindricoOd = value;
																atendimentoController.formWasChanged = true;
                              },
                            ),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: SpinBox( 
                              autofocus: true,
                              textStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 16.0
                              ),
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Posicao Eixo OD',
																labelText: 'Posição do Eixo OD',
																usePadding: true,
															),                           
                              max: 180,
                              min: 0,
                              value: atendimentoController.posicaoEixoOdController.text.toDouble() ?? 0,
                              decimals: 0,
                              step: 1,
                              onChanged: (value) { 
																atendimentoController.atendimentoModel.posicaoEixoOd = value.toInt();
																atendimentoController.formWasChanged = true;
                              },
                            ),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButtonFormField(
															value: atendimentoController.atendimentoModel.acuidadeVisualLongeOd ?? '20/20',
															labelText: 'Acuidade Visual Longe OD',
															hintText: 'Informe os dados para o campo Acuidade Visual Longe OD',
															items: const ['20/20','20/30','20/40','20/80','20/100','20/200','20/400'],
															onChanged: (dynamic newValue) {
																atendimentoController.atendimentoModel.acuidadeVisualLongeOd = newValue;
																atendimentoController.formWasChanged = true;
															},
														),
													),
												),
                        BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButtonFormField(
															value: atendimentoController.atendimentoModel.acuidadeVisualPertoOd ?? 'J1',
															labelText: 'Acuidade Visual Perto OD',
															hintText: 'Informe os dados para o campo Acuidade Visual Perto OD',
															items: const ['J1','J2','J3','J4','J5','J6'],
															onChanged: (dynamic newValue) {
																atendimentoController.atendimentoModel.acuidadeVisualPertoOd = newValue;
																atendimentoController.formWasChanged = true;
															},
														),
													),
												),
                      BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: atendimentoController.distanciaNasoPupilarOdController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Distancia Naso Pupilar OD',
																labelText: 'Distância Naso Pupilar OD',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																atendimentoController.atendimentoModel.distanciaNasoPupilarOd = atendimentoController.distanciaNasoPupilarOdController.numberValue;
																atendimentoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
                        BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: SpinBox( 
                              readOnly: false,
                              autofocus: true,
                              textStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 16.0
                              ),
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Esférico OE',
																labelText: 'Valor Esférico OE',
																usePadding: true,
															),                               
                              max: 20,
                              min: -20,
                              value: atendimentoController.valorEsfericoOeController.text.toDouble() ?? 0,
                              decimals: 2,
                              step: 0.25,
                              onChanged: (value) { 
																atendimentoController.atendimentoModel.valorEsfericoOe = value;
																atendimentoController.formWasChanged = true;
                              },
                            ),
													),
												),
                        BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: SpinBox( 
                              readOnly: false,
                              autofocus: true,
                              textStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 16.0
                              ),
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Cilindrico OE',
																labelText: 'Valor Cilíndrico OE',
																usePadding: true,
															),                           
                              max: 0,
                              min: -20,
                              value: atendimentoController.valorCilindricoOeController.text.toDouble() ?? 0,
                              decimals: 2,
                              step: 0.25,
                              onChanged: (value) { 
																atendimentoController.atendimentoModel.valorCilindricoOe = value;
																atendimentoController.formWasChanged = true;
                              },
                            ),
													),
												),
                        BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: SpinBox( 
                              autofocus: true,
                              textStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 16.0
                              ),
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Posicao Eixo OE',
																labelText: 'Posição do Eixo OE',
																usePadding: true,
															),                          
                              max: 180,
                              min: 0,
                              value: atendimentoController.posicaoEixoOeController.text.toDouble() ?? 0,
                              decimals: 0,
                              step: 1,
                              onChanged: (value) { 
																atendimentoController.atendimentoModel.posicaoEixoOe = value.toInt();
																atendimentoController.formWasChanged = true;
                              },
                            ),
													),
												),
												
											BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButtonFormField(
															value: atendimentoController.atendimentoModel.acuidadeVisualLongeOe ?? '20/20',
															labelText: 'Acuidade Visual Longe OE',
															hintText: 'Informe os dados para o campo Acuidade Visual Longe OE',
															items: const ['20/20','20/30','20/40','20/80','20/100','20/200','20/400'],
															onChanged: (dynamic newValue) {
																atendimentoController.atendimentoModel.acuidadeVisualLongeOe = newValue;
																atendimentoController.formWasChanged = true;
															},
														),
													),
												),
                        BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButtonFormField(
															value: atendimentoController.atendimentoModel.acuidadeVisualPertoOe ?? 'J1',
															labelText: 'Acuidade Visual Perto OE',
															hintText: 'Informe os dados para o campo Acuidade Visual Perto OE',
															items: const ['J1','J2','J3','J4','J5','J6'],
															onChanged: (dynamic newValue) {
																atendimentoController.atendimentoModel.acuidadeVisualPertoOe = newValue;
																atendimentoController.formWasChanged = true;
															},
														),
													),
												),
                        BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: atendimentoController.distanciaNasoPupilarOeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Distancia Naso Pupilar OE',
																labelText: 'Distância Naso Pupilar OE',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																atendimentoController.atendimentoModel.distanciaNasoPupilarOe = atendimentoController.distanciaNasoPupilarOeController.numberValue;
																atendimentoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: SpinBox( 
                              readOnly: true,
                              autofocus: true,
                              textStyle: const TextStyle(
                                color: Colors.black,
                                fontSize: 16.0
                              ),
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Adicao',
																labelText: 'Adição',
																usePadding: true,
															),                       
                              max: 3.50,
                              min: 0.25,
                              value: atendimentoController.adicaoController.text.toDouble() ?? 0,
                              decimals: 2,
                              step: 0.25,
                              onChanged: (value) { 
																atendimentoController.atendimentoModel.adicao = value;
																atendimentoController.formWasChanged = true;
                              },
                            ),
													),
												),
												
												
                        
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: atendimentoController.examinadorController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Examinador',
																labelText: 'Examinador',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																atendimentoController.atendimentoModel.examinador = text;
																atendimentoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 500,
															maxLines: 5,
															controller: atendimentoController.observacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Observacao',
																labelText: 'Observação',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																atendimentoController.atendimentoModel.observacao = text;
																atendimentoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),                    
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
