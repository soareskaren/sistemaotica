import 'package:flutter/material.dart';
import 'package:otica/app/page/shared_widget/fade_animation.dart';

class LoginLabel extends StatelessWidget {
  final String label;
  const LoginLabel({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    return FadeAnimation(
      delay: 1,
      child: Text(
        label,
        style: const TextStyle(color: Colors.white, letterSpacing: 0.5),
      ),
    );
  }
}
