import 'package:flutter/material.dart';
import 'package:otica/app/infra/constants.dart';
import 'package:otica/app/page/shared_widget/fade_animation.dart';

class LoginImage extends StatelessWidget {
  const LoginImage({super.key});

  @override
  Widget build(BuildContext context) {
    return FadeAnimation(
      delay: 0.8,
      child: Image.asset(
        Constants.loginImage,
      ),
    );
  }
}
