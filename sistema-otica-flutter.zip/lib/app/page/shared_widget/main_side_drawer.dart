import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:otica/app/controller/theme_controller.dart';
import 'package:otica/app/controller/usuario_controller.dart';
import 'package:otica/app/infra/constants.dart';
import 'package:otica/app/page/shared_widget/message_dialog.dart';
import 'package:otica/app/routes/app_routes.dart';

class MainSideDrawer extends StatelessWidget {
  MainSideDrawer({Key? key}) : super(key: key);

  final usuarioController = Get.find<UsuarioController>();
  final themeController = Get.find<ThemeController>();

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          UserAccountsDrawerHeader(
            accountName: Text(
              usuarioController.usuario.nome ??
                  'name'.tr, 
            ),
            accountEmail: Text(
              usuarioController.usuario.login ??
                  'Email', 
            ),
            currentAccountPicture: MouseRegion(
              cursor: SystemMouseCursors.click,
              child: GestureDetector(
                onTap: (() {
                  showInfoSnackBar(message: 'drawer_message_change_image_profile'.tr);
                }),
                child: const CircleAvatar(
                  backgroundImage: AssetImage(Constants.profileImage),
                ),
              ),
            ),
          ),

          const Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child: Text(
              "Principal",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 10.0),
            ),
          ),

          ListTile(
            onTap: () {
              Get.toNamed(Routes.pessoaListPage);
            },            
            title: const Text(
              "Pessoa",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.person,
              color: Colors.blue,
            ),
          ),
          
          const Divider(),     

          const Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child: Text(
              "Produto",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 10.0),
            ),
          ),
          ListTile(
						onTap: () {
							Get.toNamed(Routes.vendaCabecalhoListPage);
						},            
            title: const Text(
              "Venda",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.point_of_sale_sharp,
              color: Colors.cyan,
            ),
          ),            
          ListTile(
						onTap: () {
							Get.toNamed(Routes.produtoListPage);
						},            
            title: const Text(
              "Produto",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.production_quantity_limits_sharp,
              color: Colors.red,
            ),
          ),
          ListTile(
						onTap: () {
							Get.toNamed(Routes.produtoMarcaListPage);
						},            
            title: const Text(
              "Marca",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.tag_rounded,
              color: Colors.green,
            ),
          ),  
          ListTile(
						onTap: () {
							Get.toNamed(Routes.produtoUnidadeListPage);
						},            
            title: const Text(
              "Unidade",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.ac_unit,
              color: Colors.amber,
            ),
          ),      
                         
          const Divider(),  

          const Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child: Text(
              "Financeiro",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 10.0),
            ),
          ),
          ListTile(
            onTap: () {
              Get.toNamed(Routes.bancoListPage);
            },
            title: const Text(
              "Banco",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.attach_money,
              color: Colors.blueGrey,
            ),
          ),
          ListTile(
            onTap: () {
              Get.toNamed(Routes.bancoAgenciaListPage);
            },            
            title: const Text(
              "Agencia",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.broadcast_on_personal_sharp,
              color: Colors.deepOrange,
            ),
          ),
          ListTile(
						onTap: () {
							Get.toNamed(Routes.bancoContaCaixaListPage);
						},            
            title: const Text(
              "Conta Caixa",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.money_sharp,
              color: Colors.indigo,
            ),
          ),
          ListTile(
            onTap: () {
							Get.toNamed(Routes.formaPagamentoListPage);
						},
            title: const Text(
              "Formas de Pagamento",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.money_off_csred,
              color: Colors.lightBlue,
            ),
          ),
          ListTile(
						onTap: () {
							Get.toNamed(Routes.contasReceberListPage);
						},            
            title: const Text(
              "Contas a Receber",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.clean_hands_outlined,
              color: Colors.lightGreen,
            ),
          ), 
          ListTile(
						onTap: () {
							Get.toNamed(Routes.contasPagarListPage);
						},            
            title: const Text(
              "Contas a Pagar",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.waving_hand_sharp,
              color: Colors.redAccent,
            ),
          ),                   
          const Divider(),     

          const Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child: Text(
              "Outros Cadastros",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 10.0),
            ),
          ),
          ListTile(
						onTap: () {
							Get.toNamed(Routes.empresaListPage);
						},            
            title: const Text(
              "Empresa",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.confirmation_number_sharp,
              color: Colors.teal,
            ),
          ),
          ListTile(
						onTap: () {
							Get.toNamed(Routes.usuarioListPage);
						},            
            title: const Text(
              "Usuário",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.supervised_user_circle_outlined,
              color: Colors.purple,
            ),
          ),          
          ListTile(
						onTap: () {
							Get.toNamed(Routes.nivelFormacaoListPage);
						},            
            title: const Text(
              "Nível Formação",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.school,
              color: Colors.grey,
            ),
          ),
          ListTile(
            onTap: () {
              Get.toNamed(Routes.estadoCivilListPage);
            },
            title: const Text(
              "Estado Civil",
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
            ),
            leading: const Icon(
              Icons.people_outline,
              color: Colors.brown,
            ),
          ),
        ],
      ),
    );
  }
}
