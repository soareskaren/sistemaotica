import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:otica/app/controller/controller_imports.dart';
import 'package:otica/app/infra/infra_imports.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import 'package:get/get.dart';
import 'package:pdf/widgets.dart' show PageOrientation;
import 'package:printing/printing.dart';
import 'package:otica/app/page/shared_widget/buttons.dart';

String title = '';

class ReportAvaliacaoOptometricaPage extends StatefulWidget {
  final String title;
  
  const ReportAvaliacaoOptometricaPage({Key? key, required this.title}) : super(key: key);

  @override
  ReportAvaliacaoOptometricaPageState createState() => ReportAvaliacaoOptometricaPageState();
}

class ReportAvaliacaoOptometricaPageState extends State<ReportAvaliacaoOptometricaPage> {
  @override
  Widget build(BuildContext context) {  
    title = widget.title;
    return SizedBox(
      width: Get.width,
      height: Get.height,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Text(title),
          actions: buttonsAppBar(),
        ),
        body: PdfPreview(  
          initialPageFormat: PdfPageFormat.a4.landscape,                  
          canChangeOrientation: true,
          build: (format) => generateReport(format),
        ),
      ),
    );
  }

  List<Widget> buttonsAppBar() {
    return <Widget>[
      exitButton(),    
      const SizedBox(
        height: 10,
        width: 5,
      )  
    ];
  }
}

Future<Uint8List> generateReport(PdfPageFormat pageFormat) async {
  final pessoaController = Get.find<PessoaController>();
  final atendimentoController = Get.find<AtendimentoController>();

  final pdf = pw.Document();

  final libreBaskerville = await PdfGoogleFonts.libreBaskervilleRegular();
  final libreBaskervilleItalic = await PdfGoogleFonts.libreBaskervilleItalic();
  final libreBaskervilleBold = await PdfGoogleFonts.libreBaskervilleBold();
  final robotoLight = await PdfGoogleFonts.robotoLight();
  final exameImage = pw.MemoryImage((await rootBundle.load('assets/images/exame-de-vista.jpg')).buffer.asUint8List(),);

  pw.Widget content() {
    return pw.Expanded(
      child: pw.Container(
        margin: const pw.EdgeInsets.all(5),
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColors.green, width: 5),
        ),
        width: double.infinity,
        height: double.infinity,
        child: pw.Column(
          children: [
            pw.Container(
              decoration: const pw.BoxDecoration(
                border: pw.Border(bottom: pw.BorderSide(color: PdfColors.black)),
              ),
              padding: const pw.EdgeInsets.only(top: 10, bottom: 2),
              child: pw.Text(
                'OPTOMETRIA',
                style: pw.TextStyle(
                  color: PdfColors.green,
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 35,
                ),
              ),
            ),                  
            pw.Padding(padding: const pw.EdgeInsets.fromLTRB(0, 5, 0, 0)),
            pw.Text(
              'A primeira barreira contra a cegueira evitável',
              style: pw.TextStyle(
                font: robotoLight,
                fontSize: 10,
                letterSpacing: 2,
                wordSpacing: 2,
              ),
            ),
            pw.Container(
              alignment: pw.Alignment.center,
              padding: const pw.EdgeInsets.only(top: 8),
              width: 300,
              child: pw.Image(exameImage),
            ),
            pw.Spacer(flex: 2),
            pw.RichText(
              text: pw.TextSpan(
                  style: pw.TextStyle(
                    fontWeight: pw.FontWeight.bold,
                    fontSize: 25,
                  ),
                  children: const [
                    pw.TextSpan(text: 'Avaliação Optométrica '),
                  ]),
            ),
            pw.Spacer(),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [                  
                pw.Container(
                  alignment: pw.Alignment.topLeft,
                  padding: const pw.EdgeInsets.only(bottom: 5, left: 10),
                  child: pw.Text(
                    'NOME: ${pessoaController.pessoaModel.nome}',
                    style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold,
                      fontSize: 10,
                    ),
                  ),
                ),
                pw.Container(
                  alignment: pw.Alignment.topLeft,
                  padding: const pw.EdgeInsets.only(bottom: 5, right: 10),
                  child: pw.Text(
                    'IDADE: ${Util.calcularIdade(pessoaController.pessoaModel.pessoaFisicaModel?.dataNascimento)}',
                    style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold,
                      fontSize: 10,
                    ),
                  ),
                ),                      
              ],
            ),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [                  
                pw.Container(
                  alignment: pw.Alignment.topLeft,
                  padding: const pw.EdgeInsets.only(bottom: 5, left: 10),
                  child: pw.Text(
                    'OCUPAÇÃO: ${pessoaController.pessoaModel.clienteModel?.ocupacao ?? ''}',
                    style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold,
                      fontSize: 10,
                    ),
                  ),
                ),
                pw.Container(
                  alignment: pw.Alignment.topLeft,
                  padding: const pw.EdgeInsets.only(bottom: 5, right: 10),
                  child: pw.Text(
                    'RETORNAR EM: ${Util.formatDate(atendimentoController.atendimentoModel.dataRetorno)}',
                    style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold,
                      fontSize: 10,
                    ),
                  ),
                ),                
              ],
            ),

            pw.Padding(
              padding: const pw.EdgeInsets.all(10),
              child: pw.Container(
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.green, width: 1),
                ),
                child: pw.Expanded(
                  child: pw.Row(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      
                      pw.Padding(
                        padding: const pw.EdgeInsets.only(top: 20, left: 3, right: 3),
                        child: pw.Transform.rotateBox(
                          angle: pi / 2,
                          child: pw.Text(
                            'Longe',
                            style: pw.TextStyle(
                              fontWeight: pw.FontWeight.bold,
                              fontSize: 10,
                            ),                        
                          ),
                        ),
                      ),
                      pw.Padding(
                        padding: const pw.EdgeInsets.all(0),
                        child: pw.Container(
                          width: 0,
                          height: 60,
                          decoration: pw.BoxDecoration(
                            border: pw.Border.all(color: PdfColors.green, width: 1),
                          ),
                        ),
                      ),  

                      pw.Padding(
                        padding: const pw.EdgeInsets.all(0),
                        child: pw.Column(
                          children: [
                            pw.Container(
                              width: 40,
                              height: 20,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                            ),
                            pw.Container(
                              width: 40,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  'O.D.',
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),
                            ),
                            pw.Container(
                              width: 40,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  'O.E.',
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),                              
                            ),
                          ],
                        ),
                      ),          

                      pw.Padding(
                        padding: const pw.EdgeInsets.all(0),
                        child: pw.Column(
                          children: [
                            pw.Container(
                              width: 50,
                              height: 20,
                              decoration: pw.BoxDecoration(
                                color: PdfColors.green,
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 5),
                                child: pw.Text(
                                  'ESF.',
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                    color: PdfColors.white
                                  ),
                                ),
                              ),                              
                            ),
                            pw.Container(
                              width: 50,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  atendimentoController.atendimentoModel.valorEsfericoOd! > 0 
                                  ? '+${atendimentoController.atendimentoModel.valorEsfericoOd!.toStringAsFixed(2)}'
                                  : atendimentoController.atendimentoModel.valorEsfericoOd!.toStringAsFixed(2),
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),
                            ),
                            pw.Container(
                              width: 50,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  atendimentoController.atendimentoModel.valorEsfericoOe! > 0 
                                  ? '+${atendimentoController.atendimentoModel.valorEsfericoOe!.toStringAsFixed(2)}'
                                  : atendimentoController.atendimentoModel.valorEsfericoOe!.toStringAsFixed(2),
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),                              
                            ),
                          ],
                        ),
                      ), 

                      pw.Padding(
                        padding: const pw.EdgeInsets.all(0),
                        child: pw.Column(
                          children: [
                            pw.Container(
                              width: 50,
                              height: 20,
                              decoration: pw.BoxDecoration(
                                color: PdfColors.green,
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 5),
                                child: pw.Text(
                                  'CIL.',
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                    color: PdfColors.white
                                  ),
                                ),
                              ),                              
                            ),
                            pw.Container(
                              width: 50,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  atendimentoController.atendimentoModel.valorCilindricoOd!.toStringAsFixed(2),
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),
                            ),
                            pw.Container(
                              width: 50,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  atendimentoController.atendimentoModel.valorCilindricoOe!.toStringAsFixed(2),
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),                              
                            ),
                          ],
                        ),
                      ), 

                      pw.Padding(
                        padding: const pw.EdgeInsets.all(0),
                        child: pw.Column(
                          children: [
                            pw.Container(
                              width: 50,
                              height: 20,
                              decoration: pw.BoxDecoration(
                                color: PdfColors.green,
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 5),
                                child: pw.Text(
                                  'EIXO',
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                    color: PdfColors.white
                                  ),
                                ),
                              ),                              
                            ),
                            pw.Container(
                              width: 50,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  atendimentoController.atendimentoModel.posicaoEixoOd.toString(),
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),
                            ),
                            pw.Container(
                              width: 50,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  atendimentoController.atendimentoModel.posicaoEixoOe.toString(),
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),                              
                            ),
                          ],
                        ),
                      ), 

                      pw.Padding(
                        padding: const pw.EdgeInsets.all(0),
                        child: pw.Column(
                          children: [
                            pw.Container(
                              width: 50,
                              height: 20,
                              decoration: pw.BoxDecoration(
                                color: PdfColors.green,
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 5),
                                child: pw.Text(
                                  'A.V.',
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                    color: PdfColors.white
                                  ),
                                ),
                              ),                              
                            ),
                            pw.Container(
                              width: 50,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  atendimentoController.atendimentoModel.acuidadeVisualLongeOd.toString(),
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),
                            ),
                            pw.Container(
                              width: 50,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  atendimentoController.atendimentoModel.acuidadeVisualLongeOe.toString(),
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),                              
                            ),
                          ],
                        ),
                      ),

                      pw.Padding(
                        padding: const pw.EdgeInsets.only(top: 23, left: 3, right: 3),
                        child: pw.Transform.rotateBox(
                          angle: pi / 2,
                          child: pw.Text(
                            'Perto',
                            style: pw.TextStyle(
                              fontWeight: pw.FontWeight.bold,
                              fontSize: 10,
                            ),                        
                          ),
                        ),
                      ),
                      pw.Padding(
                        padding: const pw.EdgeInsets.all(0),
                        child: pw.Container(
                          width: 0,
                          height: 60,
                          decoration: pw.BoxDecoration(
                            border: pw.Border.all(color: PdfColors.green, width: 1),
                          ),
                        ),
                      ),  

                      pw.Padding(
                        padding: const pw.EdgeInsets.all(0),
                        child: pw.Column(
                          children: [
                            pw.Container(
                              width: 50,
                              height: 20,
                              decoration: pw.BoxDecoration(
                                color: PdfColors.green,
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 5),
                                child: pw.Text(
                                  'Adição',
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                    color: PdfColors.white
                                  ),
                                ),
                              ),                              
                            ),
                            pw.Container(
                              width: 50,
                              height: 50,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 20),
                                child: pw.Text(
                                  atendimentoController.atendimentoModel.adicao!.toStringAsFixed(2),
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),                              
                            ),
                          ],
                        ),
                      ), 

                      pw.Padding(
                        padding: const pw.EdgeInsets.all(0),
                        child: pw.Column(
                          children: [
                            pw.Container(
                              width: 49,
                              height: 20,
                              decoration: pw.BoxDecoration(
                                color: PdfColors.green,
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 5),
                                child: pw.Text(
                                  'A.V.',
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                    color: PdfColors.white
                                  ),
                                ),
                              ),                              
                            ),
                            pw.Container(
                              width: 49,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  atendimentoController.atendimentoModel.acuidadeVisualPertoOd.toString(),
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),
                            ),
                            pw.Container(
                              width: 49,
                              height: 25,
                              decoration: pw.BoxDecoration(
                                border: pw.Border.all(color: PdfColors.green, width: 1),
                              ),
                              child: pw.Padding(
                                padding: const pw.EdgeInsets.only(top: 8),
                                child: pw.Text(
                                  atendimentoController.atendimentoModel.acuidadeVisualPertoOe.toString(),
                                  textAlign: pw.TextAlign.center,
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: 10,
                                  ),
                                ),
                              ),                              
                            ),
                          ],
                        ),
                      ), 
                    ],
                  ),
                ),
              ),
            ),

            pw.SizedBox(height: 20),

            pw.Container(
              alignment: pw.Alignment.topLeft,
              padding: const pw.EdgeInsets.only(bottom: 5, left: 10, right: 10),
              child: pw.Text(
                'OBSERVAÇÕES: ${atendimentoController.atendimentoModel.observacao}',
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 10,
                ),
                textAlign: pw.TextAlign.justify,
              ),
            ),

            pw.Container(
              alignment: pw.Alignment.topRight,
              padding: const pw.EdgeInsets.only(bottom: 5, right: 10, top: 5),
              child: pw.Text(
                Util.dataPorExtenso(DateTime.now()),
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  fontSize: 10,
                ),
              ),
            ),

            pw.SizedBox(height: 20),

            pw.Padding(
              padding: const pw.EdgeInsets.all(10),
              child: pw.Text(
                'IMPORTANTE: Nos primeiros dias de uso, o usuário poderá sentir tontura, dor de cabeça, desníveis, etc. '
                'As lentes progressivas ou bifocais exigem um maior período de adaptação e mais cuidado ao subir ou descer '
                'escadas.'
                '\n'
                'O Óptico-optometrista é o profissional NÃO-MÉDICO da área de saúde, responsável pela avaliação primária '
                'da saúde visual e ocular, estando apto a prescrever óculos, lentes de contatos ou terapias visuais, podendo '
                'ainda identificar alterações patológicas, encaminhando-as ao especialista para o tratamento adequado. '
                'Para o desempenho de seu trabalho, não utiliza qualquer medicamento ou técnica invasiva no corpo humano. \n'
                'A optometria foi instituída no Brasil em 1932 pelo Decreto-lei 20.931, e suas atribuições definidas pela '
                'portaria número 397 de 09/10/2002, editada pelo Ministério do Trabalho.',
                style: const pw.TextStyle(fontSize: 6),
                textAlign: pw.TextAlign.justify,
              ),
            ),

          ],
        ),
      ),
    );
  }

  pdf.addPage(
    pw.Page(
      build: (context) => pw.Row(
        children: [
          content(),
          pw.SizedBox(width: 10),
          content(),
        ],
      ),
      pageTheme: pw.PageTheme(
        margin: const pw.EdgeInsets.all(10),
        pageFormat: pageFormat,
        orientation: PageOrientation.landscape,
        theme: pw.ThemeData.withFont(
          base: libreBaskerville,
          italic: libreBaskervilleItalic,
          bold: libreBaskervilleBold,
        ),
      ),
    ),
  );

  return pdf.save();
}
