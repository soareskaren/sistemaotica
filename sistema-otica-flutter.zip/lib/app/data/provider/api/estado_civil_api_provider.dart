import 'dart:convert';
import 'package:otica/app/data/provider/api/api_provider_base.dart';
import 'package:otica/app/data/model/model_imports.dart';

class EstadoCivilApiProvider extends ApiProviderBase {

	Future<List<EstadoCivilModel>?> getList({Filter? filter}) async {
		List<EstadoCivilModel> estadoCivilModelList = [];

		try {
			handleFilter(filter, '/estado-civil/');
			
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse(url)!, headers: ApiProviderBase.headerRequisition);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var estadoCivilModelJson = json.decode(response.body) as List<dynamic>;
					for (var estadoCivilModel in estadoCivilModelJson) {
						estadoCivilModelList.add(EstadoCivilModel.fromJson(estadoCivilModel));
					}
					return estadoCivilModelList;
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<EstadoCivilModel?> getObject(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse('$endpoint/estado-civil/$pk')!, headers: ApiProviderBase.headerRequisition);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var estadoCivilModelJson = json.decode(response.body);
					return EstadoCivilModel.fromJson(estadoCivilModelJson);		 
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<EstadoCivilModel?>? insert(EstadoCivilModel estadoCivilModel) async {
		try {
			final response = await ApiProviderBase.httpClient.post(
				Uri.tryParse('$endpoint/estado-civil')!,
				headers: ApiProviderBase.headerRequisition,
				body: estadoCivilModel.objectEncodeJson(),
			);

			if (response.statusCode == 200 || response.statusCode == 201) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var estadoCivilModelJson = json.decode(response.body);
					return EstadoCivilModel.fromJson(estadoCivilModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<EstadoCivilModel?>? update(EstadoCivilModel estadoCivilModel) async {
		try {
			final response = await ApiProviderBase.httpClient.put(
				Uri.tryParse('$endpoint/estado-civil')!,
				headers: ApiProviderBase.headerRequisition,
				body: estadoCivilModel.objectEncodeJson(),
			);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var estadoCivilModelJson = json.decode(response.body);
					return EstadoCivilModel.fromJson(estadoCivilModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.delete(
				Uri.tryParse('$endpoint/estado-civil/$pk')!,
				headers: ApiProviderBase.headerRequisition,
			);

			if (response.statusCode == 200) {
				return true;
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	
}
