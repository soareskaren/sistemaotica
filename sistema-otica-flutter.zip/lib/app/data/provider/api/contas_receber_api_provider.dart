import 'dart:convert';
import 'package:otica/app/data/provider/api/api_provider_base.dart';
import 'package:otica/app/data/model/model_imports.dart';

class ContasReceberApiProvider extends ApiProviderBase {

	Future<List<ContasReceberModel>?> getList({Filter? filter}) async {
		List<ContasReceberModel> contasReceberModelList = [];

		try {
			handleFilter(filter, '/contas-receber/');
			
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse(url)!, headers: ApiProviderBase.headerRequisition);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var contasReceberModelJson = json.decode(response.body) as List<dynamic>;
					for (var contasReceberModel in contasReceberModelJson) {
						contasReceberModelList.add(ContasReceberModel.fromJson(contasReceberModel));
					}
					return contasReceberModelList;
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<ContasReceberModel?> getObject(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse('$endpoint/contas-receber/$pk')!, headers: ApiProviderBase.headerRequisition);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var contasReceberModelJson = json.decode(response.body);
					return ContasReceberModel.fromJson(contasReceberModelJson);		 
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ContasReceberModel?>? insert(ContasReceberModel contasReceberModel) async {
		try {
			final response = await ApiProviderBase.httpClient.post(
				Uri.tryParse('$endpoint/contas-receber')!,
				headers: ApiProviderBase.headerRequisition,
				body: contasReceberModel.objectEncodeJson(),
			);

			if (response.statusCode == 200 || response.statusCode == 201) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var contasReceberModelJson = json.decode(response.body);
					return ContasReceberModel.fromJson(contasReceberModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ContasReceberModel?>? update(ContasReceberModel contasReceberModel) async {
		try {
			final response = await ApiProviderBase.httpClient.put(
				Uri.tryParse('$endpoint/contas-receber')!,
				headers: ApiProviderBase.headerRequisition,
				body: contasReceberModel.objectEncodeJson(),
			);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var contasReceberModelJson = json.decode(response.body);
					return ContasReceberModel.fromJson(contasReceberModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.delete(
				Uri.tryParse('$endpoint/contas-receber/$pk')!,
				headers: ApiProviderBase.headerRequisition,
			);

			if (response.statusCode == 200) {
				return true;
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	
}
