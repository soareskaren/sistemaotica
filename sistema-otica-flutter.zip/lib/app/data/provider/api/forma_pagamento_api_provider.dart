import 'dart:convert';
import 'package:otica/app/data/provider/api/api_provider_base.dart';
import 'package:otica/app/data/model/model_imports.dart';

class FormaPagamentoApiProvider extends ApiProviderBase {

	Future<List<FormaPagamentoModel>?> getList({Filter? filter}) async {
		List<FormaPagamentoModel> formaPagamentoModelList = [];

		try {
			handleFilter(filter, '/forma-pagamento/');
			
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse(url)!, headers: ApiProviderBase.headerRequisition);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var formaPagamentoModelJson = json.decode(response.body) as List<dynamic>;
					for (var formaPagamentoModel in formaPagamentoModelJson) {
						formaPagamentoModelList.add(FormaPagamentoModel.fromJson(formaPagamentoModel));
					}
					return formaPagamentoModelList;
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<FormaPagamentoModel?> getObject(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse('$endpoint/forma-pagamento/$pk')!, headers: ApiProviderBase.headerRequisition);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var formaPagamentoModelJson = json.decode(response.body);
					return FormaPagamentoModel.fromJson(formaPagamentoModelJson);		 
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<FormaPagamentoModel?>? insert(FormaPagamentoModel formaPagamentoModel) async {
		try {
			final response = await ApiProviderBase.httpClient.post(
				Uri.tryParse('$endpoint/forma-pagamento')!,
				headers: ApiProviderBase.headerRequisition,
				body: formaPagamentoModel.objectEncodeJson(),
			);

			if (response.statusCode == 200 || response.statusCode == 201) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var formaPagamentoModelJson = json.decode(response.body);
					return FormaPagamentoModel.fromJson(formaPagamentoModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<FormaPagamentoModel?>? update(FormaPagamentoModel formaPagamentoModel) async {
		try {
			final response = await ApiProviderBase.httpClient.put(
				Uri.tryParse('$endpoint/forma-pagamento')!,
				headers: ApiProviderBase.headerRequisition,
				body: formaPagamentoModel.objectEncodeJson(),
			);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var formaPagamentoModelJson = json.decode(response.body);
					return FormaPagamentoModel.fromJson(formaPagamentoModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.delete(
				Uri.tryParse('$endpoint/forma-pagamento/$pk')!,
				headers: ApiProviderBase.headerRequisition,
			);

			if (response.statusCode == 200) {
				return true;
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	
}
