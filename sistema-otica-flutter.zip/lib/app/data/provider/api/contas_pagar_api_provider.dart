import 'dart:convert';
import 'package:otica/app/data/provider/api/api_provider_base.dart';
import 'package:otica/app/data/model/model_imports.dart';

class ContasPagarApiProvider extends ApiProviderBase {

	Future<List<ContasPagarModel>?> getList({Filter? filter}) async {
		List<ContasPagarModel> contasPagarModelList = [];

		try {
			handleFilter(filter, '/contas-pagar/');
			
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse(url)!, headers: ApiProviderBase.headerRequisition);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var contasPagarModelJson = json.decode(response.body) as List<dynamic>;
					for (var contasPagarModel in contasPagarModelJson) {
						contasPagarModelList.add(ContasPagarModel.fromJson(contasPagarModel));
					}
					return contasPagarModelList;
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<ContasPagarModel?> getObject(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse('$endpoint/contas-pagar/$pk')!, headers: ApiProviderBase.headerRequisition);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var contasPagarModelJson = json.decode(response.body);
					return ContasPagarModel.fromJson(contasPagarModelJson);		 
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ContasPagarModel?>? insert(ContasPagarModel contasPagarModel) async {
		try {
			final response = await ApiProviderBase.httpClient.post(
				Uri.tryParse('$endpoint/contas-pagar')!,
				headers: ApiProviderBase.headerRequisition,
				body: contasPagarModel.objectEncodeJson(),
			);

			if (response.statusCode == 200 || response.statusCode == 201) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var contasPagarModelJson = json.decode(response.body);
					return ContasPagarModel.fromJson(contasPagarModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ContasPagarModel?>? update(ContasPagarModel contasPagarModel) async {
		try {
			final response = await ApiProviderBase.httpClient.put(
				Uri.tryParse('$endpoint/contas-pagar')!,
				headers: ApiProviderBase.headerRequisition,
				body: contasPagarModel.objectEncodeJson(),
			);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var contasPagarModelJson = json.decode(response.body);
					return ContasPagarModel.fromJson(contasPagarModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.delete(
				Uri.tryParse('$endpoint/contas-pagar/$pk')!,
				headers: ApiProviderBase.headerRequisition,
			);

			if (response.statusCode == 200) {
				return true;
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	
}
