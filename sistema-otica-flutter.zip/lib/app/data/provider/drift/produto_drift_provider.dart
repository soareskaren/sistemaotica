import 'package:otica/app/data/provider/drift/database/database_imports.dart';
import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/data/provider/api/api_provider_base.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/model/model_imports.dart';

class ProdutoDriftProvider extends ApiProviderBase {

	Future<List<ProdutoModel>?> getList({Filter? filter}) async {
		List<ProdutoGrouped> produtoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				produtoDriftList = await Session.database.produtoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				produtoDriftList = await Session.database.produtoDao.getGroupedList(); 
			}
			if (produtoDriftList.isNotEmpty) {
				return toListModel(produtoDriftList);
			} else {
				return [];
			}			 
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<ProdutoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.produtoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ProdutoModel?>? insert(ProdutoModel produtoModel) async {
		try {
			final lastPk = await Session.database.produtoDao.insertObject(toDrift(produtoModel));
			produtoModel.id = lastPk;
			return produtoModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ProdutoModel?>? update(ProdutoModel produtoModel) async {
		try {
			await Session.database.produtoDao.updateObject(toDrift(produtoModel));
			return produtoModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.produtoDao.deleteObject(toDrift(ProdutoModel(id: pk)));
			return true;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<ProdutoModel> toListModel(List<ProdutoGrouped> produtoDriftList) {
		List<ProdutoModel> listModel = [];
		for (var produtoDrift in produtoDriftList) {
			listModel.add(toModel(produtoDrift)!);
		}
		return listModel;
	}	

	ProdutoModel? toModel(ProdutoGrouped? produtoDrift) {
		if (produtoDrift != null) {
			return ProdutoModel(
				id: produtoDrift.produto?.id,
				idProdutoMarca: produtoDrift.produto?.idProdutoMarca,
				idProdutoUnidade: produtoDrift.produto?.idProdutoUnidade,
				idPessoa: produtoDrift.produto?.idPessoa,
				nome: produtoDrift.produto?.nome,
				dataCadastro: produtoDrift.produto?.dataCadastro,
				descricao: produtoDrift.produto?.descricao,
				gtin: produtoDrift.produto?.gtin,
				codigoInterno: produtoDrift.produto?.codigoInterno,
				valorCompra: produtoDrift.produto?.valorCompra,
				valorVenda: produtoDrift.produto?.valorVenda,
				codigoNcm: produtoDrift.produto?.codigoNcm,
				estoqueMinimo: produtoDrift.produto?.estoqueMinimo,
				estoqueMaximo: produtoDrift.produto?.estoqueMaximo,
				quantidadeEstoque: produtoDrift.produto?.quantidadeEstoque,
				produtoUnidadeModel: ProdutoUnidadeModel(
					id: produtoDrift.produtoUnidade?.id,
					sigla: produtoDrift.produtoUnidade?.sigla,
					descricao: produtoDrift.produtoUnidade?.descricao,
				),
				produtoMarcaModel: ProdutoMarcaModel(
					id: produtoDrift.produtoMarca?.id,
					nome: produtoDrift.produtoMarca?.nome,
					descricao: produtoDrift.produtoMarca?.descricao,
				),
				pessoaModel: PessoaModel(
					id: produtoDrift.pessoa?.id,
					nome: produtoDrift.pessoa?.nome,
					tipo: produtoDrift.pessoa?.tipo,
					referencia: produtoDrift.pessoa?.referencia,
					email: produtoDrift.pessoa?.email,
					ehCliente: produtoDrift.pessoa?.ehCliente,
					ehFornecedor: produtoDrift.pessoa?.ehFornecedor,
					site: produtoDrift.pessoa?.site,
					observacao: produtoDrift.pessoa?.observacao,
				),
			);
		} else {
			return null;
		}
	}


	ProdutoGrouped toDrift(ProdutoModel produtoModel) {
		return ProdutoGrouped(
			produto: Produto(
				id: produtoModel.id,
				idProdutoMarca: produtoModel.idProdutoMarca,
				idProdutoUnidade: produtoModel.idProdutoUnidade,
				idPessoa: produtoModel.idPessoa,
				nome: produtoModel.nome,
				dataCadastro: produtoModel.dataCadastro,
				descricao: produtoModel.descricao,
				gtin: produtoModel.gtin,
				codigoInterno: produtoModel.codigoInterno,
				valorCompra: produtoModel.valorCompra,
				valorVenda: produtoModel.valorVenda,
				codigoNcm: produtoModel.codigoNcm,
				estoqueMinimo: produtoModel.estoqueMinimo,
				estoqueMaximo: produtoModel.estoqueMaximo,
				quantidadeEstoque: produtoModel.quantidadeEstoque,
			),
		);
	}

		
}
