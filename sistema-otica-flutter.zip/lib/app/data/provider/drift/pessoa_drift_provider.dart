import 'package:otica/app/data/provider/drift/database/database_imports.dart';
import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/data/provider/api/api_provider_base.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/model/model_imports.dart';
import 'package:otica/app/data/domain/domain_imports.dart';

class PessoaDriftProvider extends ApiProviderBase {

	Future<List<PessoaModel>?> getList({Filter? filter}) async {
		List<PessoaGrouped> pessoaDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				pessoaDriftList = await Session.database.pessoaDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				pessoaDriftList = await Session.database.pessoaDao.getGroupedList(); 
			}
			if (pessoaDriftList.isNotEmpty) {
				return toListModel(pessoaDriftList);
			} else {
				return [];
			}			 
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<PessoaModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.pessoaDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<PessoaModel?>? insert(PessoaModel pessoaModel) async {
		try {
			final lastPk = await Session.database.pessoaDao.insertObject(toDrift(pessoaModel));
			pessoaModel.id = lastPk;
			return pessoaModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<PessoaModel?>? update(PessoaModel pessoaModel) async {
		try {
			await Session.database.pessoaDao.updateObject(toDrift(pessoaModel));
			return pessoaModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.pessoaDao.deleteObject(toDrift(PessoaModel(id: pk)));
			return true;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<PessoaModel> toListModel(List<PessoaGrouped> pessoaDriftList) {
		List<PessoaModel> listModel = [];
		for (var pessoaDrift in pessoaDriftList) {
			listModel.add(toModel(pessoaDrift)!);
		}
		return listModel;
	}	

	PessoaModel? toModel(PessoaGrouped? pessoaDrift) {
		if (pessoaDrift != null) {
			return PessoaModel(
				id: pessoaDrift.pessoa?.id,
				nome: pessoaDrift.pessoa?.nome,
				tipo: PessoaDomain.getTipo(pessoaDrift.pessoa?.tipo),
				site: pessoaDrift.pessoa?.site,
				email: pessoaDrift.pessoa?.email,
				ehCliente: PessoaDomain.getEhCliente(pessoaDrift.pessoa?.ehCliente),
				ehFornecedor: PessoaDomain.getEhFornecedor(pessoaDrift.pessoa?.ehFornecedor),
				referencia: pessoaDrift.pessoa?.referencia,
				observacao: pessoaDrift.pessoa?.observacao,
				pessoaJuridicaModel: PessoaJuridicaModel(
					id: pessoaDrift.pessoaJuridica?.id,
					idPessoa: pessoaDrift.pessoaJuridica?.idPessoa,
					cnpj: pessoaDrift.pessoaJuridica?.cnpj,
					nomeFantasia: pessoaDrift.pessoaJuridica?.nomeFantasia,
					inscricaoEstadual: pessoaDrift.pessoaJuridica?.inscricaoEstadual,
					inscricaoMunicipal: pessoaDrift.pessoaJuridica?.inscricaoMunicipal,
					dataConstituicao: pessoaDrift.pessoaJuridica?.dataConstituicao,
					tipoRegime: PessoaJuridicaDomain.getTipoRegime(pessoaDrift.pessoaJuridica?.tipoRegime),
					crt: PessoaJuridicaDomain.getCrt(pessoaDrift.pessoaJuridica?.crt),
				),
				fornecedorModel: FornecedorModel(
					id: pessoaDrift.fornecedor?.id,
					idPessoa: pessoaDrift.fornecedor?.idPessoa,
					desde: pessoaDrift.fornecedor?.desde,
					observacao: pessoaDrift.fornecedor?.observacao,
				),
				clienteModel: ClienteModel(
					id: pessoaDrift.cliente?.id,
					idPessoa: pessoaDrift.cliente?.idPessoa,
					desde: pessoaDrift.cliente?.desde,
					taxaDesconto: pessoaDrift.cliente?.taxaDesconto,
					limiteCredito: pessoaDrift.cliente?.limiteCredito,
					ocupacao: pessoaDrift.cliente?.ocupacao,
					observacao: pessoaDrift.cliente?.observacao,
				),
				pessoaFisicaModel: PessoaFisicaModel(
					id: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.id,
					idPessoa: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.idPessoa,
					idNivelFormacao: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.idNivelFormacao,
					idEstadoCivil: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.idEstadoCivil,
					dataNascimento: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.dataNascimento,
					cpf: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.cpf,
					rg: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.rg,
					orgaoRg: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.orgaoRg,
					dataEmissaoRg: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.dataEmissaoRg,
					sexo: PessoaFisicaDomain.getSexo(pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.sexo),
					raca: PessoaFisicaDomain.getRaca(pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.raca),
					nacionalidade: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.nacionalidade,
					naturalidade: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.naturalidade,
					nomePai: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.nomePai,
					nomeMae: pessoaDrift.pessoaFisicaGrouped?.pessoaFisica?.nomeMae,
					nivelFormacaoModel: NivelFormacaoModel(
						id: pessoaDrift.pessoaFisicaGrouped?.nivelFormacao?.id,
						nome: pessoaDrift.pessoaFisicaGrouped?.nivelFormacao?.nome,
						descricao: pessoaDrift.pessoaFisicaGrouped?.nivelFormacao?.descricao,
					),
					estadoCivilModel: EstadoCivilModel(
						id: pessoaDrift.pessoaFisicaGrouped?.estadoCivil?.id,
						nome: pessoaDrift.pessoaFisicaGrouped?.estadoCivil?.nome,
						descricao: pessoaDrift.pessoaFisicaGrouped?.estadoCivil?.descricao,
					),
				),
				pessoaTelefoneModelList: pessoaTelefoneDriftToModel(pessoaDrift.pessoaTelefoneGroupedList),
				pessoaEnderecoModelList: pessoaEnderecoDriftToModel(pessoaDrift.pessoaEnderecoGroupedList),
				pessoaContatoModelList: pessoaContatoDriftToModel(pessoaDrift.pessoaContatoGroupedList),
				atendimentoModelList: atendimentoDriftToModel(pessoaDrift.atendimentoGroupedList),
			);
		} else {
			return null;
		}
	}

	List<PessoaTelefoneModel> pessoaTelefoneDriftToModel(List<PessoaTelefoneGrouped>? pessoaTelefoneDriftList) { 
		List<PessoaTelefoneModel> pessoaTelefoneModelList = [];
		if (pessoaTelefoneDriftList != null) {
			for (var pessoaTelefoneGrouped in pessoaTelefoneDriftList) {
				pessoaTelefoneModelList.add(
					PessoaTelefoneModel(
						id: pessoaTelefoneGrouped.pessoaTelefone?.id,
						idPessoa: pessoaTelefoneGrouped.pessoaTelefone?.idPessoa,
						tipo: PessoaTelefoneDomain.getTipo(pessoaTelefoneGrouped.pessoaTelefone?.tipo),
						numero: pessoaTelefoneGrouped.pessoaTelefone?.numero,
					)
				);
			}
			return pessoaTelefoneModelList;
		}
		return [];
	}

	List<PessoaEnderecoModel> pessoaEnderecoDriftToModel(List<PessoaEnderecoGrouped>? pessoaEnderecoDriftList) { 
		List<PessoaEnderecoModel> pessoaEnderecoModelList = [];
		if (pessoaEnderecoDriftList != null) {
			for (var pessoaEnderecoGrouped in pessoaEnderecoDriftList) {
				pessoaEnderecoModelList.add(
					PessoaEnderecoModel(
						id: pessoaEnderecoGrouped.pessoaEndereco?.id,
						idPessoa: pessoaEnderecoGrouped.pessoaEndereco?.idPessoa,
						logradouro: pessoaEnderecoGrouped.pessoaEndereco?.logradouro,
						numero: pessoaEnderecoGrouped.pessoaEndereco?.numero,
						bairro: pessoaEnderecoGrouped.pessoaEndereco?.bairro,
						cidade: pessoaEnderecoGrouped.pessoaEndereco?.cidade,
						uf: PessoaEnderecoDomain.getUf(pessoaEnderecoGrouped.pessoaEndereco?.uf),
						cep: pessoaEnderecoGrouped.pessoaEndereco?.cep,
						complemento: pessoaEnderecoGrouped.pessoaEndereco?.complemento,
						principal: PessoaEnderecoDomain.getPrincipal(pessoaEnderecoGrouped.pessoaEndereco?.principal),
						entrega: PessoaEnderecoDomain.getEntrega(pessoaEnderecoGrouped.pessoaEndereco?.entrega),
						cobranca: PessoaEnderecoDomain.getCobranca(pessoaEnderecoGrouped.pessoaEndereco?.cobranca),
						correspondencia: PessoaEnderecoDomain.getCorrespondencia(pessoaEnderecoGrouped.pessoaEndereco?.correspondencia),
					)
				);
			}
			return pessoaEnderecoModelList;
		}
		return [];
	}

	List<PessoaContatoModel> pessoaContatoDriftToModel(List<PessoaContatoGrouped>? pessoaContatoDriftList) { 
		List<PessoaContatoModel> pessoaContatoModelList = [];
		if (pessoaContatoDriftList != null) {
			for (var pessoaContatoGrouped in pessoaContatoDriftList) {
				pessoaContatoModelList.add(
					PessoaContatoModel(
						id: pessoaContatoGrouped.pessoaContato?.id,
						idPessoa: pessoaContatoGrouped.pessoaContato?.idPessoa,
						nome: pessoaContatoGrouped.pessoaContato?.nome,
						email: pessoaContatoGrouped.pessoaContato?.email,
						observacao: pessoaContatoGrouped.pessoaContato?.observacao,
					)
				);
			}
			return pessoaContatoModelList;
		}
		return [];
	}

	List<AtendimentoModel> atendimentoDriftToModel(List<AtendimentoGrouped>? atendimentoDriftList) { 
		List<AtendimentoModel> atendimentoModelList = [];
		if (atendimentoDriftList != null) {
			for (var atendimentoGrouped in atendimentoDriftList) {
				atendimentoModelList.add(
					AtendimentoModel(
						id: atendimentoGrouped.atendimento?.id,
						idPessoa: atendimentoGrouped.atendimento?.idPessoa,
						talao: atendimentoGrouped.atendimento?.talao,
						dataAtendimento: atendimentoGrouped.atendimento?.dataAtendimento,
						dataRetorno: atendimentoGrouped.atendimento?.dataRetorno,
						valorEsfericoOd: atendimentoGrouped.atendimento?.valorEsfericoOd,
						valorEsfericoOe: atendimentoGrouped.atendimento?.valorEsfericoOe,
						valorCilindricoOd: atendimentoGrouped.atendimento?.valorCilindricoOd?.toDouble(),
						valorCilindricoOe: atendimentoGrouped.atendimento?.valorCilindricoOe?.toDouble(),
						posicaoEixoOd: atendimentoGrouped.atendimento?.posicaoEixoOd,
						posicaoEixoOe: atendimentoGrouped.atendimento?.posicaoEixoOe,
						distanciaNasoPupilarOd: atendimentoGrouped.atendimento?.distanciaNasoPupilarOd,
						distanciaNasoPupilarOe: atendimentoGrouped.atendimento?.distanciaNasoPupilarOe,
						acuidadeVisualLongeOd: AtendimentoDomain.getAcuidadeVisualLongeOd(atendimentoGrouped.atendimento?.acuidadeVisualLongeOd),
						acuidadeVisualLongeOe: AtendimentoDomain.getAcuidadeVisualLongeOe(atendimentoGrouped.atendimento?.acuidadeVisualLongeOe),
						adicao: atendimentoGrouped.atendimento?.adicao,
						acuidadeVisualPertoOd: AtendimentoDomain.getAcuidadeVisualPertoOd(atendimentoGrouped.atendimento?.acuidadeVisualPertoOd),
						acuidadeVisualPertoOe: AtendimentoDomain.getAcuidadeVisualPertoOe(atendimentoGrouped.atendimento?.acuidadeVisualPertoOe),
						examinador: atendimentoGrouped.atendimento?.examinador,
						observacao: atendimentoGrouped.atendimento?.observacao,
					)
				);
			}
			return atendimentoModelList;
		}
		return [];
	}


	PessoaGrouped toDrift(PessoaModel pessoaModel) {
		return PessoaGrouped(
			pessoa: Pessoa(
				id: pessoaModel.id,
				nome: pessoaModel.nome,
				tipo: PessoaDomain.setTipo(pessoaModel.tipo),
				site: pessoaModel.site,
				email: pessoaModel.email,
				ehCliente: PessoaDomain.setEhCliente(pessoaModel.ehCliente),
				ehFornecedor: PessoaDomain.setEhFornecedor(pessoaModel.ehFornecedor),
				referencia: pessoaModel.referencia,
				observacao: pessoaModel.observacao,
			),
			pessoaJuridica: PessoaJuridica(
				id: pessoaModel.pessoaJuridicaModel?.id,
				idPessoa: pessoaModel.pessoaJuridicaModel?.idPessoa,
				cnpj: Util.removeMask(pessoaModel.pessoaJuridicaModel?.cnpj),
				nomeFantasia: pessoaModel.pessoaJuridicaModel?.nomeFantasia,
				inscricaoEstadual: pessoaModel.pessoaJuridicaModel?.inscricaoEstadual,
				inscricaoMunicipal: pessoaModel.pessoaJuridicaModel?.inscricaoMunicipal,
				dataConstituicao: pessoaModel.pessoaJuridicaModel?.dataConstituicao,
				tipoRegime: PessoaJuridicaDomain.setTipoRegime(pessoaModel.pessoaJuridicaModel?.tipoRegime),
				crt: PessoaJuridicaDomain.setCrt(pessoaModel.pessoaJuridicaModel?.crt),
			),
			fornecedor: Fornecedor(
				id: pessoaModel.fornecedorModel?.id,
				idPessoa: pessoaModel.fornecedorModel?.idPessoa,
				desde: pessoaModel.fornecedorModel?.desde,
				observacao: pessoaModel.fornecedorModel?.observacao,
			),
			cliente: Cliente(
				id: pessoaModel.clienteModel?.id,
				idPessoa: pessoaModel.clienteModel?.idPessoa,
				desde: pessoaModel.clienteModel?.desde,
				taxaDesconto: pessoaModel.clienteModel?.taxaDesconto,
				limiteCredito: pessoaModel.clienteModel?.limiteCredito,
				ocupacao: pessoaModel.clienteModel?.ocupacao,
				observacao: pessoaModel.clienteModel?.observacao,
			),
			pessoaFisicaGrouped: PessoaFisicaGrouped(
				pessoaFisica: PessoaFisica(
					id: pessoaModel.pessoaFisicaModel?.id,
					idPessoa: pessoaModel.pessoaFisicaModel?.idPessoa,
					idNivelFormacao: pessoaModel.pessoaFisicaModel?.idNivelFormacao,
					idEstadoCivil: pessoaModel.pessoaFisicaModel?.idEstadoCivil,
					dataNascimento: pessoaModel.pessoaFisicaModel?.dataNascimento,
					cpf: Util.removeMask(pessoaModel.pessoaFisicaModel?.cpf),
					rg: pessoaModel.pessoaFisicaModel?.rg,
					orgaoRg: pessoaModel.pessoaFisicaModel?.orgaoRg,
					dataEmissaoRg: pessoaModel.pessoaFisicaModel?.dataEmissaoRg,
					sexo: PessoaFisicaDomain.setSexo(pessoaModel.pessoaFisicaModel?.sexo),
					raca: PessoaFisicaDomain.setRaca(pessoaModel.pessoaFisicaModel?.raca),
					nacionalidade: pessoaModel.pessoaFisicaModel?.nacionalidade,
					naturalidade: pessoaModel.pessoaFisicaModel?.naturalidade,
					nomePai: pessoaModel.pessoaFisicaModel?.nomePai,
					nomeMae: pessoaModel.pessoaFisicaModel?.nomeMae,
				),
				nivelFormacao: NivelFormacao(
					id: pessoaModel.pessoaFisicaModel?.nivelFormacaoModel?.id,
					nome: pessoaModel.pessoaFisicaModel?.nivelFormacaoModel?.nome,
					descricao: pessoaModel.pessoaFisicaModel?.nivelFormacaoModel?.descricao,
				),
				estadoCivil: EstadoCivil(
					id: pessoaModel.pessoaFisicaModel?.estadoCivilModel?.id,
					nome: pessoaModel.pessoaFisicaModel?.estadoCivilModel?.nome,
					descricao: pessoaModel.pessoaFisicaModel?.estadoCivilModel?.descricao,
				),
			),
			pessoaTelefoneGroupedList: pessoaTelefoneModelToDrift(pessoaModel.pessoaTelefoneModelList),
			pessoaEnderecoGroupedList: pessoaEnderecoModelToDrift(pessoaModel.pessoaEnderecoModelList),
			pessoaContatoGroupedList: pessoaContatoModelToDrift(pessoaModel.pessoaContatoModelList),
			atendimentoGroupedList: atendimentoModelToDrift(pessoaModel.atendimentoModelList),
		);
	}

	List<PessoaTelefoneGrouped> pessoaTelefoneModelToDrift(List<PessoaTelefoneModel>? pessoaTelefoneModelList) { 
		List<PessoaTelefoneGrouped> pessoaTelefoneGroupedList = [];
		if (pessoaTelefoneModelList != null) {
			for (var pessoaTelefoneModel in pessoaTelefoneModelList) {
				pessoaTelefoneGroupedList.add(
					PessoaTelefoneGrouped(
						pessoaTelefone: PessoaTelefone(
							id: pessoaTelefoneModel.id,
							idPessoa: pessoaTelefoneModel.idPessoa,
							tipo: PessoaTelefoneDomain.setTipo(pessoaTelefoneModel.tipo),
							numero: Util.removeMask(pessoaTelefoneModel.numero),
						),
					),
				);
			}
			return pessoaTelefoneGroupedList;
		}
		return [];
	}

	List<PessoaEnderecoGrouped> pessoaEnderecoModelToDrift(List<PessoaEnderecoModel>? pessoaEnderecoModelList) { 
		List<PessoaEnderecoGrouped> pessoaEnderecoGroupedList = [];
		if (pessoaEnderecoModelList != null) {
			for (var pessoaEnderecoModel in pessoaEnderecoModelList) {
				pessoaEnderecoGroupedList.add(
					PessoaEnderecoGrouped(
						pessoaEndereco: PessoaEndereco(
							id: pessoaEnderecoModel.id,
							idPessoa: pessoaEnderecoModel.idPessoa,
							logradouro: pessoaEnderecoModel.logradouro,
							numero: pessoaEnderecoModel.numero,
							bairro: pessoaEnderecoModel.bairro,
							cidade: pessoaEnderecoModel.cidade,
							uf: PessoaEnderecoDomain.setUf(pessoaEnderecoModel.uf),
							cep: Util.removeMask(pessoaEnderecoModel.cep),
							complemento: pessoaEnderecoModel.complemento,
							principal: PessoaEnderecoDomain.setPrincipal(pessoaEnderecoModel.principal),
							entrega: PessoaEnderecoDomain.setEntrega(pessoaEnderecoModel.entrega),
							cobranca: PessoaEnderecoDomain.setCobranca(pessoaEnderecoModel.cobranca),
							correspondencia: PessoaEnderecoDomain.setCorrespondencia(pessoaEnderecoModel.correspondencia),
						),
					),
				);
			}
			return pessoaEnderecoGroupedList;
		}
		return [];
	}

	List<PessoaContatoGrouped> pessoaContatoModelToDrift(List<PessoaContatoModel>? pessoaContatoModelList) { 
		List<PessoaContatoGrouped> pessoaContatoGroupedList = [];
		if (pessoaContatoModelList != null) {
			for (var pessoaContatoModel in pessoaContatoModelList) {
				pessoaContatoGroupedList.add(
					PessoaContatoGrouped(
						pessoaContato: PessoaContato(
							id: pessoaContatoModel.id,
							idPessoa: pessoaContatoModel.idPessoa,
							nome: pessoaContatoModel.nome,
							email: pessoaContatoModel.email,
							observacao: pessoaContatoModel.observacao,
						),
					),
				);
			}
			return pessoaContatoGroupedList;
		}
		return [];
	}

	List<AtendimentoGrouped> atendimentoModelToDrift(List<AtendimentoModel>? atendimentoModelList) { 
		List<AtendimentoGrouped> atendimentoGroupedList = [];
		if (atendimentoModelList != null) {
			for (var atendimentoModel in atendimentoModelList) {
				atendimentoGroupedList.add(
					AtendimentoGrouped(
						atendimento: Atendimento(
							id: atendimentoModel.id,
							idPessoa: atendimentoModel.idPessoa,
							talao: atendimentoModel.talao,
							dataAtendimento: atendimentoModel.dataAtendimento,
							dataRetorno: atendimentoModel.dataRetorno,
							valorEsfericoOd: atendimentoModel.valorEsfericoOd,
							valorEsfericoOe: atendimentoModel.valorEsfericoOe,
							valorCilindricoOd: atendimentoModel.valorCilindricoOd?.toInt(),
							valorCilindricoOe: atendimentoModel.valorCilindricoOe?.toInt(),
							posicaoEixoOd: atendimentoModel.posicaoEixoOd,
							posicaoEixoOe: atendimentoModel.posicaoEixoOe,
							distanciaNasoPupilarOd: atendimentoModel.distanciaNasoPupilarOd,
							distanciaNasoPupilarOe: atendimentoModel.distanciaNasoPupilarOe,
							acuidadeVisualLongeOd: AtendimentoDomain.setAcuidadeVisualLongeOd(atendimentoModel.acuidadeVisualLongeOd),
							acuidadeVisualLongeOe: AtendimentoDomain.setAcuidadeVisualLongeOe(atendimentoModel.acuidadeVisualLongeOe),
							adicao: atendimentoModel.adicao,
							acuidadeVisualPertoOd: AtendimentoDomain.setAcuidadeVisualPertoOd(atendimentoModel.acuidadeVisualPertoOd),
							acuidadeVisualPertoOe: AtendimentoDomain.setAcuidadeVisualPertoOe(atendimentoModel.acuidadeVisualPertoOe),
							examinador: atendimentoModel.examinador,
							observacao: atendimentoModel.observacao,
						),
					),
				);
			}
			return atendimentoGroupedList;
		}
		return [];
	}

		
}
