import 'package:otica/app/data/provider/drift/database/database_imports.dart';
import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/data/provider/api/api_provider_base.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/model/model_imports.dart';

class ContasPagarDriftProvider extends ApiProviderBase {

	Future<List<ContasPagarModel>?> getList({Filter? filter}) async {
		List<ContasPagarGrouped> contasPagarDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				contasPagarDriftList = await Session.database.contasPagarDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				contasPagarDriftList = await Session.database.contasPagarDao.getGroupedList(); 
			}
			if (contasPagarDriftList.isNotEmpty) {
				return toListModel(contasPagarDriftList);
			} else {
				return [];
			}			 
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<ContasPagarModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.contasPagarDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ContasPagarModel?>? insert(ContasPagarModel contasPagarModel) async {
		try {
			final lastPk = await Session.database.contasPagarDao.insertObject(toDrift(contasPagarModel));
			contasPagarModel.id = lastPk;
			return contasPagarModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ContasPagarModel?>? update(ContasPagarModel contasPagarModel) async {
		try {
			await Session.database.contasPagarDao.updateObject(toDrift(contasPagarModel));
			return contasPagarModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.contasPagarDao.deleteObject(toDrift(ContasPagarModel(id: pk)));
			return true;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<ContasPagarModel> toListModel(List<ContasPagarGrouped> contasPagarDriftList) {
		List<ContasPagarModel> listModel = [];
		for (var contasPagarDrift in contasPagarDriftList) {
			listModel.add(toModel(contasPagarDrift)!);
		}
		return listModel;
	}	

	ContasPagarModel? toModel(ContasPagarGrouped? contasPagarDrift) {
		if (contasPagarDrift != null) {
			return ContasPagarModel(
				id: contasPagarDrift.contasPagar?.id,
				idPessoa: contasPagarDrift.contasPagar?.idPessoa,
				idFormaPagamento: contasPagarDrift.contasPagar?.idFormaPagamento,
				idBancoContaCaixa: contasPagarDrift.contasPagar?.idBancoContaCaixa,
				dataLancamento: contasPagarDrift.contasPagar?.dataLancamento,
				valorTotal: contasPagarDrift.contasPagar?.valorTotal,
				numeroParcela: contasPagarDrift.contasPagar?.numeroParcela,
				valorParcela: contasPagarDrift.contasPagar?.valorParcela,
				dataVencimento: contasPagarDrift.contasPagar?.dataVencimento,
				dataRecebimento: contasPagarDrift.contasPagar?.dataRecebimento,
				valorRecebido: contasPagarDrift.contasPagar?.valorRecebido,
				observacao: contasPagarDrift.contasPagar?.observacao,
				formaPagamentoModel: FormaPagamentoModel(
					id: contasPagarDrift.formaPagamento?.id,
					nome: contasPagarDrift.formaPagamento?.nome,
				),
				pessoaModel: PessoaModel(
					id: contasPagarDrift.pessoa?.id,
					nome: contasPagarDrift.pessoa?.nome,
					tipo: contasPagarDrift.pessoa?.tipo,
					referencia: contasPagarDrift.pessoa?.referencia,
					email: contasPagarDrift.pessoa?.email,
					ehCliente: contasPagarDrift.pessoa?.ehCliente,
					ehFornecedor: contasPagarDrift.pessoa?.ehFornecedor,
					site: contasPagarDrift.pessoa?.site,
					observacao: contasPagarDrift.pessoa?.observacao,
				),
				bancoContaCaixaModel: BancoContaCaixaModel(
					id: contasPagarDrift.bancoContaCaixa?.id,
					idBancoAgencia: contasPagarDrift.bancoContaCaixa?.idBancoAgencia,
					numero: contasPagarDrift.bancoContaCaixa?.numero,
					digito: contasPagarDrift.bancoContaCaixa?.digito,
					tipo: contasPagarDrift.bancoContaCaixa?.tipo,
					nome: contasPagarDrift.bancoContaCaixa?.nome,
					descricao: contasPagarDrift.bancoContaCaixa?.descricao,
				),
			);
		} else {
			return null;
		}
	}


	ContasPagarGrouped toDrift(ContasPagarModel contasPagarModel) {
		return ContasPagarGrouped(
			contasPagar: ContasPagar(
				id: contasPagarModel.id,
				idPessoa: contasPagarModel.idPessoa,
				idFormaPagamento: contasPagarModel.idFormaPagamento,
				idBancoContaCaixa: contasPagarModel.idBancoContaCaixa,
				dataLancamento: contasPagarModel.dataLancamento,
				valorTotal: contasPagarModel.valorTotal,
				numeroParcela: contasPagarModel.numeroParcela,
				valorParcela: contasPagarModel.valorParcela,
				dataVencimento: contasPagarModel.dataVencimento,
				dataRecebimento: contasPagarModel.dataRecebimento,
				valorRecebido: contasPagarModel.valorRecebido,
				observacao: contasPagarModel.observacao,
			),
		);
	}

		
}
