import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';

@DataClassName("ContasReceber")
class ContasRecebers extends Table {
	@override
	String get tableName => 'contas_receber';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idPessoa => integer().named('id_pessoa').nullable()();
	IntColumn get idFormaPagamento => integer().named('id_forma_pagamento').nullable()();
	IntColumn get idVendaCabecalho => integer().named('id_venda_cabecalho').nullable()();
	IntColumn get idBancoContaCaixa => integer().named('id_banco_conta_caixa').nullable()();
	DateTimeColumn get dataLancamento => dateTime().named('data_lancamento').nullable()();
	RealColumn get valorTotal => real().named('valor_total').nullable()();
	IntColumn get numeroParcela => integer().named('numero_parcela').nullable()();
	RealColumn get valorParcela => real().named('valor_parcela').nullable()();
	DateTimeColumn get dataVencimento => dateTime().named('data_vencimento').nullable()();
	DateTimeColumn get dataRecebimento => dateTime().named('data_recebimento').nullable()();
	RealColumn get valorRecebido => real().named('valor_recebido').nullable()();
	TextColumn get observacao => text().named('observacao').withLength(min: 0, max: 250).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class ContasReceberGrouped {
	ContasReceber? contasReceber; 
	VendaCabecalho? vendaCabecalho; 
	Pessoa? pessoa; 
	FormaPagamento? formaPagamento; 
	BancoContaCaixa? bancoContaCaixa; 

  ContasReceberGrouped({
		this.contasReceber, 
		this.vendaCabecalho, 
		this.pessoa, 
		this.formaPagamento, 
		this.bancoContaCaixa, 

  });
}
