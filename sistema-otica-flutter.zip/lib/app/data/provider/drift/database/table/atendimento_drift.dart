import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';

@DataClassName("Atendimento")
class Atendimentos extends Table {
	@override
	String get tableName => 'atendimento';

	IntColumn get id => integer().named('ID').nullable()();
	IntColumn get idPessoa => integer().named('id_pessoa').nullable()();
	IntColumn get talao => integer().named('talao').nullable()();
	DateTimeColumn get dataAtendimento => dateTime().named('data_atendimento').nullable()();
	DateTimeColumn get dataRetorno => dateTime().named('data_retorno').nullable()();
	RealColumn get valorEsfericoOd => real().named('valor_esferico_od').nullable()();
	RealColumn get valorEsfericoOe => real().named('valor_esferico_oe').nullable()();
	IntColumn get valorCilindricoOd => integer().named('valor_cilindrico_od').nullable()();
	IntColumn get valorCilindricoOe => integer().named('valor_cilindrico_oe').nullable()();
	IntColumn get posicaoEixoOd => integer().named('posicao_eixo_od').nullable()();
	IntColumn get posicaoEixoOe => integer().named('posicao_eixo_oe').nullable()();
	RealColumn get distanciaNasoPupilarOd => real().named('distancia_naso_pupilar_od').nullable()();
	RealColumn get distanciaNasoPupilarOe => real().named('distancia_naso_pupilar_oe').nullable()();
	TextColumn get acuidadeVisualLongeOd => text().named('acuidade_visual_longe_od').withLength(min: 0, max: 6).nullable()();
	TextColumn get acuidadeVisualLongeOe => text().named('acuidade_visual_longe_oe').withLength(min: 0, max: 6).nullable()();
	RealColumn get adicao => real().named('adicao').nullable()();
	TextColumn get acuidadeVisualPertoOd => text().named('acuidade_visual_perto_od').withLength(min: 0, max: 2).nullable()();
	TextColumn get acuidadeVisualPertoOe => text().named('acuidade_visual_perto_oe').withLength(min: 0, max: 2).nullable()();
	TextColumn get examinador => text().named('examinador').withLength(min: 0, max: 100).nullable()();
	TextColumn get observacao => text().named('observacao').withLength(min: 0, max: 500).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class AtendimentoGrouped {
	Atendimento? atendimento; 

  AtendimentoGrouped({
		this.atendimento, 

  });
}
