import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';

@DataClassName("Empresa")
class Empresas extends Table {
	@override
	String get tableName => 'empresa';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get razaoSocial => text().named('razao_social').withLength(min: 0, max: 150).nullable()();
	TextColumn get nomeFantasia => text().named('nome_fantasia').withLength(min: 0, max: 150).nullable()();
	TextColumn get cnpj => text().named('cnpj').withLength(min: 0, max: 18).nullable()();
	TextColumn get inscricaoEstadual => text().named('inscricao_estadual').withLength(min: 0, max: 45).nullable()();
	TextColumn get inscricaoMunicipal => text().named('inscricao_municipal').withLength(min: 0, max: 45).nullable()();
	TextColumn get tipoRegime => text().named('tipo_regime').withLength(min: 0, max: 1).nullable()();
	TextColumn get crt => text().named('crt').withLength(min: 0, max: 1).nullable()();
	TextColumn get email => text().named('email').withLength(min: 0, max: 250).nullable()();
	TextColumn get site => text().named('site').withLength(min: 0, max: 250).nullable()();
	TextColumn get contato => text().named('contato').withLength(min: 0, max: 100).nullable()();
	DateTimeColumn get dataConstituicao => dateTime().named('data_constituicao').nullable()();
	IntColumn get codigoIbgeCidade => integer().named('codigo_ibge_cidade').nullable()();
	IntColumn get codigoIbgeUf => integer().named('codigo_ibge_uf').nullable()();
	TextColumn get cei => text().named('cei').withLength(min: 0, max: 12).nullable()();
	TextColumn get codigoCnaePrincipal => text().named('codigo_cnae_principal').withLength(min: 0, max: 7).nullable()();
	BlobColumn get imagemLogotipo => blob().named('imagem_logotipo').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class EmpresaGrouped {
	Empresa? empresa; 

  EmpresaGrouped({
		this.empresa, 

  });
}
