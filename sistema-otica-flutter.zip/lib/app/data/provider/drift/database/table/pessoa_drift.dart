import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/provider/drift/database/database_imports.dart';

@DataClassName("Pessoa")
class Pessoas extends Table {
	@override
	String get tableName => 'pessoa';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get nome => text().named('nome').withLength(min: 0, max: 150).nullable()();
	TextColumn get tipo => text().named('tipo').withLength(min: 0, max: 1).nullable()();
	TextColumn get site => text().named('site').withLength(min: 0, max: 250).nullable()();
	TextColumn get email => text().named('email').withLength(min: 0, max: 250).nullable()();
	TextColumn get ehCliente => text().named('eh_cliente').withLength(min: 0, max: 1).nullable()();
	TextColumn get ehFornecedor => text().named('eh_fornecedor').withLength(min: 0, max: 1).nullable()();
	TextColumn get referencia => text().named('referencia').withLength(min: 0, max: 100).nullable()();
	TextColumn get observacao => text().named('observacao').withLength(min: 0, max: 250).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class PessoaGrouped {
	Pessoa? pessoa; 
	PessoaJuridica? pessoaJuridica; 
	Fornecedor? fornecedor; 
	Cliente? cliente; 
	PessoaFisicaGrouped? pessoaFisicaGrouped; 
	List<PessoaTelefoneGrouped>? pessoaTelefoneGroupedList; 
	List<PessoaEnderecoGrouped>? pessoaEnderecoGroupedList; 
	List<PessoaContatoGrouped>? pessoaContatoGroupedList; 
	List<AtendimentoGrouped>? atendimentoGroupedList; 

  PessoaGrouped({
		this.pessoa, 
		this.pessoaJuridica, 
		this.fornecedor, 
		this.cliente, 
		this. pessoaFisicaGrouped, 
		this.pessoaTelefoneGroupedList, 
		this.pessoaEnderecoGroupedList, 
		this.pessoaContatoGroupedList, 
		this.atendimentoGroupedList, 

  });
}
