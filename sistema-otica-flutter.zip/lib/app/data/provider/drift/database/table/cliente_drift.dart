import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';

@DataClassName("Cliente")
class Clientes extends Table {
	@override
	String get tableName => 'cliente';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idPessoa => integer().named('id_pessoa').nullable()();
	DateTimeColumn get desde => dateTime().named('desde').nullable()();
	RealColumn get taxaDesconto => real().named('taxa_desconto').nullable()();
	RealColumn get limiteCredito => real().named('limite_credito').nullable()();
	TextColumn get ocupacao => text().named('ocupacao').withLength(min: 0, max: 100).nullable()();
	TextColumn get observacao => text().named('observacao').withLength(min: 0, max: 250).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class ClienteGrouped {
	Cliente? cliente; 

  ClienteGrouped({
		this.cliente, 

  });
}
