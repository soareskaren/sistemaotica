import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/provider/drift/database/database_imports.dart';

@DataClassName("VendaCabecalho")
class VendaCabecalhos extends Table {
	@override
	String get tableName => 'venda_cabecalho';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idPessoa => integer().named('id_pessoa').nullable()();
	IntColumn get codigo => integer().named('codigo').nullable()();
	DateTimeColumn get dataVenda => dateTime().named('data_venda').nullable()();
	RealColumn get valorSubtotal => real().named('valor_subtotal').nullable()();
	RealColumn get valorDesconto => real().named('valor_desconto').nullable()();
	RealColumn get valorTotal => real().named('valor_total').nullable()();
	IntColumn get quantidadeParcelas => integer().named('quantidade_parcelas').nullable()();
	DateTimeColumn get primeiroVencimento => dateTime().named('primeiro_vencimento').nullable()();
	DateTimeColumn get dataPrevistaEntrega => dateTime().named('data_prevista_entrega').nullable()();
	DateTimeColumn get dataEntrega => dateTime().named('data_entrega').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class VendaCabecalhoGrouped {
	VendaCabecalho? vendaCabecalho; 
	List<VendaDetalheGrouped>? vendaDetalheGroupedList; 
	Pessoa? pessoa; 

  VendaCabecalhoGrouped({
		this.vendaCabecalho, 
		this.vendaDetalheGroupedList, 
		this.pessoa, 

  });
}
