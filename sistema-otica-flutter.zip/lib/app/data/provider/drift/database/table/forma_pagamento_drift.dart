import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';

@DataClassName("FormaPagamento")
class FormaPagamentos extends Table {
	@override
	String get tableName => 'forma_pagamento';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get nome => text().named('nome').withLength(min: 0, max: 100).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class FormaPagamentoGrouped {
	FormaPagamento? formaPagamento; 

  FormaPagamentoGrouped({
		this.formaPagamento, 

  });
}
