import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';

@DataClassName("Talao")
class Talaos extends Table {
	@override
	String get tableName => 'talao';

	IntColumn get id => integer().named('ID').nullable()();
	TextColumn get ano => text().named('ANO').withLength(min: 0, max: 4).nullable()();
	IntColumn get sequencia => integer().named('SEQUENCIA').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class TalaoGrouped {
	Talao? talao; 

  TalaoGrouped({
		this.talao, 

  });
}
