import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/provider/drift/database/database_imports.dart';

part 'talao_dao.g.dart';

@DriftAccessor(tables: [
	Talaos,
])
class TalaoDao extends DatabaseAccessor<AppDatabase> with _$TalaoDaoMixin {
	final AppDatabase db;

	List<Talao> talaoList = []; 
	List<TalaoGrouped> talaoGroupedList = []; 

	TalaoDao(this.db) : super(db);

	Future<List<Talao>> getList() async {
		talaoList = await select(talaos).get();
		return talaoList;
	}

	Future<List<Talao>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		talaoList = await (select(talaos)..where((t) => expression)).get();
		return talaoList;	 
	}

	Future<List<TalaoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(talaos)
			.join([]);

		if (field != null && field != '') { 
			final column = talaos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		talaoGroupedList = await query.map((row) {
			final talao = row.readTableOrNull(talaos); 

			return TalaoGrouped(
				talao: talao, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var talaoGrouped in talaoGroupedList) {
		//}		

		return talaoGroupedList;	
	}

	Future<Talao?> getObject(dynamic pk) async {
		return await (select(talaos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<Talao?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM talao WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as Talao;		 
	} 

	Future<TalaoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(TalaoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.talao = object.talao!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(talaos).insert(object.talao!);
			object.talao = object.talao!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(TalaoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(talaos).replace(object.talao!);
		});	 
	} 

	Future<int> deleteObject(TalaoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(talaos).delete(object.talao!);
		});		
	}

	Future<void> insertChildren(TalaoGrouped object) async {
	}
	
	Future<void> deleteChildren(TalaoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(ID) as LAST from talao").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}