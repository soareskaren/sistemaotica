// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'empresa_dao.dart';

// ignore_for_file: type=lint
mixin _$EmpresaDaoMixin on DatabaseAccessor<AppDatabase> {
  $EmpresasTable get empresas => attachedDatabase.empresas;
}
