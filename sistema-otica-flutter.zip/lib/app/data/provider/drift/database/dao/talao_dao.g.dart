// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'talao_dao.dart';

// ignore_for_file: type=lint
mixin _$TalaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $TalaosTable get talaos => attachedDatabase.talaos;
}
