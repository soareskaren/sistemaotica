// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pessoa_dao.dart';

// ignore_for_file: type=lint
mixin _$PessoaDaoMixin on DatabaseAccessor<AppDatabase> {
  $PessoasTable get pessoas => attachedDatabase.pessoas;
  $PessoaJuridicasTable get pessoaJuridicas => attachedDatabase.pessoaJuridicas;
  $FornecedorsTable get fornecedors => attachedDatabase.fornecedors;
  $ClientesTable get clientes => attachedDatabase.clientes;
  $PessoaFisicasTable get pessoaFisicas => attachedDatabase.pessoaFisicas;
  $NivelFormacaosTable get nivelFormacaos => attachedDatabase.nivelFormacaos;
  $EstadoCivilsTable get estadoCivils => attachedDatabase.estadoCivils;
  $PessoaTelefonesTable get pessoaTelefones => attachedDatabase.pessoaTelefones;
  $PessoaEnderecosTable get pessoaEnderecos => attachedDatabase.pessoaEnderecos;
  $PessoaContatosTable get pessoaContatos => attachedDatabase.pessoaContatos;
  $AtendimentosTable get atendimentos => attachedDatabase.atendimentos;
}
