// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contas_receber_dao.dart';

// ignore_for_file: type=lint
mixin _$ContasReceberDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContasRecebersTable get contasRecebers => attachedDatabase.contasRecebers;
  $VendaCabecalhosTable get vendaCabecalhos => attachedDatabase.vendaCabecalhos;
  $PessoasTable get pessoas => attachedDatabase.pessoas;
  $FormaPagamentosTable get formaPagamentos => attachedDatabase.formaPagamentos;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
}
