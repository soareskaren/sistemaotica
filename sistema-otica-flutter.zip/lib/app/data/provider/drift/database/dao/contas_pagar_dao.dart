import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/provider/drift/database/database_imports.dart';

part 'contas_pagar_dao.g.dart';

@DriftAccessor(tables: [
	ContasPagars,
	FormaPagamentos,
	Pessoas,
	BancoContaCaixas,
])
class ContasPagarDao extends DatabaseAccessor<AppDatabase> with _$ContasPagarDaoMixin {
	final AppDatabase db;

	List<ContasPagar> contasPagarList = []; 
	List<ContasPagarGrouped> contasPagarGroupedList = []; 

	ContasPagarDao(this.db) : super(db);

	Future<List<ContasPagar>> getList() async {
		contasPagarList = await select(contasPagars).get();
		return contasPagarList;
	}

	Future<List<ContasPagar>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		contasPagarList = await (select(contasPagars)..where((t) => expression)).get();
		return contasPagarList;	 
	}

	Future<List<ContasPagarGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(contasPagars)
			.join([ 
				leftOuterJoin(formaPagamentos, formaPagamentos.id.equalsExp(contasPagars.idFormaPagamento)), 
			]).join([ 
				leftOuterJoin(pessoas, pessoas.id.equalsExp(contasPagars.idPessoa)), 
			]).join([ 
				leftOuterJoin(bancoContaCaixas, bancoContaCaixas.id.equalsExp(contasPagars.idBancoContaCaixa)), 
			]);

		if (field != null && field != '') { 
			final column = contasPagars.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		contasPagarGroupedList = await query.map((row) {
			final contasPagar = row.readTableOrNull(contasPagars); 
			final formaPagamento = row.readTableOrNull(formaPagamentos); 
			final pessoa = row.readTableOrNull(pessoas); 
			final bancoContaCaixa = row.readTableOrNull(bancoContaCaixas); 

			return ContasPagarGrouped(
				contasPagar: contasPagar, 
				formaPagamento: formaPagamento, 
				pessoa: pessoa, 
				bancoContaCaixa: bancoContaCaixa, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var contasPagarGrouped in contasPagarGroupedList) {
		//}		

		return contasPagarGroupedList;	
	}

	Future<ContasPagar?> getObject(dynamic pk) async {
		return await (select(contasPagars)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<ContasPagar?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM contas_pagar WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as ContasPagar;		 
	} 

	Future<ContasPagarGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(ContasPagarGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.contasPagar = object.contasPagar!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(contasPagars).insert(object.contasPagar!);
			object.contasPagar = object.contasPagar!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(ContasPagarGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(contasPagars).replace(object.contasPagar!);
		});	 
	} 

	Future<int> deleteObject(ContasPagarGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(contasPagars).delete(object.contasPagar!);
		});		
	}

	Future<void> insertChildren(ContasPagarGrouped object) async {
	}
	
	Future<void> deleteChildren(ContasPagarGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from contas_pagar").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}