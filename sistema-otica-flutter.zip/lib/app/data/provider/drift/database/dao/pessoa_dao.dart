import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/provider/drift/database/database_imports.dart';

part 'pessoa_dao.g.dart';

@DriftAccessor(tables: [
	Pessoas,
	PessoaJuridicas,
	Fornecedors,
	Clientes,
	PessoaFisicas,
	NivelFormacaos,
	EstadoCivils,
	PessoaTelefones,
	PessoaEnderecos,
	PessoaContatos,
	Atendimentos,
])
class PessoaDao extends DatabaseAccessor<AppDatabase> with _$PessoaDaoMixin {
	final AppDatabase db;

	List<Pessoa> pessoaList = []; 
	List<PessoaGrouped> pessoaGroupedList = []; 

	PessoaDao(this.db) : super(db);

	Future<List<Pessoa>> getList() async {
		pessoaList = await select(pessoas).get();
		return pessoaList;
	}

	Future<List<Pessoa>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		pessoaList = await (select(pessoas)..where((t) => expression)).get();
		return pessoaList;	 
	}

	Future<List<PessoaGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(pessoas)
			.join([ 
				leftOuterJoin(pessoaJuridicas, pessoaJuridicas.idPessoa.equalsExp(pessoas.id)), 
			]).join([ 
				leftOuterJoin(fornecedors, fornecedors.idPessoa.equalsExp(pessoas.id)), 
			]).join([ 
				leftOuterJoin(clientes, clientes.idPessoa.equalsExp(pessoas.id)), 
			]).join([ 
				leftOuterJoin(pessoaFisicas, pessoaFisicas.idPessoa.equalsExp(pessoas.id)), 
			]).join([ 
				leftOuterJoin(nivelFormacaos, nivelFormacaos.id.equalsExp(pessoaFisicas.idNivelFormacao)), 
			]).join([ 
				leftOuterJoin(estadoCivils, estadoCivils.id.equalsExp(pessoaFisicas.idEstadoCivil)), 
			]);

		if (field != null && field != '') { 
			final column = pessoas.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		pessoaGroupedList = await query.map((row) {
			final pessoa = row.readTableOrNull(pessoas); 
			final pessoaJuridica = row.readTableOrNull(pessoaJuridicas); 
			final fornecedor = row.readTableOrNull(fornecedors); 
			final cliente = row.readTableOrNull(clientes); 
			final pessoaFisica = row.readTableOrNull(pessoaFisicas); 
			final nivelFormacao = row.readTableOrNull(nivelFormacaos); 
			final estadoCivil = row.readTableOrNull(estadoCivils); 

			return PessoaGrouped(
				pessoa: pessoa, 
				pessoaJuridica: pessoaJuridica, 
				fornecedor: fornecedor, 
				cliente: cliente, 
				pessoaFisicaGrouped: PessoaFisicaGrouped 
				(
					pessoaFisica: pessoaFisica, 
					nivelFormacao: nivelFormacao, 
					estadoCivil: estadoCivil, 
				),
			);
		}).get();

		// fill internal lists
		dynamic expression;
		for (var pessoaGrouped in pessoaGroupedList) {
			pessoaGrouped.pessoaTelefoneGroupedList = [];
			final queryPessoaTelefone = ' id_pessoa = ${pessoaGrouped.pessoa!.id}';
			expression = CustomExpression<bool>(queryPessoaTelefone);
			final pessoaTelefoneList = await (select(pessoaTelefones)..where((t) => expression)).get();
			for (var pessoaTelefone in pessoaTelefoneList) {
				PessoaTelefoneGrouped pessoaTelefoneGrouped = PessoaTelefoneGrouped(
					pessoaTelefone: pessoaTelefone,
				);
				pessoaGrouped.pessoaTelefoneGroupedList!.add(pessoaTelefoneGrouped);
			}

			pessoaGrouped.pessoaEnderecoGroupedList = [];
			final queryPessoaEndereco = ' id_pessoa = ${pessoaGrouped.pessoa!.id}';
			expression = CustomExpression<bool>(queryPessoaEndereco);
			final pessoaEnderecoList = await (select(pessoaEnderecos)..where((t) => expression)).get();
			for (var pessoaEndereco in pessoaEnderecoList) {
				PessoaEnderecoGrouped pessoaEnderecoGrouped = PessoaEnderecoGrouped(
					pessoaEndereco: pessoaEndereco,
				);
				pessoaGrouped.pessoaEnderecoGroupedList!.add(pessoaEnderecoGrouped);
			}

			pessoaGrouped.pessoaContatoGroupedList = [];
			final queryPessoaContato = ' id_pessoa = ${pessoaGrouped.pessoa!.id}';
			expression = CustomExpression<bool>(queryPessoaContato);
			final pessoaContatoList = await (select(pessoaContatos)..where((t) => expression)).get();
			for (var pessoaContato in pessoaContatoList) {
				PessoaContatoGrouped pessoaContatoGrouped = PessoaContatoGrouped(
					pessoaContato: pessoaContato,
				);
				pessoaGrouped.pessoaContatoGroupedList!.add(pessoaContatoGrouped);
			}

			pessoaGrouped.atendimentoGroupedList = [];
			final queryAtendimento = ' id_pessoa = ${pessoaGrouped.pessoa!.id}';
			expression = CustomExpression<bool>(queryAtendimento);
			final atendimentoList = await (select(atendimentos)..where((t) => expression)).get();
			for (var atendimento in atendimentoList) {
				AtendimentoGrouped atendimentoGrouped = AtendimentoGrouped(
					atendimento: atendimento,
				);
				pessoaGrouped.atendimentoGroupedList!.add(atendimentoGrouped);
			}

		}		

		return pessoaGroupedList;	
	}

	Future<Pessoa?> getObject(dynamic pk) async {
		return await (select(pessoas)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<Pessoa?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM pessoa WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as Pessoa;		 
	} 

	Future<PessoaGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(PessoaGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.pessoa = object.pessoa!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(pessoas).insert(object.pessoa!);
			object.pessoa = object.pessoa!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(PessoaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(pessoas).replace(object.pessoa!);
		});	 
	} 

	Future<int> deleteObject(PessoaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(pessoas).delete(object.pessoa!);
		});		
	}

	Future<void> insertChildren(PessoaGrouped object) async {
		object.pessoaJuridica = object.pessoaJuridica!.copyWith(idPessoa: Value(object.pessoa!.id));
		await into(pessoaJuridicas).insert(object.pessoaJuridica!);
		object.fornecedor = object.fornecedor!.copyWith(idPessoa: Value(object.pessoa!.id));
		await into(fornecedors).insert(object.fornecedor!);
		object.cliente = object.cliente!.copyWith(idPessoa: Value(object.pessoa!.id));
		await into(clientes).insert(object.cliente!);
		object.pessoaFisicaGrouped!.pessoaFisica = object.pessoaFisicaGrouped!.pessoaFisica!.copyWith(idPessoa: Value(object.pessoa!.id));
		await into(pessoaFisicas).insert(object.pessoaFisicaGrouped!.pessoaFisica!);
		for (var pessoaTelefoneGrouped in object.pessoaTelefoneGroupedList!) {
			pessoaTelefoneGrouped.pessoaTelefone = pessoaTelefoneGrouped.pessoaTelefone?.copyWith(
				id: const Value(null),
				idPessoa: Value(object.pessoa!.id),
			);
			await into(pessoaTelefones).insert(pessoaTelefoneGrouped.pessoaTelefone!);
		}
		for (var pessoaEnderecoGrouped in object.pessoaEnderecoGroupedList!) {
			pessoaEnderecoGrouped.pessoaEndereco = pessoaEnderecoGrouped.pessoaEndereco?.copyWith(
				id: const Value(null),
				idPessoa: Value(object.pessoa!.id),
			);
			await into(pessoaEnderecos).insert(pessoaEnderecoGrouped.pessoaEndereco!);
		}
		for (var pessoaContatoGrouped in object.pessoaContatoGroupedList!) {
			pessoaContatoGrouped.pessoaContato = pessoaContatoGrouped.pessoaContato?.copyWith(
				id: const Value(null),
				idPessoa: Value(object.pessoa!.id),
			);
			await into(pessoaContatos).insert(pessoaContatoGrouped.pessoaContato!);
		}
		for (var atendimentoGrouped in object.atendimentoGroupedList!) {
			atendimentoGrouped.atendimento = atendimentoGrouped.atendimento?.copyWith(
				id: const Value(null),
				idPessoa: Value(object.pessoa!.id),
			);
			await into(atendimentos).insert(atendimentoGrouped.atendimento!);
		}
	}
	
	Future<void> deleteChildren(PessoaGrouped object) async {
		await (delete(pessoaJuridicas)..where((t) => t.idPessoa.equals(object.pessoa!.id!))).go();
		await (delete(fornecedors)..where((t) => t.idPessoa.equals(object.pessoa!.id!))).go();
		await (delete(clientes)..where((t) => t.idPessoa.equals(object.pessoa!.id!))).go();
		await (delete(pessoaFisicas)..where((t) => t.idPessoa.equals(object.pessoa!.id!))).go();
		await (delete(pessoaTelefones)..where((t) => t.idPessoa.equals(object.pessoa!.id!))).go();
		await (delete(pessoaEnderecos)..where((t) => t.idPessoa.equals(object.pessoa!.id!))).go();
		await (delete(pessoaContatos)..where((t) => t.idPessoa.equals(object.pessoa!.id!))).go();
		await (delete(atendimentos)..where((t) => t.idPessoa.equals(object.pessoa!.id!))).go();
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from pessoa").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}