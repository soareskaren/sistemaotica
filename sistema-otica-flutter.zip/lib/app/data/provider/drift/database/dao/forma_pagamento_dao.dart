import 'package:drift/drift.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/provider/drift/database/database_imports.dart';

part 'forma_pagamento_dao.g.dart';

@DriftAccessor(tables: [
	FormaPagamentos,
])
class FormaPagamentoDao extends DatabaseAccessor<AppDatabase> with _$FormaPagamentoDaoMixin {
	final AppDatabase db;

	List<FormaPagamento> formaPagamentoList = []; 
	List<FormaPagamentoGrouped> formaPagamentoGroupedList = []; 

	FormaPagamentoDao(this.db) : super(db);

	Future<List<FormaPagamento>> getList() async {
		formaPagamentoList = await select(formaPagamentos).get();
		return formaPagamentoList;
	}

	Future<List<FormaPagamento>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		formaPagamentoList = await (select(formaPagamentos)..where((t) => expression)).get();
		return formaPagamentoList;	 
	}

	Future<List<FormaPagamentoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(formaPagamentos)
			.join([]);

		if (field != null && field != '') { 
			final column = formaPagamentos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		formaPagamentoGroupedList = await query.map((row) {
			final formaPagamento = row.readTableOrNull(formaPagamentos); 

			return FormaPagamentoGrouped(
				formaPagamento: formaPagamento, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var formaPagamentoGrouped in formaPagamentoGroupedList) {
		//}		

		return formaPagamentoGroupedList;	
	}

	Future<FormaPagamento?> getObject(dynamic pk) async {
		return await (select(formaPagamentos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<FormaPagamento?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM forma_pagamento WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as FormaPagamento;		 
	} 

	Future<FormaPagamentoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(FormaPagamentoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.formaPagamento = object.formaPagamento!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(formaPagamentos).insert(object.formaPagamento!);
			object.formaPagamento = object.formaPagamento!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(FormaPagamentoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(formaPagamentos).replace(object.formaPagamento!);
		});	 
	} 

	Future<int> deleteObject(FormaPagamentoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(formaPagamentos).delete(object.formaPagamento!);
		});		
	}

	Future<void> insertChildren(FormaPagamentoGrouped object) async {
	}
	
	Future<void> deleteChildren(FormaPagamentoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from forma_pagamento").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}