// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contas_pagar_dao.dart';

// ignore_for_file: type=lint
mixin _$ContasPagarDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContasPagarsTable get contasPagars => attachedDatabase.contasPagars;
  $FormaPagamentosTable get formaPagamentos => attachedDatabase.formaPagamentos;
  $PessoasTable get pessoas => attachedDatabase.pessoas;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
}
