// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'produto_unidade_dao.dart';

// ignore_for_file: type=lint
mixin _$ProdutoUnidadeDaoMixin on DatabaseAccessor<AppDatabase> {
  $ProdutoUnidadesTable get produtoUnidades => attachedDatabase.produtoUnidades;
}
