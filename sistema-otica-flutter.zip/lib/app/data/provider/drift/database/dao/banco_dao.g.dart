// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'banco_dao.dart';

// ignore_for_file: type=lint
mixin _$BancoDaoMixin on DatabaseAccessor<AppDatabase> {
  $BancosTable get bancos => attachedDatabase.bancos;
}
