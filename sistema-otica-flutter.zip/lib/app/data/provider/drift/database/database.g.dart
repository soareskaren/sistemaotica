// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $PessoaContatosTable extends PessoaContatos
    with TableInfo<$PessoaContatosTable, PessoaContato> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoaContatosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idPessoa, nome, email, observacao];
  @override
  String get aliasedName => _alias ?? 'pessoa_contato';
  @override
  String get actualTableName => 'pessoa_contato';
  @override
  VerificationContext validateIntegrity(Insertable<PessoaContato> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PessoaContato map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PessoaContato(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $PessoaContatosTable createAlias(String alias) {
    return $PessoaContatosTable(attachedDatabase, alias);
  }
}

class PessoaContato extends DataClass implements Insertable<PessoaContato> {
  final int? id;
  final int? idPessoa;
  final String? nome;
  final String? email;
  final String? observacao;
  const PessoaContato(
      {this.id, this.idPessoa, this.nome, this.email, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory PessoaContato.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PessoaContato(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      nome: serializer.fromJson<String?>(json['nome']),
      email: serializer.fromJson<String?>(json['email']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'nome': serializer.toJson<String?>(nome),
      'email': serializer.toJson<String?>(email),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  PessoaContato copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      PessoaContato(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        nome: nome.present ? nome.value : this.nome,
        email: email.present ? email.value : this.email,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('PessoaContato(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('nome: $nome, ')
          ..write('email: $email, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, nome, email, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PessoaContato &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.nome == this.nome &&
          other.email == this.email &&
          other.observacao == this.observacao);
}

class PessoaContatosCompanion extends UpdateCompanion<PessoaContato> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> nome;
  final Value<String?> email;
  final Value<String?> observacao;
  const PessoaContatosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.nome = const Value.absent(),
    this.email = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  PessoaContatosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.nome = const Value.absent(),
    this.email = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<PessoaContato> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? nome,
    Expression<String>? email,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (nome != null) 'nome': nome,
      if (email != null) 'email': email,
      if (observacao != null) 'observacao': observacao,
    });
  }

  PessoaContatosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? nome,
      Value<String?>? email,
      Value<String?>? observacao}) {
    return PessoaContatosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      nome: nome ?? this.nome,
      email: email ?? this.email,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoaContatosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('nome: $nome, ')
          ..write('email: $email, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $ClientesTable extends Clientes with TableInfo<$ClientesTable, Cliente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ClientesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
      'desde', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _limiteCreditoMeta =
      const VerificationMeta('limiteCredito');
  @override
  late final GeneratedColumn<double> limiteCredito = GeneratedColumn<double>(
      'limite_credito', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _ocupacaoMeta =
      const VerificationMeta('ocupacao');
  @override
  late final GeneratedColumn<String> ocupacao = GeneratedColumn<String>(
      'ocupacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idPessoa, desde, taxaDesconto, limiteCredito, ocupacao, observacao];
  @override
  String get aliasedName => _alias ?? 'cliente';
  @override
  String get actualTableName => 'cliente';
  @override
  VerificationContext validateIntegrity(Insertable<Cliente> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('desde')) {
      context.handle(
          _desdeMeta, desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('limite_credito')) {
      context.handle(
          _limiteCreditoMeta,
          limiteCredito.isAcceptableOrUnknown(
              data['limite_credito']!, _limiteCreditoMeta));
    }
    if (data.containsKey('ocupacao')) {
      context.handle(_ocupacaoMeta,
          ocupacao.isAcceptableOrUnknown(data['ocupacao']!, _ocupacaoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Cliente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Cliente(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      desde: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}desde']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      limiteCredito: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}limite_credito']),
      ocupacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ocupacao']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $ClientesTable createAlias(String alias) {
    return $ClientesTable(attachedDatabase, alias);
  }
}

class Cliente extends DataClass implements Insertable<Cliente> {
  final int? id;
  final int? idPessoa;
  final DateTime? desde;
  final double? taxaDesconto;
  final double? limiteCredito;
  final String? ocupacao;
  final String? observacao;
  const Cliente(
      {this.id,
      this.idPessoa,
      this.desde,
      this.taxaDesconto,
      this.limiteCredito,
      this.ocupacao,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || limiteCredito != null) {
      map['limite_credito'] = Variable<double>(limiteCredito);
    }
    if (!nullToAbsent || ocupacao != null) {
      map['ocupacao'] = Variable<String>(ocupacao);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory Cliente.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Cliente(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      limiteCredito: serializer.fromJson<double?>(json['limiteCredito']),
      ocupacao: serializer.fromJson<String?>(json['ocupacao']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'desde': serializer.toJson<DateTime?>(desde),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'limiteCredito': serializer.toJson<double?>(limiteCredito),
      'ocupacao': serializer.toJson<String?>(ocupacao),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  Cliente copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<DateTime?> desde = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> limiteCredito = const Value.absent(),
          Value<String?> ocupacao = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      Cliente(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        desde: desde.present ? desde.value : this.desde,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        limiteCredito:
            limiteCredito.present ? limiteCredito.value : this.limiteCredito,
        ocupacao: ocupacao.present ? ocupacao.value : this.ocupacao,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('Cliente(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('ocupacao: $ocupacao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idPessoa, desde, taxaDesconto, limiteCredito, ocupacao, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Cliente &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.desde == this.desde &&
          other.taxaDesconto == this.taxaDesconto &&
          other.limiteCredito == this.limiteCredito &&
          other.ocupacao == this.ocupacao &&
          other.observacao == this.observacao);
}

class ClientesCompanion extends UpdateCompanion<Cliente> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<DateTime?> desde;
  final Value<double?> taxaDesconto;
  final Value<double?> limiteCredito;
  final Value<String?> ocupacao;
  final Value<String?> observacao;
  const ClientesCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.ocupacao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  ClientesCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.ocupacao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<Cliente> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<DateTime>? desde,
    Expression<double>? taxaDesconto,
    Expression<double>? limiteCredito,
    Expression<String>? ocupacao,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (desde != null) 'desde': desde,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (limiteCredito != null) 'limite_credito': limiteCredito,
      if (ocupacao != null) 'ocupacao': ocupacao,
      if (observacao != null) 'observacao': observacao,
    });
  }

  ClientesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<DateTime?>? desde,
      Value<double?>? taxaDesconto,
      Value<double?>? limiteCredito,
      Value<String?>? ocupacao,
      Value<String?>? observacao}) {
    return ClientesCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      desde: desde ?? this.desde,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      limiteCredito: limiteCredito ?? this.limiteCredito,
      ocupacao: ocupacao ?? this.ocupacao,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (limiteCredito.present) {
      map['limite_credito'] = Variable<double>(limiteCredito.value);
    }
    if (ocupacao.present) {
      map['ocupacao'] = Variable<String>(ocupacao.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ClientesCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('ocupacao: $ocupacao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $PessoaFisicasTable extends PessoaFisicas
    with TableInfo<$PessoaFisicasTable, PessoaFisica> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoaFisicasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idNivelFormacaoMeta =
      const VerificationMeta('idNivelFormacao');
  @override
  late final GeneratedColumn<int> idNivelFormacao = GeneratedColumn<int>(
      'id_nivel_formacao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEstadoCivilMeta =
      const VerificationMeta('idEstadoCivil');
  @override
  late final GeneratedColumn<int> idEstadoCivil = GeneratedColumn<int>(
      'id_estado_civil', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataNascimentoMeta =
      const VerificationMeta('dataNascimento');
  @override
  late final GeneratedColumn<DateTime> dataNascimento =
      GeneratedColumn<DateTime>('data_nascimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgMeta = const VerificationMeta('rg');
  @override
  late final GeneratedColumn<String> rg = GeneratedColumn<String>(
      'rg', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _orgaoRgMeta =
      const VerificationMeta('orgaoRg');
  @override
  late final GeneratedColumn<String> orgaoRg = GeneratedColumn<String>(
      'orgao_rg', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataEmissaoRgMeta =
      const VerificationMeta('dataEmissaoRg');
  @override
  late final GeneratedColumn<DateTime> dataEmissaoRg =
      GeneratedColumn<DateTime>('data_emissao_rg', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _sexoMeta = const VerificationMeta('sexo');
  @override
  late final GeneratedColumn<String> sexo = GeneratedColumn<String>(
      'sexo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _racaMeta = const VerificationMeta('raca');
  @override
  late final GeneratedColumn<String> raca = GeneratedColumn<String>(
      'raca', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nacionalidadeMeta =
      const VerificationMeta('nacionalidade');
  @override
  late final GeneratedColumn<String> nacionalidade = GeneratedColumn<String>(
      'nacionalidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _naturalidadeMeta =
      const VerificationMeta('naturalidade');
  @override
  late final GeneratedColumn<String> naturalidade = GeneratedColumn<String>(
      'naturalidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomePaiMeta =
      const VerificationMeta('nomePai');
  @override
  late final GeneratedColumn<String> nomePai = GeneratedColumn<String>(
      'nome_pai', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 200),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMaeMeta =
      const VerificationMeta('nomeMae');
  @override
  late final GeneratedColumn<String> nomeMae = GeneratedColumn<String>(
      'nome_mae', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 200),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        idNivelFormacao,
        idEstadoCivil,
        dataNascimento,
        cpf,
        rg,
        orgaoRg,
        dataEmissaoRg,
        sexo,
        raca,
        nacionalidade,
        naturalidade,
        nomePai,
        nomeMae
      ];
  @override
  String get aliasedName => _alias ?? 'pessoa_fisica';
  @override
  String get actualTableName => 'pessoa_fisica';
  @override
  VerificationContext validateIntegrity(Insertable<PessoaFisica> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_nivel_formacao')) {
      context.handle(
          _idNivelFormacaoMeta,
          idNivelFormacao.isAcceptableOrUnknown(
              data['id_nivel_formacao']!, _idNivelFormacaoMeta));
    }
    if (data.containsKey('id_estado_civil')) {
      context.handle(
          _idEstadoCivilMeta,
          idEstadoCivil.isAcceptableOrUnknown(
              data['id_estado_civil']!, _idEstadoCivilMeta));
    }
    if (data.containsKey('data_nascimento')) {
      context.handle(
          _dataNascimentoMeta,
          dataNascimento.isAcceptableOrUnknown(
              data['data_nascimento']!, _dataNascimentoMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    if (data.containsKey('rg')) {
      context.handle(_rgMeta, rg.isAcceptableOrUnknown(data['rg']!, _rgMeta));
    }
    if (data.containsKey('orgao_rg')) {
      context.handle(_orgaoRgMeta,
          orgaoRg.isAcceptableOrUnknown(data['orgao_rg']!, _orgaoRgMeta));
    }
    if (data.containsKey('data_emissao_rg')) {
      context.handle(
          _dataEmissaoRgMeta,
          dataEmissaoRg.isAcceptableOrUnknown(
              data['data_emissao_rg']!, _dataEmissaoRgMeta));
    }
    if (data.containsKey('sexo')) {
      context.handle(
          _sexoMeta, sexo.isAcceptableOrUnknown(data['sexo']!, _sexoMeta));
    }
    if (data.containsKey('raca')) {
      context.handle(
          _racaMeta, raca.isAcceptableOrUnknown(data['raca']!, _racaMeta));
    }
    if (data.containsKey('nacionalidade')) {
      context.handle(
          _nacionalidadeMeta,
          nacionalidade.isAcceptableOrUnknown(
              data['nacionalidade']!, _nacionalidadeMeta));
    }
    if (data.containsKey('naturalidade')) {
      context.handle(
          _naturalidadeMeta,
          naturalidade.isAcceptableOrUnknown(
              data['naturalidade']!, _naturalidadeMeta));
    }
    if (data.containsKey('nome_pai')) {
      context.handle(_nomePaiMeta,
          nomePai.isAcceptableOrUnknown(data['nome_pai']!, _nomePaiMeta));
    }
    if (data.containsKey('nome_mae')) {
      context.handle(_nomeMaeMeta,
          nomeMae.isAcceptableOrUnknown(data['nome_mae']!, _nomeMaeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PessoaFisica map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PessoaFisica(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idNivelFormacao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_nivel_formacao']),
      idEstadoCivil: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_estado_civil']),
      dataNascimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_nascimento']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
      rg: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg']),
      orgaoRg: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}orgao_rg']),
      dataEmissaoRg: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_emissao_rg']),
      sexo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sexo']),
      raca: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}raca']),
      nacionalidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nacionalidade']),
      naturalidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}naturalidade']),
      nomePai: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_pai']),
      nomeMae: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_mae']),
    );
  }

  @override
  $PessoaFisicasTable createAlias(String alias) {
    return $PessoaFisicasTable(attachedDatabase, alias);
  }
}

class PessoaFisica extends DataClass implements Insertable<PessoaFisica> {
  final int? id;
  final int? idPessoa;
  final int? idNivelFormacao;
  final int? idEstadoCivil;
  final DateTime? dataNascimento;
  final String? cpf;
  final String? rg;
  final String? orgaoRg;
  final DateTime? dataEmissaoRg;
  final String? sexo;
  final String? raca;
  final String? nacionalidade;
  final String? naturalidade;
  final String? nomePai;
  final String? nomeMae;
  const PessoaFisica(
      {this.id,
      this.idPessoa,
      this.idNivelFormacao,
      this.idEstadoCivil,
      this.dataNascimento,
      this.cpf,
      this.rg,
      this.orgaoRg,
      this.dataEmissaoRg,
      this.sexo,
      this.raca,
      this.nacionalidade,
      this.naturalidade,
      this.nomePai,
      this.nomeMae});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idNivelFormacao != null) {
      map['id_nivel_formacao'] = Variable<int>(idNivelFormacao);
    }
    if (!nullToAbsent || idEstadoCivil != null) {
      map['id_estado_civil'] = Variable<int>(idEstadoCivil);
    }
    if (!nullToAbsent || dataNascimento != null) {
      map['data_nascimento'] = Variable<DateTime>(dataNascimento);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || rg != null) {
      map['rg'] = Variable<String>(rg);
    }
    if (!nullToAbsent || orgaoRg != null) {
      map['orgao_rg'] = Variable<String>(orgaoRg);
    }
    if (!nullToAbsent || dataEmissaoRg != null) {
      map['data_emissao_rg'] = Variable<DateTime>(dataEmissaoRg);
    }
    if (!nullToAbsent || sexo != null) {
      map['sexo'] = Variable<String>(sexo);
    }
    if (!nullToAbsent || raca != null) {
      map['raca'] = Variable<String>(raca);
    }
    if (!nullToAbsent || nacionalidade != null) {
      map['nacionalidade'] = Variable<String>(nacionalidade);
    }
    if (!nullToAbsent || naturalidade != null) {
      map['naturalidade'] = Variable<String>(naturalidade);
    }
    if (!nullToAbsent || nomePai != null) {
      map['nome_pai'] = Variable<String>(nomePai);
    }
    if (!nullToAbsent || nomeMae != null) {
      map['nome_mae'] = Variable<String>(nomeMae);
    }
    return map;
  }

  factory PessoaFisica.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PessoaFisica(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idNivelFormacao: serializer.fromJson<int?>(json['idNivelFormacao']),
      idEstadoCivil: serializer.fromJson<int?>(json['idEstadoCivil']),
      dataNascimento: serializer.fromJson<DateTime?>(json['dataNascimento']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      rg: serializer.fromJson<String?>(json['rg']),
      orgaoRg: serializer.fromJson<String?>(json['orgaoRg']),
      dataEmissaoRg: serializer.fromJson<DateTime?>(json['dataEmissaoRg']),
      sexo: serializer.fromJson<String?>(json['sexo']),
      raca: serializer.fromJson<String?>(json['raca']),
      nacionalidade: serializer.fromJson<String?>(json['nacionalidade']),
      naturalidade: serializer.fromJson<String?>(json['naturalidade']),
      nomePai: serializer.fromJson<String?>(json['nomePai']),
      nomeMae: serializer.fromJson<String?>(json['nomeMae']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idNivelFormacao': serializer.toJson<int?>(idNivelFormacao),
      'idEstadoCivil': serializer.toJson<int?>(idEstadoCivil),
      'dataNascimento': serializer.toJson<DateTime?>(dataNascimento),
      'cpf': serializer.toJson<String?>(cpf),
      'rg': serializer.toJson<String?>(rg),
      'orgaoRg': serializer.toJson<String?>(orgaoRg),
      'dataEmissaoRg': serializer.toJson<DateTime?>(dataEmissaoRg),
      'sexo': serializer.toJson<String?>(sexo),
      'raca': serializer.toJson<String?>(raca),
      'nacionalidade': serializer.toJson<String?>(nacionalidade),
      'naturalidade': serializer.toJson<String?>(naturalidade),
      'nomePai': serializer.toJson<String?>(nomePai),
      'nomeMae': serializer.toJson<String?>(nomeMae),
    };
  }

  PessoaFisica copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idNivelFormacao = const Value.absent(),
          Value<int?> idEstadoCivil = const Value.absent(),
          Value<DateTime?> dataNascimento = const Value.absent(),
          Value<String?> cpf = const Value.absent(),
          Value<String?> rg = const Value.absent(),
          Value<String?> orgaoRg = const Value.absent(),
          Value<DateTime?> dataEmissaoRg = const Value.absent(),
          Value<String?> sexo = const Value.absent(),
          Value<String?> raca = const Value.absent(),
          Value<String?> nacionalidade = const Value.absent(),
          Value<String?> naturalidade = const Value.absent(),
          Value<String?> nomePai = const Value.absent(),
          Value<String?> nomeMae = const Value.absent()}) =>
      PessoaFisica(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idNivelFormacao: idNivelFormacao.present
            ? idNivelFormacao.value
            : this.idNivelFormacao,
        idEstadoCivil:
            idEstadoCivil.present ? idEstadoCivil.value : this.idEstadoCivil,
        dataNascimento:
            dataNascimento.present ? dataNascimento.value : this.dataNascimento,
        cpf: cpf.present ? cpf.value : this.cpf,
        rg: rg.present ? rg.value : this.rg,
        orgaoRg: orgaoRg.present ? orgaoRg.value : this.orgaoRg,
        dataEmissaoRg:
            dataEmissaoRg.present ? dataEmissaoRg.value : this.dataEmissaoRg,
        sexo: sexo.present ? sexo.value : this.sexo,
        raca: raca.present ? raca.value : this.raca,
        nacionalidade:
            nacionalidade.present ? nacionalidade.value : this.nacionalidade,
        naturalidade:
            naturalidade.present ? naturalidade.value : this.naturalidade,
        nomePai: nomePai.present ? nomePai.value : this.nomePai,
        nomeMae: nomeMae.present ? nomeMae.value : this.nomeMae,
      );
  @override
  String toString() {
    return (StringBuffer('PessoaFisica(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idNivelFormacao: $idNivelFormacao, ')
          ..write('idEstadoCivil: $idEstadoCivil, ')
          ..write('dataNascimento: $dataNascimento, ')
          ..write('cpf: $cpf, ')
          ..write('rg: $rg, ')
          ..write('orgaoRg: $orgaoRg, ')
          ..write('dataEmissaoRg: $dataEmissaoRg, ')
          ..write('sexo: $sexo, ')
          ..write('raca: $raca, ')
          ..write('nacionalidade: $nacionalidade, ')
          ..write('naturalidade: $naturalidade, ')
          ..write('nomePai: $nomePai, ')
          ..write('nomeMae: $nomeMae')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      idNivelFormacao,
      idEstadoCivil,
      dataNascimento,
      cpf,
      rg,
      orgaoRg,
      dataEmissaoRg,
      sexo,
      raca,
      nacionalidade,
      naturalidade,
      nomePai,
      nomeMae);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PessoaFisica &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.idNivelFormacao == this.idNivelFormacao &&
          other.idEstadoCivil == this.idEstadoCivil &&
          other.dataNascimento == this.dataNascimento &&
          other.cpf == this.cpf &&
          other.rg == this.rg &&
          other.orgaoRg == this.orgaoRg &&
          other.dataEmissaoRg == this.dataEmissaoRg &&
          other.sexo == this.sexo &&
          other.raca == this.raca &&
          other.nacionalidade == this.nacionalidade &&
          other.naturalidade == this.naturalidade &&
          other.nomePai == this.nomePai &&
          other.nomeMae == this.nomeMae);
}

class PessoaFisicasCompanion extends UpdateCompanion<PessoaFisica> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<int?> idNivelFormacao;
  final Value<int?> idEstadoCivil;
  final Value<DateTime?> dataNascimento;
  final Value<String?> cpf;
  final Value<String?> rg;
  final Value<String?> orgaoRg;
  final Value<DateTime?> dataEmissaoRg;
  final Value<String?> sexo;
  final Value<String?> raca;
  final Value<String?> nacionalidade;
  final Value<String?> naturalidade;
  final Value<String?> nomePai;
  final Value<String?> nomeMae;
  const PessoaFisicasCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idNivelFormacao = const Value.absent(),
    this.idEstadoCivil = const Value.absent(),
    this.dataNascimento = const Value.absent(),
    this.cpf = const Value.absent(),
    this.rg = const Value.absent(),
    this.orgaoRg = const Value.absent(),
    this.dataEmissaoRg = const Value.absent(),
    this.sexo = const Value.absent(),
    this.raca = const Value.absent(),
    this.nacionalidade = const Value.absent(),
    this.naturalidade = const Value.absent(),
    this.nomePai = const Value.absent(),
    this.nomeMae = const Value.absent(),
  });
  PessoaFisicasCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idNivelFormacao = const Value.absent(),
    this.idEstadoCivil = const Value.absent(),
    this.dataNascimento = const Value.absent(),
    this.cpf = const Value.absent(),
    this.rg = const Value.absent(),
    this.orgaoRg = const Value.absent(),
    this.dataEmissaoRg = const Value.absent(),
    this.sexo = const Value.absent(),
    this.raca = const Value.absent(),
    this.nacionalidade = const Value.absent(),
    this.naturalidade = const Value.absent(),
    this.nomePai = const Value.absent(),
    this.nomeMae = const Value.absent(),
  });
  static Insertable<PessoaFisica> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<int>? idNivelFormacao,
    Expression<int>? idEstadoCivil,
    Expression<DateTime>? dataNascimento,
    Expression<String>? cpf,
    Expression<String>? rg,
    Expression<String>? orgaoRg,
    Expression<DateTime>? dataEmissaoRg,
    Expression<String>? sexo,
    Expression<String>? raca,
    Expression<String>? nacionalidade,
    Expression<String>? naturalidade,
    Expression<String>? nomePai,
    Expression<String>? nomeMae,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idNivelFormacao != null) 'id_nivel_formacao': idNivelFormacao,
      if (idEstadoCivil != null) 'id_estado_civil': idEstadoCivil,
      if (dataNascimento != null) 'data_nascimento': dataNascimento,
      if (cpf != null) 'cpf': cpf,
      if (rg != null) 'rg': rg,
      if (orgaoRg != null) 'orgao_rg': orgaoRg,
      if (dataEmissaoRg != null) 'data_emissao_rg': dataEmissaoRg,
      if (sexo != null) 'sexo': sexo,
      if (raca != null) 'raca': raca,
      if (nacionalidade != null) 'nacionalidade': nacionalidade,
      if (naturalidade != null) 'naturalidade': naturalidade,
      if (nomePai != null) 'nome_pai': nomePai,
      if (nomeMae != null) 'nome_mae': nomeMae,
    });
  }

  PessoaFisicasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<int?>? idNivelFormacao,
      Value<int?>? idEstadoCivil,
      Value<DateTime?>? dataNascimento,
      Value<String?>? cpf,
      Value<String?>? rg,
      Value<String?>? orgaoRg,
      Value<DateTime?>? dataEmissaoRg,
      Value<String?>? sexo,
      Value<String?>? raca,
      Value<String?>? nacionalidade,
      Value<String?>? naturalidade,
      Value<String?>? nomePai,
      Value<String?>? nomeMae}) {
    return PessoaFisicasCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      idNivelFormacao: idNivelFormacao ?? this.idNivelFormacao,
      idEstadoCivil: idEstadoCivil ?? this.idEstadoCivil,
      dataNascimento: dataNascimento ?? this.dataNascimento,
      cpf: cpf ?? this.cpf,
      rg: rg ?? this.rg,
      orgaoRg: orgaoRg ?? this.orgaoRg,
      dataEmissaoRg: dataEmissaoRg ?? this.dataEmissaoRg,
      sexo: sexo ?? this.sexo,
      raca: raca ?? this.raca,
      nacionalidade: nacionalidade ?? this.nacionalidade,
      naturalidade: naturalidade ?? this.naturalidade,
      nomePai: nomePai ?? this.nomePai,
      nomeMae: nomeMae ?? this.nomeMae,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idNivelFormacao.present) {
      map['id_nivel_formacao'] = Variable<int>(idNivelFormacao.value);
    }
    if (idEstadoCivil.present) {
      map['id_estado_civil'] = Variable<int>(idEstadoCivil.value);
    }
    if (dataNascimento.present) {
      map['data_nascimento'] = Variable<DateTime>(dataNascimento.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (rg.present) {
      map['rg'] = Variable<String>(rg.value);
    }
    if (orgaoRg.present) {
      map['orgao_rg'] = Variable<String>(orgaoRg.value);
    }
    if (dataEmissaoRg.present) {
      map['data_emissao_rg'] = Variable<DateTime>(dataEmissaoRg.value);
    }
    if (sexo.present) {
      map['sexo'] = Variable<String>(sexo.value);
    }
    if (raca.present) {
      map['raca'] = Variable<String>(raca.value);
    }
    if (nacionalidade.present) {
      map['nacionalidade'] = Variable<String>(nacionalidade.value);
    }
    if (naturalidade.present) {
      map['naturalidade'] = Variable<String>(naturalidade.value);
    }
    if (nomePai.present) {
      map['nome_pai'] = Variable<String>(nomePai.value);
    }
    if (nomeMae.present) {
      map['nome_mae'] = Variable<String>(nomeMae.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoaFisicasCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idNivelFormacao: $idNivelFormacao, ')
          ..write('idEstadoCivil: $idEstadoCivil, ')
          ..write('dataNascimento: $dataNascimento, ')
          ..write('cpf: $cpf, ')
          ..write('rg: $rg, ')
          ..write('orgaoRg: $orgaoRg, ')
          ..write('dataEmissaoRg: $dataEmissaoRg, ')
          ..write('sexo: $sexo, ')
          ..write('raca: $raca, ')
          ..write('nacionalidade: $nacionalidade, ')
          ..write('naturalidade: $naturalidade, ')
          ..write('nomePai: $nomePai, ')
          ..write('nomeMae: $nomeMae')
          ..write(')'))
        .toString();
  }
}

class $VendaDetalhesTable extends VendaDetalhes
    with TableInfo<$VendaDetalhesTable, VendaDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VendaDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendaCabecalhoMeta =
      const VerificationMeta('idVendaCabecalho');
  @override
  late final GeneratedColumn<int> idVendaCabecalho = GeneratedColumn<int>(
      'id_venda_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMeta =
      const VerificationMeta('idProduto');
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
      'id_produto', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<int> quantidade = GeneratedColumn<int>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorUnitarioMeta =
      const VerificationMeta('valorUnitario');
  @override
  late final GeneratedColumn<double> valorUnitario = GeneratedColumn<double>(
      'valor_unitario', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idVendaCabecalho,
        idProduto,
        quantidade,
        valorUnitario,
        taxaDesconto,
        valorDesconto,
        valorTotal
      ];
  @override
  String get aliasedName => _alias ?? 'venda_detalhe';
  @override
  String get actualTableName => 'venda_detalhe';
  @override
  VerificationContext validateIntegrity(Insertable<VendaDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_venda_cabecalho')) {
      context.handle(
          _idVendaCabecalhoMeta,
          idVendaCabecalho.isAcceptableOrUnknown(
              data['id_venda_cabecalho']!, _idVendaCabecalhoMeta));
    }
    if (data.containsKey('id_produto')) {
      context.handle(_idProdutoMeta,
          idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    if (data.containsKey('valor_unitario')) {
      context.handle(
          _valorUnitarioMeta,
          valorUnitario.isAcceptableOrUnknown(
              data['valor_unitario']!, _valorUnitarioMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  VendaDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VendaDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idVendaCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_venda_cabecalho']),
      idProduto: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}quantidade']),
      valorUnitario: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_unitario']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
    );
  }

  @override
  $VendaDetalhesTable createAlias(String alias) {
    return $VendaDetalhesTable(attachedDatabase, alias);
  }
}

class VendaDetalhe extends DataClass implements Insertable<VendaDetalhe> {
  final int? id;
  final int? idVendaCabecalho;
  final int? idProduto;
  final int? quantidade;
  final double? valorUnitario;
  final double? taxaDesconto;
  final double? valorDesconto;
  final double? valorTotal;
  const VendaDetalhe(
      {this.id,
      this.idVendaCabecalho,
      this.idProduto,
      this.quantidade,
      this.valorUnitario,
      this.taxaDesconto,
      this.valorDesconto,
      this.valorTotal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idVendaCabecalho != null) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<int>(quantidade);
    }
    if (!nullToAbsent || valorUnitario != null) {
      map['valor_unitario'] = Variable<double>(valorUnitario);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    return map;
  }

  factory VendaDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VendaDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idVendaCabecalho: serializer.fromJson<int?>(json['idVendaCabecalho']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      quantidade: serializer.fromJson<int?>(json['quantidade']),
      valorUnitario: serializer.fromJson<double?>(json['valorUnitario']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idVendaCabecalho': serializer.toJson<int?>(idVendaCabecalho),
      'idProduto': serializer.toJson<int?>(idProduto),
      'quantidade': serializer.toJson<int?>(quantidade),
      'valorUnitario': serializer.toJson<double?>(valorUnitario),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorTotal': serializer.toJson<double?>(valorTotal),
    };
  }

  VendaDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idVendaCabecalho = const Value.absent(),
          Value<int?> idProduto = const Value.absent(),
          Value<int?> quantidade = const Value.absent(),
          Value<double?> valorUnitario = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorTotal = const Value.absent()}) =>
      VendaDetalhe(
        id: id.present ? id.value : this.id,
        idVendaCabecalho: idVendaCabecalho.present
            ? idVendaCabecalho.value
            : this.idVendaCabecalho,
        idProduto: idProduto.present ? idProduto.value : this.idProduto,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
        valorUnitario:
            valorUnitario.present ? valorUnitario.value : this.valorUnitario,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
      );
  @override
  String toString() {
    return (StringBuffer('VendaDetalhe(')
          ..write('id: $id, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idVendaCabecalho, idProduto, quantidade,
      valorUnitario, taxaDesconto, valorDesconto, valorTotal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VendaDetalhe &&
          other.id == this.id &&
          other.idVendaCabecalho == this.idVendaCabecalho &&
          other.idProduto == this.idProduto &&
          other.quantidade == this.quantidade &&
          other.valorUnitario == this.valorUnitario &&
          other.taxaDesconto == this.taxaDesconto &&
          other.valorDesconto == this.valorDesconto &&
          other.valorTotal == this.valorTotal);
}

class VendaDetalhesCompanion extends UpdateCompanion<VendaDetalhe> {
  final Value<int?> id;
  final Value<int?> idVendaCabecalho;
  final Value<int?> idProduto;
  final Value<int?> quantidade;
  final Value<double?> valorUnitario;
  final Value<double?> taxaDesconto;
  final Value<double?> valorDesconto;
  final Value<double?> valorTotal;
  const VendaDetalhesCompanion({
    this.id = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
  });
  VendaDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
  });
  static Insertable<VendaDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idVendaCabecalho,
    Expression<int>? idProduto,
    Expression<int>? quantidade,
    Expression<double>? valorUnitario,
    Expression<double>? taxaDesconto,
    Expression<double>? valorDesconto,
    Expression<double>? valorTotal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idVendaCabecalho != null) 'id_venda_cabecalho': idVendaCabecalho,
      if (idProduto != null) 'id_produto': idProduto,
      if (quantidade != null) 'quantidade': quantidade,
      if (valorUnitario != null) 'valor_unitario': valorUnitario,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorTotal != null) 'valor_total': valorTotal,
    });
  }

  VendaDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idVendaCabecalho,
      Value<int?>? idProduto,
      Value<int?>? quantidade,
      Value<double?>? valorUnitario,
      Value<double?>? taxaDesconto,
      Value<double?>? valorDesconto,
      Value<double?>? valorTotal}) {
    return VendaDetalhesCompanion(
      id: id ?? this.id,
      idVendaCabecalho: idVendaCabecalho ?? this.idVendaCabecalho,
      idProduto: idProduto ?? this.idProduto,
      quantidade: quantidade ?? this.quantidade,
      valorUnitario: valorUnitario ?? this.valorUnitario,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorTotal: valorTotal ?? this.valorTotal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idVendaCabecalho.present) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<int>(quantidade.value);
    }
    if (valorUnitario.present) {
      map['valor_unitario'] = Variable<double>(valorUnitario.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VendaDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal')
          ..write(')'))
        .toString();
  }
}

class $FornecedorsTable extends Fornecedors
    with TableInfo<$FornecedorsTable, Fornecedor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FornecedorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
      'desde', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idPessoa, desde, observacao];
  @override
  String get aliasedName => _alias ?? 'fornecedor';
  @override
  String get actualTableName => 'fornecedor';
  @override
  VerificationContext validateIntegrity(Insertable<Fornecedor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('desde')) {
      context.handle(
          _desdeMeta, desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Fornecedor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Fornecedor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      desde: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}desde']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $FornecedorsTable createAlias(String alias) {
    return $FornecedorsTable(attachedDatabase, alias);
  }
}

class Fornecedor extends DataClass implements Insertable<Fornecedor> {
  final int? id;
  final int? idPessoa;
  final DateTime? desde;
  final String? observacao;
  const Fornecedor({this.id, this.idPessoa, this.desde, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory Fornecedor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Fornecedor(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'desde': serializer.toJson<DateTime?>(desde),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  Fornecedor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<DateTime?> desde = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      Fornecedor(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        desde: desde.present ? desde.value : this.desde,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('Fornecedor(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('desde: $desde, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, desde, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Fornecedor &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.desde == this.desde &&
          other.observacao == this.observacao);
}

class FornecedorsCompanion extends UpdateCompanion<Fornecedor> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<DateTime?> desde;
  final Value<String?> observacao;
  const FornecedorsCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.desde = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  FornecedorsCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.desde = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<Fornecedor> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<DateTime>? desde,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (desde != null) 'desde': desde,
      if (observacao != null) 'observacao': observacao,
    });
  }

  FornecedorsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<DateTime?>? desde,
      Value<String?>? observacao}) {
    return FornecedorsCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      desde: desde ?? this.desde,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FornecedorsCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('desde: $desde, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $PessoaEnderecosTable extends PessoaEnderecos
    with TableInfo<$PessoaEnderecosTable, PessoaEndereco> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoaEnderecosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _principalMeta =
      const VerificationMeta('principal');
  @override
  late final GeneratedColumn<String> principal = GeneratedColumn<String>(
      'principal', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entregaMeta =
      const VerificationMeta('entrega');
  @override
  late final GeneratedColumn<String> entrega = GeneratedColumn<String>(
      'entrega', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cobrancaMeta =
      const VerificationMeta('cobranca');
  @override
  late final GeneratedColumn<String> cobranca = GeneratedColumn<String>(
      'cobranca', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _correspondenciaMeta =
      const VerificationMeta('correspondencia');
  @override
  late final GeneratedColumn<String> correspondencia = GeneratedColumn<String>(
      'correspondencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        logradouro,
        numero,
        bairro,
        cidade,
        uf,
        cep,
        complemento,
        principal,
        entrega,
        cobranca,
        correspondencia
      ];
  @override
  String get aliasedName => _alias ?? 'pessoa_endereco';
  @override
  String get actualTableName => 'pessoa_endereco';
  @override
  VerificationContext validateIntegrity(Insertable<PessoaEndereco> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('principal')) {
      context.handle(_principalMeta,
          principal.isAcceptableOrUnknown(data['principal']!, _principalMeta));
    }
    if (data.containsKey('entrega')) {
      context.handle(_entregaMeta,
          entrega.isAcceptableOrUnknown(data['entrega']!, _entregaMeta));
    }
    if (data.containsKey('cobranca')) {
      context.handle(_cobrancaMeta,
          cobranca.isAcceptableOrUnknown(data['cobranca']!, _cobrancaMeta));
    }
    if (data.containsKey('correspondencia')) {
      context.handle(
          _correspondenciaMeta,
          correspondencia.isAcceptableOrUnknown(
              data['correspondencia']!, _correspondenciaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PessoaEndereco map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PessoaEndereco(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      principal: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}principal']),
      entrega: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrega']),
      cobranca: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cobranca']),
      correspondencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}correspondencia']),
    );
  }

  @override
  $PessoaEnderecosTable createAlias(String alias) {
    return $PessoaEnderecosTable(attachedDatabase, alias);
  }
}

class PessoaEndereco extends DataClass implements Insertable<PessoaEndereco> {
  final int? id;
  final int? idPessoa;
  final String? logradouro;
  final String? numero;
  final String? bairro;
  final String? cidade;
  final String? uf;
  final String? cep;
  final String? complemento;
  final String? principal;
  final String? entrega;
  final String? cobranca;
  final String? correspondencia;
  const PessoaEndereco(
      {this.id,
      this.idPessoa,
      this.logradouro,
      this.numero,
      this.bairro,
      this.cidade,
      this.uf,
      this.cep,
      this.complemento,
      this.principal,
      this.entrega,
      this.cobranca,
      this.correspondencia});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || principal != null) {
      map['principal'] = Variable<String>(principal);
    }
    if (!nullToAbsent || entrega != null) {
      map['entrega'] = Variable<String>(entrega);
    }
    if (!nullToAbsent || cobranca != null) {
      map['cobranca'] = Variable<String>(cobranca);
    }
    if (!nullToAbsent || correspondencia != null) {
      map['correspondencia'] = Variable<String>(correspondencia);
    }
    return map;
  }

  factory PessoaEndereco.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PessoaEndereco(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      principal: serializer.fromJson<String?>(json['principal']),
      entrega: serializer.fromJson<String?>(json['entrega']),
      cobranca: serializer.fromJson<String?>(json['cobranca']),
      correspondencia: serializer.fromJson<String?>(json['correspondencia']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'complemento': serializer.toJson<String?>(complemento),
      'principal': serializer.toJson<String?>(principal),
      'entrega': serializer.toJson<String?>(entrega),
      'cobranca': serializer.toJson<String?>(cobranca),
      'correspondencia': serializer.toJson<String?>(correspondencia),
    };
  }

  PessoaEndereco copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> principal = const Value.absent(),
          Value<String?> entrega = const Value.absent(),
          Value<String?> cobranca = const Value.absent(),
          Value<String?> correspondencia = const Value.absent()}) =>
      PessoaEndereco(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        uf: uf.present ? uf.value : this.uf,
        cep: cep.present ? cep.value : this.cep,
        complemento: complemento.present ? complemento.value : this.complemento,
        principal: principal.present ? principal.value : this.principal,
        entrega: entrega.present ? entrega.value : this.entrega,
        cobranca: cobranca.present ? cobranca.value : this.cobranca,
        correspondencia: correspondencia.present
            ? correspondencia.value
            : this.correspondencia,
      );
  @override
  String toString() {
    return (StringBuffer('PessoaEndereco(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('complemento: $complemento, ')
          ..write('principal: $principal, ')
          ..write('entrega: $entrega, ')
          ..write('cobranca: $cobranca, ')
          ..write('correspondencia: $correspondencia')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      logradouro,
      numero,
      bairro,
      cidade,
      uf,
      cep,
      complemento,
      principal,
      entrega,
      cobranca,
      correspondencia);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PessoaEndereco &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.complemento == this.complemento &&
          other.principal == this.principal &&
          other.entrega == this.entrega &&
          other.cobranca == this.cobranca &&
          other.correspondencia == this.correspondencia);
}

class PessoaEnderecosCompanion extends UpdateCompanion<PessoaEndereco> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<String?> complemento;
  final Value<String?> principal;
  final Value<String?> entrega;
  final Value<String?> cobranca;
  final Value<String?> correspondencia;
  const PessoaEnderecosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.complemento = const Value.absent(),
    this.principal = const Value.absent(),
    this.entrega = const Value.absent(),
    this.cobranca = const Value.absent(),
    this.correspondencia = const Value.absent(),
  });
  PessoaEnderecosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.complemento = const Value.absent(),
    this.principal = const Value.absent(),
    this.entrega = const Value.absent(),
    this.cobranca = const Value.absent(),
    this.correspondencia = const Value.absent(),
  });
  static Insertable<PessoaEndereco> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<String>? complemento,
    Expression<String>? principal,
    Expression<String>? entrega,
    Expression<String>? cobranca,
    Expression<String>? correspondencia,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (complemento != null) 'complemento': complemento,
      if (principal != null) 'principal': principal,
      if (entrega != null) 'entrega': entrega,
      if (cobranca != null) 'cobranca': cobranca,
      if (correspondencia != null) 'correspondencia': correspondencia,
    });
  }

  PessoaEnderecosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? uf,
      Value<String?>? cep,
      Value<String?>? complemento,
      Value<String?>? principal,
      Value<String?>? entrega,
      Value<String?>? cobranca,
      Value<String?>? correspondencia}) {
    return PessoaEnderecosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      complemento: complemento ?? this.complemento,
      principal: principal ?? this.principal,
      entrega: entrega ?? this.entrega,
      cobranca: cobranca ?? this.cobranca,
      correspondencia: correspondencia ?? this.correspondencia,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (principal.present) {
      map['principal'] = Variable<String>(principal.value);
    }
    if (entrega.present) {
      map['entrega'] = Variable<String>(entrega.value);
    }
    if (cobranca.present) {
      map['cobranca'] = Variable<String>(cobranca.value);
    }
    if (correspondencia.present) {
      map['correspondencia'] = Variable<String>(correspondencia.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoaEnderecosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('complemento: $complemento, ')
          ..write('principal: $principal, ')
          ..write('entrega: $entrega, ')
          ..write('cobranca: $cobranca, ')
          ..write('correspondencia: $correspondencia')
          ..write(')'))
        .toString();
  }
}

class $AtendimentosTable extends Atendimentos
    with TableInfo<$AtendimentosTable, Atendimento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AtendimentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'ID', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _talaoMeta = const VerificationMeta('talao');
  @override
  late final GeneratedColumn<int> talao = GeneratedColumn<int>(
      'talao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataAtendimentoMeta =
      const VerificationMeta('dataAtendimento');
  @override
  late final GeneratedColumn<DateTime> dataAtendimento =
      GeneratedColumn<DateTime>('data_atendimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataRetornoMeta =
      const VerificationMeta('dataRetorno');
  @override
  late final GeneratedColumn<DateTime> dataRetorno = GeneratedColumn<DateTime>(
      'data_retorno', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorEsfericoOdMeta =
      const VerificationMeta('valorEsfericoOd');
  @override
  late final GeneratedColumn<double> valorEsfericoOd = GeneratedColumn<double>(
      'valor_esferico_od', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorEsfericoOeMeta =
      const VerificationMeta('valorEsfericoOe');
  @override
  late final GeneratedColumn<double> valorEsfericoOe = GeneratedColumn<double>(
      'valor_esferico_oe', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCilindricoOdMeta =
      const VerificationMeta('valorCilindricoOd');
  @override
  late final GeneratedColumn<int> valorCilindricoOd = GeneratedColumn<int>(
      'valor_cilindrico_od', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorCilindricoOeMeta =
      const VerificationMeta('valorCilindricoOe');
  @override
  late final GeneratedColumn<int> valorCilindricoOe = GeneratedColumn<int>(
      'valor_cilindrico_oe', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _posicaoEixoOdMeta =
      const VerificationMeta('posicaoEixoOd');
  @override
  late final GeneratedColumn<int> posicaoEixoOd = GeneratedColumn<int>(
      'posicao_eixo_od', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _posicaoEixoOeMeta =
      const VerificationMeta('posicaoEixoOe');
  @override
  late final GeneratedColumn<int> posicaoEixoOe = GeneratedColumn<int>(
      'posicao_eixo_oe', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _distanciaNasoPupilarOdMeta =
      const VerificationMeta('distanciaNasoPupilarOd');
  @override
  late final GeneratedColumn<double> distanciaNasoPupilarOd =
      GeneratedColumn<double>('distancia_naso_pupilar_od', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _distanciaNasoPupilarOeMeta =
      const VerificationMeta('distanciaNasoPupilarOe');
  @override
  late final GeneratedColumn<double> distanciaNasoPupilarOe =
      GeneratedColumn<double>('distancia_naso_pupilar_oe', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _acuidadeVisualLongeOdMeta =
      const VerificationMeta('acuidadeVisualLongeOd');
  @override
  late final GeneratedColumn<String> acuidadeVisualLongeOd =
      GeneratedColumn<String>('acuidade_visual_longe_od', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 6),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _acuidadeVisualLongeOeMeta =
      const VerificationMeta('acuidadeVisualLongeOe');
  @override
  late final GeneratedColumn<String> acuidadeVisualLongeOe =
      GeneratedColumn<String>('acuidade_visual_longe_oe', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 6),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _adicaoMeta = const VerificationMeta('adicao');
  @override
  late final GeneratedColumn<double> adicao = GeneratedColumn<double>(
      'adicao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _acuidadeVisualPertoOdMeta =
      const VerificationMeta('acuidadeVisualPertoOd');
  @override
  late final GeneratedColumn<String> acuidadeVisualPertoOd =
      GeneratedColumn<String>('acuidade_visual_perto_od', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _acuidadeVisualPertoOeMeta =
      const VerificationMeta('acuidadeVisualPertoOe');
  @override
  late final GeneratedColumn<String> acuidadeVisualPertoOe =
      GeneratedColumn<String>('acuidade_visual_perto_oe', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _examinadorMeta =
      const VerificationMeta('examinador');
  @override
  late final GeneratedColumn<String> examinador = GeneratedColumn<String>(
      'examinador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 500),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        talao,
        dataAtendimento,
        dataRetorno,
        valorEsfericoOd,
        valorEsfericoOe,
        valorCilindricoOd,
        valorCilindricoOe,
        posicaoEixoOd,
        posicaoEixoOe,
        distanciaNasoPupilarOd,
        distanciaNasoPupilarOe,
        acuidadeVisualLongeOd,
        acuidadeVisualLongeOe,
        adicao,
        acuidadeVisualPertoOd,
        acuidadeVisualPertoOe,
        examinador,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? 'atendimento';
  @override
  String get actualTableName => 'atendimento';
  @override
  VerificationContext validateIntegrity(Insertable<Atendimento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('ID')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['ID']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('talao')) {
      context.handle(
          _talaoMeta, talao.isAcceptableOrUnknown(data['talao']!, _talaoMeta));
    }
    if (data.containsKey('data_atendimento')) {
      context.handle(
          _dataAtendimentoMeta,
          dataAtendimento.isAcceptableOrUnknown(
              data['data_atendimento']!, _dataAtendimentoMeta));
    }
    if (data.containsKey('data_retorno')) {
      context.handle(
          _dataRetornoMeta,
          dataRetorno.isAcceptableOrUnknown(
              data['data_retorno']!, _dataRetornoMeta));
    }
    if (data.containsKey('valor_esferico_od')) {
      context.handle(
          _valorEsfericoOdMeta,
          valorEsfericoOd.isAcceptableOrUnknown(
              data['valor_esferico_od']!, _valorEsfericoOdMeta));
    }
    if (data.containsKey('valor_esferico_oe')) {
      context.handle(
          _valorEsfericoOeMeta,
          valorEsfericoOe.isAcceptableOrUnknown(
              data['valor_esferico_oe']!, _valorEsfericoOeMeta));
    }
    if (data.containsKey('valor_cilindrico_od')) {
      context.handle(
          _valorCilindricoOdMeta,
          valorCilindricoOd.isAcceptableOrUnknown(
              data['valor_cilindrico_od']!, _valorCilindricoOdMeta));
    }
    if (data.containsKey('valor_cilindrico_oe')) {
      context.handle(
          _valorCilindricoOeMeta,
          valorCilindricoOe.isAcceptableOrUnknown(
              data['valor_cilindrico_oe']!, _valorCilindricoOeMeta));
    }
    if (data.containsKey('posicao_eixo_od')) {
      context.handle(
          _posicaoEixoOdMeta,
          posicaoEixoOd.isAcceptableOrUnknown(
              data['posicao_eixo_od']!, _posicaoEixoOdMeta));
    }
    if (data.containsKey('posicao_eixo_oe')) {
      context.handle(
          _posicaoEixoOeMeta,
          posicaoEixoOe.isAcceptableOrUnknown(
              data['posicao_eixo_oe']!, _posicaoEixoOeMeta));
    }
    if (data.containsKey('distancia_naso_pupilar_od')) {
      context.handle(
          _distanciaNasoPupilarOdMeta,
          distanciaNasoPupilarOd.isAcceptableOrUnknown(
              data['distancia_naso_pupilar_od']!, _distanciaNasoPupilarOdMeta));
    }
    if (data.containsKey('distancia_naso_pupilar_oe')) {
      context.handle(
          _distanciaNasoPupilarOeMeta,
          distanciaNasoPupilarOe.isAcceptableOrUnknown(
              data['distancia_naso_pupilar_oe']!, _distanciaNasoPupilarOeMeta));
    }
    if (data.containsKey('acuidade_visual_longe_od')) {
      context.handle(
          _acuidadeVisualLongeOdMeta,
          acuidadeVisualLongeOd.isAcceptableOrUnknown(
              data['acuidade_visual_longe_od']!, _acuidadeVisualLongeOdMeta));
    }
    if (data.containsKey('acuidade_visual_longe_oe')) {
      context.handle(
          _acuidadeVisualLongeOeMeta,
          acuidadeVisualLongeOe.isAcceptableOrUnknown(
              data['acuidade_visual_longe_oe']!, _acuidadeVisualLongeOeMeta));
    }
    if (data.containsKey('adicao')) {
      context.handle(_adicaoMeta,
          adicao.isAcceptableOrUnknown(data['adicao']!, _adicaoMeta));
    }
    if (data.containsKey('acuidade_visual_perto_od')) {
      context.handle(
          _acuidadeVisualPertoOdMeta,
          acuidadeVisualPertoOd.isAcceptableOrUnknown(
              data['acuidade_visual_perto_od']!, _acuidadeVisualPertoOdMeta));
    }
    if (data.containsKey('acuidade_visual_perto_oe')) {
      context.handle(
          _acuidadeVisualPertoOeMeta,
          acuidadeVisualPertoOe.isAcceptableOrUnknown(
              data['acuidade_visual_perto_oe']!, _acuidadeVisualPertoOeMeta));
    }
    if (data.containsKey('examinador')) {
      context.handle(
          _examinadorMeta,
          examinador.isAcceptableOrUnknown(
              data['examinador']!, _examinadorMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Atendimento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Atendimento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}ID']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      talao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}talao']),
      dataAtendimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_atendimento']),
      dataRetorno: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_retorno']),
      valorEsfericoOd: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_esferico_od']),
      valorEsfericoOe: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_esferico_oe']),
      valorCilindricoOd: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}valor_cilindrico_od']),
      valorCilindricoOe: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}valor_cilindrico_oe']),
      posicaoEixoOd: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}posicao_eixo_od']),
      posicaoEixoOe: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}posicao_eixo_oe']),
      distanciaNasoPupilarOd: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}distancia_naso_pupilar_od']),
      distanciaNasoPupilarOe: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}distancia_naso_pupilar_oe']),
      acuidadeVisualLongeOd: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}acuidade_visual_longe_od']),
      acuidadeVisualLongeOe: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}acuidade_visual_longe_oe']),
      adicao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}adicao']),
      acuidadeVisualPertoOd: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}acuidade_visual_perto_od']),
      acuidadeVisualPertoOe: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}acuidade_visual_perto_oe']),
      examinador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}examinador']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $AtendimentosTable createAlias(String alias) {
    return $AtendimentosTable(attachedDatabase, alias);
  }
}

class Atendimento extends DataClass implements Insertable<Atendimento> {
  final int? id;
  final int? idPessoa;
  final int? talao;
  final DateTime? dataAtendimento;
  final DateTime? dataRetorno;
  final double? valorEsfericoOd;
  final double? valorEsfericoOe;
  final int? valorCilindricoOd;
  final int? valorCilindricoOe;
  final int? posicaoEixoOd;
  final int? posicaoEixoOe;
  final double? distanciaNasoPupilarOd;
  final double? distanciaNasoPupilarOe;
  final String? acuidadeVisualLongeOd;
  final String? acuidadeVisualLongeOe;
  final double? adicao;
  final String? acuidadeVisualPertoOd;
  final String? acuidadeVisualPertoOe;
  final String? examinador;
  final String? observacao;
  const Atendimento(
      {this.id,
      this.idPessoa,
      this.talao,
      this.dataAtendimento,
      this.dataRetorno,
      this.valorEsfericoOd,
      this.valorEsfericoOe,
      this.valorCilindricoOd,
      this.valorCilindricoOe,
      this.posicaoEixoOd,
      this.posicaoEixoOe,
      this.distanciaNasoPupilarOd,
      this.distanciaNasoPupilarOe,
      this.acuidadeVisualLongeOd,
      this.acuidadeVisualLongeOe,
      this.adicao,
      this.acuidadeVisualPertoOd,
      this.acuidadeVisualPertoOe,
      this.examinador,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['ID'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || talao != null) {
      map['talao'] = Variable<int>(talao);
    }
    if (!nullToAbsent || dataAtendimento != null) {
      map['data_atendimento'] = Variable<DateTime>(dataAtendimento);
    }
    if (!nullToAbsent || dataRetorno != null) {
      map['data_retorno'] = Variable<DateTime>(dataRetorno);
    }
    if (!nullToAbsent || valorEsfericoOd != null) {
      map['valor_esferico_od'] = Variable<double>(valorEsfericoOd);
    }
    if (!nullToAbsent || valorEsfericoOe != null) {
      map['valor_esferico_oe'] = Variable<double>(valorEsfericoOe);
    }
    if (!nullToAbsent || valorCilindricoOd != null) {
      map['valor_cilindrico_od'] = Variable<int>(valorCilindricoOd);
    }
    if (!nullToAbsent || valorCilindricoOe != null) {
      map['valor_cilindrico_oe'] = Variable<int>(valorCilindricoOe);
    }
    if (!nullToAbsent || posicaoEixoOd != null) {
      map['posicao_eixo_od'] = Variable<int>(posicaoEixoOd);
    }
    if (!nullToAbsent || posicaoEixoOe != null) {
      map['posicao_eixo_oe'] = Variable<int>(posicaoEixoOe);
    }
    if (!nullToAbsent || distanciaNasoPupilarOd != null) {
      map['distancia_naso_pupilar_od'] =
          Variable<double>(distanciaNasoPupilarOd);
    }
    if (!nullToAbsent || distanciaNasoPupilarOe != null) {
      map['distancia_naso_pupilar_oe'] =
          Variable<double>(distanciaNasoPupilarOe);
    }
    if (!nullToAbsent || acuidadeVisualLongeOd != null) {
      map['acuidade_visual_longe_od'] = Variable<String>(acuidadeVisualLongeOd);
    }
    if (!nullToAbsent || acuidadeVisualLongeOe != null) {
      map['acuidade_visual_longe_oe'] = Variable<String>(acuidadeVisualLongeOe);
    }
    if (!nullToAbsent || adicao != null) {
      map['adicao'] = Variable<double>(adicao);
    }
    if (!nullToAbsent || acuidadeVisualPertoOd != null) {
      map['acuidade_visual_perto_od'] = Variable<String>(acuidadeVisualPertoOd);
    }
    if (!nullToAbsent || acuidadeVisualPertoOe != null) {
      map['acuidade_visual_perto_oe'] = Variable<String>(acuidadeVisualPertoOe);
    }
    if (!nullToAbsent || examinador != null) {
      map['examinador'] = Variable<String>(examinador);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory Atendimento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Atendimento(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      talao: serializer.fromJson<int?>(json['talao']),
      dataAtendimento: serializer.fromJson<DateTime?>(json['dataAtendimento']),
      dataRetorno: serializer.fromJson<DateTime?>(json['dataRetorno']),
      valorEsfericoOd: serializer.fromJson<double?>(json['valorEsfericoOd']),
      valorEsfericoOe: serializer.fromJson<double?>(json['valorEsfericoOe']),
      valorCilindricoOd: serializer.fromJson<int?>(json['valorCilindricoOd']),
      valorCilindricoOe: serializer.fromJson<int?>(json['valorCilindricoOe']),
      posicaoEixoOd: serializer.fromJson<int?>(json['posicaoEixoOd']),
      posicaoEixoOe: serializer.fromJson<int?>(json['posicaoEixoOe']),
      distanciaNasoPupilarOd:
          serializer.fromJson<double?>(json['distanciaNasoPupilarOd']),
      distanciaNasoPupilarOe:
          serializer.fromJson<double?>(json['distanciaNasoPupilarOe']),
      acuidadeVisualLongeOd:
          serializer.fromJson<String?>(json['acuidadeVisualLongeOd']),
      acuidadeVisualLongeOe:
          serializer.fromJson<String?>(json['acuidadeVisualLongeOe']),
      adicao: serializer.fromJson<double?>(json['adicao']),
      acuidadeVisualPertoOd:
          serializer.fromJson<String?>(json['acuidadeVisualPertoOd']),
      acuidadeVisualPertoOe:
          serializer.fromJson<String?>(json['acuidadeVisualPertoOe']),
      examinador: serializer.fromJson<String?>(json['examinador']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'talao': serializer.toJson<int?>(talao),
      'dataAtendimento': serializer.toJson<DateTime?>(dataAtendimento),
      'dataRetorno': serializer.toJson<DateTime?>(dataRetorno),
      'valorEsfericoOd': serializer.toJson<double?>(valorEsfericoOd),
      'valorEsfericoOe': serializer.toJson<double?>(valorEsfericoOe),
      'valorCilindricoOd': serializer.toJson<int?>(valorCilindricoOd),
      'valorCilindricoOe': serializer.toJson<int?>(valorCilindricoOe),
      'posicaoEixoOd': serializer.toJson<int?>(posicaoEixoOd),
      'posicaoEixoOe': serializer.toJson<int?>(posicaoEixoOe),
      'distanciaNasoPupilarOd':
          serializer.toJson<double?>(distanciaNasoPupilarOd),
      'distanciaNasoPupilarOe':
          serializer.toJson<double?>(distanciaNasoPupilarOe),
      'acuidadeVisualLongeOd':
          serializer.toJson<String?>(acuidadeVisualLongeOd),
      'acuidadeVisualLongeOe':
          serializer.toJson<String?>(acuidadeVisualLongeOe),
      'adicao': serializer.toJson<double?>(adicao),
      'acuidadeVisualPertoOd':
          serializer.toJson<String?>(acuidadeVisualPertoOd),
      'acuidadeVisualPertoOe':
          serializer.toJson<String?>(acuidadeVisualPertoOe),
      'examinador': serializer.toJson<String?>(examinador),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  Atendimento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> talao = const Value.absent(),
          Value<DateTime?> dataAtendimento = const Value.absent(),
          Value<DateTime?> dataRetorno = const Value.absent(),
          Value<double?> valorEsfericoOd = const Value.absent(),
          Value<double?> valorEsfericoOe = const Value.absent(),
          Value<int?> valorCilindricoOd = const Value.absent(),
          Value<int?> valorCilindricoOe = const Value.absent(),
          Value<int?> posicaoEixoOd = const Value.absent(),
          Value<int?> posicaoEixoOe = const Value.absent(),
          Value<double?> distanciaNasoPupilarOd = const Value.absent(),
          Value<double?> distanciaNasoPupilarOe = const Value.absent(),
          Value<String?> acuidadeVisualLongeOd = const Value.absent(),
          Value<String?> acuidadeVisualLongeOe = const Value.absent(),
          Value<double?> adicao = const Value.absent(),
          Value<String?> acuidadeVisualPertoOd = const Value.absent(),
          Value<String?> acuidadeVisualPertoOe = const Value.absent(),
          Value<String?> examinador = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      Atendimento(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        talao: talao.present ? talao.value : this.talao,
        dataAtendimento: dataAtendimento.present
            ? dataAtendimento.value
            : this.dataAtendimento,
        dataRetorno: dataRetorno.present ? dataRetorno.value : this.dataRetorno,
        valorEsfericoOd: valorEsfericoOd.present
            ? valorEsfericoOd.value
            : this.valorEsfericoOd,
        valorEsfericoOe: valorEsfericoOe.present
            ? valorEsfericoOe.value
            : this.valorEsfericoOe,
        valorCilindricoOd: valorCilindricoOd.present
            ? valorCilindricoOd.value
            : this.valorCilindricoOd,
        valorCilindricoOe: valorCilindricoOe.present
            ? valorCilindricoOe.value
            : this.valorCilindricoOe,
        posicaoEixoOd:
            posicaoEixoOd.present ? posicaoEixoOd.value : this.posicaoEixoOd,
        posicaoEixoOe:
            posicaoEixoOe.present ? posicaoEixoOe.value : this.posicaoEixoOe,
        distanciaNasoPupilarOd: distanciaNasoPupilarOd.present
            ? distanciaNasoPupilarOd.value
            : this.distanciaNasoPupilarOd,
        distanciaNasoPupilarOe: distanciaNasoPupilarOe.present
            ? distanciaNasoPupilarOe.value
            : this.distanciaNasoPupilarOe,
        acuidadeVisualLongeOd: acuidadeVisualLongeOd.present
            ? acuidadeVisualLongeOd.value
            : this.acuidadeVisualLongeOd,
        acuidadeVisualLongeOe: acuidadeVisualLongeOe.present
            ? acuidadeVisualLongeOe.value
            : this.acuidadeVisualLongeOe,
        adicao: adicao.present ? adicao.value : this.adicao,
        acuidadeVisualPertoOd: acuidadeVisualPertoOd.present
            ? acuidadeVisualPertoOd.value
            : this.acuidadeVisualPertoOd,
        acuidadeVisualPertoOe: acuidadeVisualPertoOe.present
            ? acuidadeVisualPertoOe.value
            : this.acuidadeVisualPertoOe,
        examinador: examinador.present ? examinador.value : this.examinador,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('Atendimento(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('talao: $talao, ')
          ..write('dataAtendimento: $dataAtendimento, ')
          ..write('dataRetorno: $dataRetorno, ')
          ..write('valorEsfericoOd: $valorEsfericoOd, ')
          ..write('valorEsfericoOe: $valorEsfericoOe, ')
          ..write('valorCilindricoOd: $valorCilindricoOd, ')
          ..write('valorCilindricoOe: $valorCilindricoOe, ')
          ..write('posicaoEixoOd: $posicaoEixoOd, ')
          ..write('posicaoEixoOe: $posicaoEixoOe, ')
          ..write('distanciaNasoPupilarOd: $distanciaNasoPupilarOd, ')
          ..write('distanciaNasoPupilarOe: $distanciaNasoPupilarOe, ')
          ..write('acuidadeVisualLongeOd: $acuidadeVisualLongeOd, ')
          ..write('acuidadeVisualLongeOe: $acuidadeVisualLongeOe, ')
          ..write('adicao: $adicao, ')
          ..write('acuidadeVisualPertoOd: $acuidadeVisualPertoOd, ')
          ..write('acuidadeVisualPertoOe: $acuidadeVisualPertoOe, ')
          ..write('examinador: $examinador, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      talao,
      dataAtendimento,
      dataRetorno,
      valorEsfericoOd,
      valorEsfericoOe,
      valorCilindricoOd,
      valorCilindricoOe,
      posicaoEixoOd,
      posicaoEixoOe,
      distanciaNasoPupilarOd,
      distanciaNasoPupilarOe,
      acuidadeVisualLongeOd,
      acuidadeVisualLongeOe,
      adicao,
      acuidadeVisualPertoOd,
      acuidadeVisualPertoOe,
      examinador,
      observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Atendimento &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.talao == this.talao &&
          other.dataAtendimento == this.dataAtendimento &&
          other.dataRetorno == this.dataRetorno &&
          other.valorEsfericoOd == this.valorEsfericoOd &&
          other.valorEsfericoOe == this.valorEsfericoOe &&
          other.valorCilindricoOd == this.valorCilindricoOd &&
          other.valorCilindricoOe == this.valorCilindricoOe &&
          other.posicaoEixoOd == this.posicaoEixoOd &&
          other.posicaoEixoOe == this.posicaoEixoOe &&
          other.distanciaNasoPupilarOd == this.distanciaNasoPupilarOd &&
          other.distanciaNasoPupilarOe == this.distanciaNasoPupilarOe &&
          other.acuidadeVisualLongeOd == this.acuidadeVisualLongeOd &&
          other.acuidadeVisualLongeOe == this.acuidadeVisualLongeOe &&
          other.adicao == this.adicao &&
          other.acuidadeVisualPertoOd == this.acuidadeVisualPertoOd &&
          other.acuidadeVisualPertoOe == this.acuidadeVisualPertoOe &&
          other.examinador == this.examinador &&
          other.observacao == this.observacao);
}

class AtendimentosCompanion extends UpdateCompanion<Atendimento> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<int?> talao;
  final Value<DateTime?> dataAtendimento;
  final Value<DateTime?> dataRetorno;
  final Value<double?> valorEsfericoOd;
  final Value<double?> valorEsfericoOe;
  final Value<int?> valorCilindricoOd;
  final Value<int?> valorCilindricoOe;
  final Value<int?> posicaoEixoOd;
  final Value<int?> posicaoEixoOe;
  final Value<double?> distanciaNasoPupilarOd;
  final Value<double?> distanciaNasoPupilarOe;
  final Value<String?> acuidadeVisualLongeOd;
  final Value<String?> acuidadeVisualLongeOe;
  final Value<double?> adicao;
  final Value<String?> acuidadeVisualPertoOd;
  final Value<String?> acuidadeVisualPertoOe;
  final Value<String?> examinador;
  final Value<String?> observacao;
  const AtendimentosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.talao = const Value.absent(),
    this.dataAtendimento = const Value.absent(),
    this.dataRetorno = const Value.absent(),
    this.valorEsfericoOd = const Value.absent(),
    this.valorEsfericoOe = const Value.absent(),
    this.valorCilindricoOd = const Value.absent(),
    this.valorCilindricoOe = const Value.absent(),
    this.posicaoEixoOd = const Value.absent(),
    this.posicaoEixoOe = const Value.absent(),
    this.distanciaNasoPupilarOd = const Value.absent(),
    this.distanciaNasoPupilarOe = const Value.absent(),
    this.acuidadeVisualLongeOd = const Value.absent(),
    this.acuidadeVisualLongeOe = const Value.absent(),
    this.adicao = const Value.absent(),
    this.acuidadeVisualPertoOd = const Value.absent(),
    this.acuidadeVisualPertoOe = const Value.absent(),
    this.examinador = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  AtendimentosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.talao = const Value.absent(),
    this.dataAtendimento = const Value.absent(),
    this.dataRetorno = const Value.absent(),
    this.valorEsfericoOd = const Value.absent(),
    this.valorEsfericoOe = const Value.absent(),
    this.valorCilindricoOd = const Value.absent(),
    this.valorCilindricoOe = const Value.absent(),
    this.posicaoEixoOd = const Value.absent(),
    this.posicaoEixoOe = const Value.absent(),
    this.distanciaNasoPupilarOd = const Value.absent(),
    this.distanciaNasoPupilarOe = const Value.absent(),
    this.acuidadeVisualLongeOd = const Value.absent(),
    this.acuidadeVisualLongeOe = const Value.absent(),
    this.adicao = const Value.absent(),
    this.acuidadeVisualPertoOd = const Value.absent(),
    this.acuidadeVisualPertoOe = const Value.absent(),
    this.examinador = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<Atendimento> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<int>? talao,
    Expression<DateTime>? dataAtendimento,
    Expression<DateTime>? dataRetorno,
    Expression<double>? valorEsfericoOd,
    Expression<double>? valorEsfericoOe,
    Expression<int>? valorCilindricoOd,
    Expression<int>? valorCilindricoOe,
    Expression<int>? posicaoEixoOd,
    Expression<int>? posicaoEixoOe,
    Expression<double>? distanciaNasoPupilarOd,
    Expression<double>? distanciaNasoPupilarOe,
    Expression<String>? acuidadeVisualLongeOd,
    Expression<String>? acuidadeVisualLongeOe,
    Expression<double>? adicao,
    Expression<String>? acuidadeVisualPertoOd,
    Expression<String>? acuidadeVisualPertoOe,
    Expression<String>? examinador,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'ID': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (talao != null) 'talao': talao,
      if (dataAtendimento != null) 'data_atendimento': dataAtendimento,
      if (dataRetorno != null) 'data_retorno': dataRetorno,
      if (valorEsfericoOd != null) 'valor_esferico_od': valorEsfericoOd,
      if (valorEsfericoOe != null) 'valor_esferico_oe': valorEsfericoOe,
      if (valorCilindricoOd != null) 'valor_cilindrico_od': valorCilindricoOd,
      if (valorCilindricoOe != null) 'valor_cilindrico_oe': valorCilindricoOe,
      if (posicaoEixoOd != null) 'posicao_eixo_od': posicaoEixoOd,
      if (posicaoEixoOe != null) 'posicao_eixo_oe': posicaoEixoOe,
      if (distanciaNasoPupilarOd != null)
        'distancia_naso_pupilar_od': distanciaNasoPupilarOd,
      if (distanciaNasoPupilarOe != null)
        'distancia_naso_pupilar_oe': distanciaNasoPupilarOe,
      if (acuidadeVisualLongeOd != null)
        'acuidade_visual_longe_od': acuidadeVisualLongeOd,
      if (acuidadeVisualLongeOe != null)
        'acuidade_visual_longe_oe': acuidadeVisualLongeOe,
      if (adicao != null) 'adicao': adicao,
      if (acuidadeVisualPertoOd != null)
        'acuidade_visual_perto_od': acuidadeVisualPertoOd,
      if (acuidadeVisualPertoOe != null)
        'acuidade_visual_perto_oe': acuidadeVisualPertoOe,
      if (examinador != null) 'examinador': examinador,
      if (observacao != null) 'observacao': observacao,
    });
  }

  AtendimentosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<int?>? talao,
      Value<DateTime?>? dataAtendimento,
      Value<DateTime?>? dataRetorno,
      Value<double?>? valorEsfericoOd,
      Value<double?>? valorEsfericoOe,
      Value<int?>? valorCilindricoOd,
      Value<int?>? valorCilindricoOe,
      Value<int?>? posicaoEixoOd,
      Value<int?>? posicaoEixoOe,
      Value<double?>? distanciaNasoPupilarOd,
      Value<double?>? distanciaNasoPupilarOe,
      Value<String?>? acuidadeVisualLongeOd,
      Value<String?>? acuidadeVisualLongeOe,
      Value<double?>? adicao,
      Value<String?>? acuidadeVisualPertoOd,
      Value<String?>? acuidadeVisualPertoOe,
      Value<String?>? examinador,
      Value<String?>? observacao}) {
    return AtendimentosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      talao: talao ?? this.talao,
      dataAtendimento: dataAtendimento ?? this.dataAtendimento,
      dataRetorno: dataRetorno ?? this.dataRetorno,
      valorEsfericoOd: valorEsfericoOd ?? this.valorEsfericoOd,
      valorEsfericoOe: valorEsfericoOe ?? this.valorEsfericoOe,
      valorCilindricoOd: valorCilindricoOd ?? this.valorCilindricoOd,
      valorCilindricoOe: valorCilindricoOe ?? this.valorCilindricoOe,
      posicaoEixoOd: posicaoEixoOd ?? this.posicaoEixoOd,
      posicaoEixoOe: posicaoEixoOe ?? this.posicaoEixoOe,
      distanciaNasoPupilarOd:
          distanciaNasoPupilarOd ?? this.distanciaNasoPupilarOd,
      distanciaNasoPupilarOe:
          distanciaNasoPupilarOe ?? this.distanciaNasoPupilarOe,
      acuidadeVisualLongeOd:
          acuidadeVisualLongeOd ?? this.acuidadeVisualLongeOd,
      acuidadeVisualLongeOe:
          acuidadeVisualLongeOe ?? this.acuidadeVisualLongeOe,
      adicao: adicao ?? this.adicao,
      acuidadeVisualPertoOd:
          acuidadeVisualPertoOd ?? this.acuidadeVisualPertoOd,
      acuidadeVisualPertoOe:
          acuidadeVisualPertoOe ?? this.acuidadeVisualPertoOe,
      examinador: examinador ?? this.examinador,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['ID'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (talao.present) {
      map['talao'] = Variable<int>(talao.value);
    }
    if (dataAtendimento.present) {
      map['data_atendimento'] = Variable<DateTime>(dataAtendimento.value);
    }
    if (dataRetorno.present) {
      map['data_retorno'] = Variable<DateTime>(dataRetorno.value);
    }
    if (valorEsfericoOd.present) {
      map['valor_esferico_od'] = Variable<double>(valorEsfericoOd.value);
    }
    if (valorEsfericoOe.present) {
      map['valor_esferico_oe'] = Variable<double>(valorEsfericoOe.value);
    }
    if (valorCilindricoOd.present) {
      map['valor_cilindrico_od'] = Variable<int>(valorCilindricoOd.value);
    }
    if (valorCilindricoOe.present) {
      map['valor_cilindrico_oe'] = Variable<int>(valorCilindricoOe.value);
    }
    if (posicaoEixoOd.present) {
      map['posicao_eixo_od'] = Variable<int>(posicaoEixoOd.value);
    }
    if (posicaoEixoOe.present) {
      map['posicao_eixo_oe'] = Variable<int>(posicaoEixoOe.value);
    }
    if (distanciaNasoPupilarOd.present) {
      map['distancia_naso_pupilar_od'] =
          Variable<double>(distanciaNasoPupilarOd.value);
    }
    if (distanciaNasoPupilarOe.present) {
      map['distancia_naso_pupilar_oe'] =
          Variable<double>(distanciaNasoPupilarOe.value);
    }
    if (acuidadeVisualLongeOd.present) {
      map['acuidade_visual_longe_od'] =
          Variable<String>(acuidadeVisualLongeOd.value);
    }
    if (acuidadeVisualLongeOe.present) {
      map['acuidade_visual_longe_oe'] =
          Variable<String>(acuidadeVisualLongeOe.value);
    }
    if (adicao.present) {
      map['adicao'] = Variable<double>(adicao.value);
    }
    if (acuidadeVisualPertoOd.present) {
      map['acuidade_visual_perto_od'] =
          Variable<String>(acuidadeVisualPertoOd.value);
    }
    if (acuidadeVisualPertoOe.present) {
      map['acuidade_visual_perto_oe'] =
          Variable<String>(acuidadeVisualPertoOe.value);
    }
    if (examinador.present) {
      map['examinador'] = Variable<String>(examinador.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AtendimentosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('talao: $talao, ')
          ..write('dataAtendimento: $dataAtendimento, ')
          ..write('dataRetorno: $dataRetorno, ')
          ..write('valorEsfericoOd: $valorEsfericoOd, ')
          ..write('valorEsfericoOe: $valorEsfericoOe, ')
          ..write('valorCilindricoOd: $valorCilindricoOd, ')
          ..write('valorCilindricoOe: $valorCilindricoOe, ')
          ..write('posicaoEixoOd: $posicaoEixoOd, ')
          ..write('posicaoEixoOe: $posicaoEixoOe, ')
          ..write('distanciaNasoPupilarOd: $distanciaNasoPupilarOd, ')
          ..write('distanciaNasoPupilarOe: $distanciaNasoPupilarOe, ')
          ..write('acuidadeVisualLongeOd: $acuidadeVisualLongeOd, ')
          ..write('acuidadeVisualLongeOe: $acuidadeVisualLongeOe, ')
          ..write('adicao: $adicao, ')
          ..write('acuidadeVisualPertoOd: $acuidadeVisualPertoOd, ')
          ..write('acuidadeVisualPertoOe: $acuidadeVisualPertoOe, ')
          ..write('examinador: $examinador, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $PessoaTelefonesTable extends PessoaTelefones
    with TableInfo<$PessoaTelefonesTable, PessoaTelefone> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoaTelefonesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idPessoa, tipo, numero];
  @override
  String get aliasedName => _alias ?? 'pessoa_telefone';
  @override
  String get actualTableName => 'pessoa_telefone';
  @override
  VerificationContext validateIntegrity(Insertable<PessoaTelefone> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PessoaTelefone map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PessoaTelefone(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
    );
  }

  @override
  $PessoaTelefonesTable createAlias(String alias) {
    return $PessoaTelefonesTable(attachedDatabase, alias);
  }
}

class PessoaTelefone extends DataClass implements Insertable<PessoaTelefone> {
  final int? id;
  final int? idPessoa;
  final String? tipo;
  final String? numero;
  const PessoaTelefone({this.id, this.idPessoa, this.tipo, this.numero});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    return map;
  }

  factory PessoaTelefone.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PessoaTelefone(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      numero: serializer.fromJson<String?>(json['numero']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'tipo': serializer.toJson<String?>(tipo),
      'numero': serializer.toJson<String?>(numero),
    };
  }

  PessoaTelefone copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> numero = const Value.absent()}) =>
      PessoaTelefone(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        tipo: tipo.present ? tipo.value : this.tipo,
        numero: numero.present ? numero.value : this.numero,
      );
  @override
  String toString() {
    return (StringBuffer('PessoaTelefone(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('tipo: $tipo, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, tipo, numero);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PessoaTelefone &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.tipo == this.tipo &&
          other.numero == this.numero);
}

class PessoaTelefonesCompanion extends UpdateCompanion<PessoaTelefone> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> tipo;
  final Value<String?> numero;
  const PessoaTelefonesCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.tipo = const Value.absent(),
    this.numero = const Value.absent(),
  });
  PessoaTelefonesCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.tipo = const Value.absent(),
    this.numero = const Value.absent(),
  });
  static Insertable<PessoaTelefone> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? tipo,
    Expression<String>? numero,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (tipo != null) 'tipo': tipo,
      if (numero != null) 'numero': numero,
    });
  }

  PessoaTelefonesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? tipo,
      Value<String?>? numero}) {
    return PessoaTelefonesCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      tipo: tipo ?? this.tipo,
      numero: numero ?? this.numero,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoaTelefonesCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('tipo: $tipo, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }
}

class $PessoaJuridicasTable extends PessoaJuridicas
    with TableInfo<$PessoaJuridicasTable, PessoaJuridica> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoaJuridicasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 18),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeFantasiaMeta =
      const VerificationMeta('nomeFantasia');
  @override
  late final GeneratedColumn<String> nomeFantasia = GeneratedColumn<String>(
      'nome_fantasia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _inscricaoEstadualMeta =
      const VerificationMeta('inscricaoEstadual');
  @override
  late final GeneratedColumn<String> inscricaoEstadual =
      GeneratedColumn<String>('inscricao_estadual', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 45),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _inscricaoMunicipalMeta =
      const VerificationMeta('inscricaoMunicipal');
  @override
  late final GeneratedColumn<String> inscricaoMunicipal =
      GeneratedColumn<String>('inscricao_municipal', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 45),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _dataConstituicaoMeta =
      const VerificationMeta('dataConstituicao');
  @override
  late final GeneratedColumn<DateTime> dataConstituicao =
      GeneratedColumn<DateTime>('data_constituicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _tipoRegimeMeta =
      const VerificationMeta('tipoRegime');
  @override
  late final GeneratedColumn<String> tipoRegime = GeneratedColumn<String>(
      'tipo_regime', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _crtMeta = const VerificationMeta('crt');
  @override
  late final GeneratedColumn<String> crt = GeneratedColumn<String>(
      'crt', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        cnpj,
        nomeFantasia,
        inscricaoEstadual,
        inscricaoMunicipal,
        dataConstituicao,
        tipoRegime,
        crt
      ];
  @override
  String get aliasedName => _alias ?? 'pessoa_juridica';
  @override
  String get actualTableName => 'pessoa_juridica';
  @override
  VerificationContext validateIntegrity(Insertable<PessoaJuridica> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('nome_fantasia')) {
      context.handle(
          _nomeFantasiaMeta,
          nomeFantasia.isAcceptableOrUnknown(
              data['nome_fantasia']!, _nomeFantasiaMeta));
    }
    if (data.containsKey('inscricao_estadual')) {
      context.handle(
          _inscricaoEstadualMeta,
          inscricaoEstadual.isAcceptableOrUnknown(
              data['inscricao_estadual']!, _inscricaoEstadualMeta));
    }
    if (data.containsKey('inscricao_municipal')) {
      context.handle(
          _inscricaoMunicipalMeta,
          inscricaoMunicipal.isAcceptableOrUnknown(
              data['inscricao_municipal']!, _inscricaoMunicipalMeta));
    }
    if (data.containsKey('data_constituicao')) {
      context.handle(
          _dataConstituicaoMeta,
          dataConstituicao.isAcceptableOrUnknown(
              data['data_constituicao']!, _dataConstituicaoMeta));
    }
    if (data.containsKey('tipo_regime')) {
      context.handle(
          _tipoRegimeMeta,
          tipoRegime.isAcceptableOrUnknown(
              data['tipo_regime']!, _tipoRegimeMeta));
    }
    if (data.containsKey('crt')) {
      context.handle(
          _crtMeta, crt.isAcceptableOrUnknown(data['crt']!, _crtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PessoaJuridica map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PessoaJuridica(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      nomeFantasia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_fantasia']),
      inscricaoEstadual: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}inscricao_estadual']),
      inscricaoMunicipal: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}inscricao_municipal']),
      dataConstituicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_constituicao']),
      tipoRegime: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_regime']),
      crt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}crt']),
    );
  }

  @override
  $PessoaJuridicasTable createAlias(String alias) {
    return $PessoaJuridicasTable(attachedDatabase, alias);
  }
}

class PessoaJuridica extends DataClass implements Insertable<PessoaJuridica> {
  final int? id;
  final int? idPessoa;
  final String? cnpj;
  final String? nomeFantasia;
  final String? inscricaoEstadual;
  final String? inscricaoMunicipal;
  final DateTime? dataConstituicao;
  final String? tipoRegime;
  final String? crt;
  const PessoaJuridica(
      {this.id,
      this.idPessoa,
      this.cnpj,
      this.nomeFantasia,
      this.inscricaoEstadual,
      this.inscricaoMunicipal,
      this.dataConstituicao,
      this.tipoRegime,
      this.crt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || nomeFantasia != null) {
      map['nome_fantasia'] = Variable<String>(nomeFantasia);
    }
    if (!nullToAbsent || inscricaoEstadual != null) {
      map['inscricao_estadual'] = Variable<String>(inscricaoEstadual);
    }
    if (!nullToAbsent || inscricaoMunicipal != null) {
      map['inscricao_municipal'] = Variable<String>(inscricaoMunicipal);
    }
    if (!nullToAbsent || dataConstituicao != null) {
      map['data_constituicao'] = Variable<DateTime>(dataConstituicao);
    }
    if (!nullToAbsent || tipoRegime != null) {
      map['tipo_regime'] = Variable<String>(tipoRegime);
    }
    if (!nullToAbsent || crt != null) {
      map['crt'] = Variable<String>(crt);
    }
    return map;
  }

  factory PessoaJuridica.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PessoaJuridica(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      nomeFantasia: serializer.fromJson<String?>(json['nomeFantasia']),
      inscricaoEstadual:
          serializer.fromJson<String?>(json['inscricaoEstadual']),
      inscricaoMunicipal:
          serializer.fromJson<String?>(json['inscricaoMunicipal']),
      dataConstituicao:
          serializer.fromJson<DateTime?>(json['dataConstituicao']),
      tipoRegime: serializer.fromJson<String?>(json['tipoRegime']),
      crt: serializer.fromJson<String?>(json['crt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'cnpj': serializer.toJson<String?>(cnpj),
      'nomeFantasia': serializer.toJson<String?>(nomeFantasia),
      'inscricaoEstadual': serializer.toJson<String?>(inscricaoEstadual),
      'inscricaoMunicipal': serializer.toJson<String?>(inscricaoMunicipal),
      'dataConstituicao': serializer.toJson<DateTime?>(dataConstituicao),
      'tipoRegime': serializer.toJson<String?>(tipoRegime),
      'crt': serializer.toJson<String?>(crt),
    };
  }

  PessoaJuridica copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> nomeFantasia = const Value.absent(),
          Value<String?> inscricaoEstadual = const Value.absent(),
          Value<String?> inscricaoMunicipal = const Value.absent(),
          Value<DateTime?> dataConstituicao = const Value.absent(),
          Value<String?> tipoRegime = const Value.absent(),
          Value<String?> crt = const Value.absent()}) =>
      PessoaJuridica(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        nomeFantasia:
            nomeFantasia.present ? nomeFantasia.value : this.nomeFantasia,
        inscricaoEstadual: inscricaoEstadual.present
            ? inscricaoEstadual.value
            : this.inscricaoEstadual,
        inscricaoMunicipal: inscricaoMunicipal.present
            ? inscricaoMunicipal.value
            : this.inscricaoMunicipal,
        dataConstituicao: dataConstituicao.present
            ? dataConstituicao.value
            : this.dataConstituicao,
        tipoRegime: tipoRegime.present ? tipoRegime.value : this.tipoRegime,
        crt: crt.present ? crt.value : this.crt,
      );
  @override
  String toString() {
    return (StringBuffer('PessoaJuridica(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('cnpj: $cnpj, ')
          ..write('nomeFantasia: $nomeFantasia, ')
          ..write('inscricaoEstadual: $inscricaoEstadual, ')
          ..write('inscricaoMunicipal: $inscricaoMunicipal, ')
          ..write('dataConstituicao: $dataConstituicao, ')
          ..write('tipoRegime: $tipoRegime, ')
          ..write('crt: $crt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, cnpj, nomeFantasia,
      inscricaoEstadual, inscricaoMunicipal, dataConstituicao, tipoRegime, crt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PessoaJuridica &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.cnpj == this.cnpj &&
          other.nomeFantasia == this.nomeFantasia &&
          other.inscricaoEstadual == this.inscricaoEstadual &&
          other.inscricaoMunicipal == this.inscricaoMunicipal &&
          other.dataConstituicao == this.dataConstituicao &&
          other.tipoRegime == this.tipoRegime &&
          other.crt == this.crt);
}

class PessoaJuridicasCompanion extends UpdateCompanion<PessoaJuridica> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> cnpj;
  final Value<String?> nomeFantasia;
  final Value<String?> inscricaoEstadual;
  final Value<String?> inscricaoMunicipal;
  final Value<DateTime?> dataConstituicao;
  final Value<String?> tipoRegime;
  final Value<String?> crt;
  const PessoaJuridicasCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.nomeFantasia = const Value.absent(),
    this.inscricaoEstadual = const Value.absent(),
    this.inscricaoMunicipal = const Value.absent(),
    this.dataConstituicao = const Value.absent(),
    this.tipoRegime = const Value.absent(),
    this.crt = const Value.absent(),
  });
  PessoaJuridicasCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.nomeFantasia = const Value.absent(),
    this.inscricaoEstadual = const Value.absent(),
    this.inscricaoMunicipal = const Value.absent(),
    this.dataConstituicao = const Value.absent(),
    this.tipoRegime = const Value.absent(),
    this.crt = const Value.absent(),
  });
  static Insertable<PessoaJuridica> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? cnpj,
    Expression<String>? nomeFantasia,
    Expression<String>? inscricaoEstadual,
    Expression<String>? inscricaoMunicipal,
    Expression<DateTime>? dataConstituicao,
    Expression<String>? tipoRegime,
    Expression<String>? crt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (cnpj != null) 'cnpj': cnpj,
      if (nomeFantasia != null) 'nome_fantasia': nomeFantasia,
      if (inscricaoEstadual != null) 'inscricao_estadual': inscricaoEstadual,
      if (inscricaoMunicipal != null) 'inscricao_municipal': inscricaoMunicipal,
      if (dataConstituicao != null) 'data_constituicao': dataConstituicao,
      if (tipoRegime != null) 'tipo_regime': tipoRegime,
      if (crt != null) 'crt': crt,
    });
  }

  PessoaJuridicasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? cnpj,
      Value<String?>? nomeFantasia,
      Value<String?>? inscricaoEstadual,
      Value<String?>? inscricaoMunicipal,
      Value<DateTime?>? dataConstituicao,
      Value<String?>? tipoRegime,
      Value<String?>? crt}) {
    return PessoaJuridicasCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      cnpj: cnpj ?? this.cnpj,
      nomeFantasia: nomeFantasia ?? this.nomeFantasia,
      inscricaoEstadual: inscricaoEstadual ?? this.inscricaoEstadual,
      inscricaoMunicipal: inscricaoMunicipal ?? this.inscricaoMunicipal,
      dataConstituicao: dataConstituicao ?? this.dataConstituicao,
      tipoRegime: tipoRegime ?? this.tipoRegime,
      crt: crt ?? this.crt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (nomeFantasia.present) {
      map['nome_fantasia'] = Variable<String>(nomeFantasia.value);
    }
    if (inscricaoEstadual.present) {
      map['inscricao_estadual'] = Variable<String>(inscricaoEstadual.value);
    }
    if (inscricaoMunicipal.present) {
      map['inscricao_municipal'] = Variable<String>(inscricaoMunicipal.value);
    }
    if (dataConstituicao.present) {
      map['data_constituicao'] = Variable<DateTime>(dataConstituicao.value);
    }
    if (tipoRegime.present) {
      map['tipo_regime'] = Variable<String>(tipoRegime.value);
    }
    if (crt.present) {
      map['crt'] = Variable<String>(crt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoaJuridicasCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('cnpj: $cnpj, ')
          ..write('nomeFantasia: $nomeFantasia, ')
          ..write('inscricaoEstadual: $inscricaoEstadual, ')
          ..write('inscricaoMunicipal: $inscricaoMunicipal, ')
          ..write('dataConstituicao: $dataConstituicao, ')
          ..write('tipoRegime: $tipoRegime, ')
          ..write('crt: $crt')
          ..write(')'))
        .toString();
  }
}

class $PessoasTable extends Pessoas with TableInfo<$PessoasTable, Pessoa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ehClienteMeta =
      const VerificationMeta('ehCliente');
  @override
  late final GeneratedColumn<String> ehCliente = GeneratedColumn<String>(
      'eh_cliente', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ehFornecedorMeta =
      const VerificationMeta('ehFornecedor');
  @override
  late final GeneratedColumn<String> ehFornecedor = GeneratedColumn<String>(
      'eh_fornecedor', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _referenciaMeta =
      const VerificationMeta('referencia');
  @override
  late final GeneratedColumn<String> referencia = GeneratedColumn<String>(
      'referencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        site,
        email,
        ehCliente,
        ehFornecedor,
        referencia,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? 'pessoa';
  @override
  String get actualTableName => 'pessoa';
  @override
  VerificationContext validateIntegrity(Insertable<Pessoa> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('eh_cliente')) {
      context.handle(_ehClienteMeta,
          ehCliente.isAcceptableOrUnknown(data['eh_cliente']!, _ehClienteMeta));
    }
    if (data.containsKey('eh_fornecedor')) {
      context.handle(
          _ehFornecedorMeta,
          ehFornecedor.isAcceptableOrUnknown(
              data['eh_fornecedor']!, _ehFornecedorMeta));
    }
    if (data.containsKey('referencia')) {
      context.handle(
          _referenciaMeta,
          referencia.isAcceptableOrUnknown(
              data['referencia']!, _referenciaMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Pessoa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Pessoa(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      ehCliente: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}eh_cliente']),
      ehFornecedor: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}eh_fornecedor']),
      referencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}referencia']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $PessoasTable createAlias(String alias) {
    return $PessoasTable(attachedDatabase, alias);
  }
}

class Pessoa extends DataClass implements Insertable<Pessoa> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? site;
  final String? email;
  final String? ehCliente;
  final String? ehFornecedor;
  final String? referencia;
  final String? observacao;
  const Pessoa(
      {this.id,
      this.nome,
      this.tipo,
      this.site,
      this.email,
      this.ehCliente,
      this.ehFornecedor,
      this.referencia,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || ehCliente != null) {
      map['eh_cliente'] = Variable<String>(ehCliente);
    }
    if (!nullToAbsent || ehFornecedor != null) {
      map['eh_fornecedor'] = Variable<String>(ehFornecedor);
    }
    if (!nullToAbsent || referencia != null) {
      map['referencia'] = Variable<String>(referencia);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory Pessoa.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Pessoa(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      site: serializer.fromJson<String?>(json['site']),
      email: serializer.fromJson<String?>(json['email']),
      ehCliente: serializer.fromJson<String?>(json['ehCliente']),
      ehFornecedor: serializer.fromJson<String?>(json['ehFornecedor']),
      referencia: serializer.fromJson<String?>(json['referencia']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'site': serializer.toJson<String?>(site),
      'email': serializer.toJson<String?>(email),
      'ehCliente': serializer.toJson<String?>(ehCliente),
      'ehFornecedor': serializer.toJson<String?>(ehFornecedor),
      'referencia': serializer.toJson<String?>(referencia),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  Pessoa copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> ehCliente = const Value.absent(),
          Value<String?> ehFornecedor = const Value.absent(),
          Value<String?> referencia = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      Pessoa(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        site: site.present ? site.value : this.site,
        email: email.present ? email.value : this.email,
        ehCliente: ehCliente.present ? ehCliente.value : this.ehCliente,
        ehFornecedor:
            ehFornecedor.present ? ehFornecedor.value : this.ehFornecedor,
        referencia: referencia.present ? referencia.value : this.referencia,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('Pessoa(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('site: $site, ')
          ..write('email: $email, ')
          ..write('ehCliente: $ehCliente, ')
          ..write('ehFornecedor: $ehFornecedor, ')
          ..write('referencia: $referencia, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, tipo, site, email, ehCliente,
      ehFornecedor, referencia, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Pessoa &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.site == this.site &&
          other.email == this.email &&
          other.ehCliente == this.ehCliente &&
          other.ehFornecedor == this.ehFornecedor &&
          other.referencia == this.referencia &&
          other.observacao == this.observacao);
}

class PessoasCompanion extends UpdateCompanion<Pessoa> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> site;
  final Value<String?> email;
  final Value<String?> ehCliente;
  final Value<String?> ehFornecedor;
  final Value<String?> referencia;
  final Value<String?> observacao;
  const PessoasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.site = const Value.absent(),
    this.email = const Value.absent(),
    this.ehCliente = const Value.absent(),
    this.ehFornecedor = const Value.absent(),
    this.referencia = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  PessoasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.site = const Value.absent(),
    this.email = const Value.absent(),
    this.ehCliente = const Value.absent(),
    this.ehFornecedor = const Value.absent(),
    this.referencia = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<Pessoa> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? site,
    Expression<String>? email,
    Expression<String>? ehCliente,
    Expression<String>? ehFornecedor,
    Expression<String>? referencia,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (site != null) 'site': site,
      if (email != null) 'email': email,
      if (ehCliente != null) 'eh_cliente': ehCliente,
      if (ehFornecedor != null) 'eh_fornecedor': ehFornecedor,
      if (referencia != null) 'referencia': referencia,
      if (observacao != null) 'observacao': observacao,
    });
  }

  PessoasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? site,
      Value<String?>? email,
      Value<String?>? ehCliente,
      Value<String?>? ehFornecedor,
      Value<String?>? referencia,
      Value<String?>? observacao}) {
    return PessoasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      site: site ?? this.site,
      email: email ?? this.email,
      ehCliente: ehCliente ?? this.ehCliente,
      ehFornecedor: ehFornecedor ?? this.ehFornecedor,
      referencia: referencia ?? this.referencia,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (ehCliente.present) {
      map['eh_cliente'] = Variable<String>(ehCliente.value);
    }
    if (ehFornecedor.present) {
      map['eh_fornecedor'] = Variable<String>(ehFornecedor.value);
    }
    if (referencia.present) {
      map['referencia'] = Variable<String>(referencia.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('site: $site, ')
          ..write('email: $email, ')
          ..write('ehCliente: $ehCliente, ')
          ..write('ehFornecedor: $ehFornecedor, ')
          ..write('referencia: $referencia, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $VendaCabecalhosTable extends VendaCabecalhos
    with TableInfo<$VendaCabecalhosTable, VendaCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VendaCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<int> codigo = GeneratedColumn<int>(
      'codigo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataVendaMeta =
      const VerificationMeta('dataVenda');
  @override
  late final GeneratedColumn<DateTime> dataVenda = GeneratedColumn<DateTime>(
      'data_venda', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorSubtotalMeta =
      const VerificationMeta('valorSubtotal');
  @override
  late final GeneratedColumn<double> valorSubtotal = GeneratedColumn<double>(
      'valor_subtotal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeParcelasMeta =
      const VerificationMeta('quantidadeParcelas');
  @override
  late final GeneratedColumn<int> quantidadeParcelas = GeneratedColumn<int>(
      'quantidade_parcelas', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _primeiroVencimentoMeta =
      const VerificationMeta('primeiroVencimento');
  @override
  late final GeneratedColumn<DateTime> primeiroVencimento =
      GeneratedColumn<DateTime>('primeiro_vencimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataPrevistaEntregaMeta =
      const VerificationMeta('dataPrevistaEntrega');
  @override
  late final GeneratedColumn<DateTime> dataPrevistaEntrega =
      GeneratedColumn<DateTime>('data_prevista_entrega', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataEntregaMeta =
      const VerificationMeta('dataEntrega');
  @override
  late final GeneratedColumn<DateTime> dataEntrega = GeneratedColumn<DateTime>(
      'data_entrega', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        codigo,
        dataVenda,
        valorSubtotal,
        valorDesconto,
        valorTotal,
        quantidadeParcelas,
        primeiroVencimento,
        dataPrevistaEntrega,
        dataEntrega
      ];
  @override
  String get aliasedName => _alias ?? 'venda_cabecalho';
  @override
  String get actualTableName => 'venda_cabecalho';
  @override
  VerificationContext validateIntegrity(Insertable<VendaCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('data_venda')) {
      context.handle(_dataVendaMeta,
          dataVenda.isAcceptableOrUnknown(data['data_venda']!, _dataVendaMeta));
    }
    if (data.containsKey('valor_subtotal')) {
      context.handle(
          _valorSubtotalMeta,
          valorSubtotal.isAcceptableOrUnknown(
              data['valor_subtotal']!, _valorSubtotalMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    if (data.containsKey('quantidade_parcelas')) {
      context.handle(
          _quantidadeParcelasMeta,
          quantidadeParcelas.isAcceptableOrUnknown(
              data['quantidade_parcelas']!, _quantidadeParcelasMeta));
    }
    if (data.containsKey('primeiro_vencimento')) {
      context.handle(
          _primeiroVencimentoMeta,
          primeiroVencimento.isAcceptableOrUnknown(
              data['primeiro_vencimento']!, _primeiroVencimentoMeta));
    }
    if (data.containsKey('data_prevista_entrega')) {
      context.handle(
          _dataPrevistaEntregaMeta,
          dataPrevistaEntrega.isAcceptableOrUnknown(
              data['data_prevista_entrega']!, _dataPrevistaEntregaMeta));
    }
    if (data.containsKey('data_entrega')) {
      context.handle(
          _dataEntregaMeta,
          dataEntrega.isAcceptableOrUnknown(
              data['data_entrega']!, _dataEntregaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  VendaCabecalho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VendaCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo']),
      dataVenda: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_venda']),
      valorSubtotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_subtotal']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
      quantidadeParcelas: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}quantidade_parcelas']),
      primeiroVencimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}primeiro_vencimento']),
      dataPrevistaEntrega: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_prevista_entrega']),
      dataEntrega: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_entrega']),
    );
  }

  @override
  $VendaCabecalhosTable createAlias(String alias) {
    return $VendaCabecalhosTable(attachedDatabase, alias);
  }
}

class VendaCabecalho extends DataClass implements Insertable<VendaCabecalho> {
  final int? id;
  final int? idPessoa;
  final int? codigo;
  final DateTime? dataVenda;
  final double? valorSubtotal;
  final double? valorDesconto;
  final double? valorTotal;
  final int? quantidadeParcelas;
  final DateTime? primeiroVencimento;
  final DateTime? dataPrevistaEntrega;
  final DateTime? dataEntrega;
  const VendaCabecalho(
      {this.id,
      this.idPessoa,
      this.codigo,
      this.dataVenda,
      this.valorSubtotal,
      this.valorDesconto,
      this.valorTotal,
      this.quantidadeParcelas,
      this.primeiroVencimento,
      this.dataPrevistaEntrega,
      this.dataEntrega});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<int>(codigo);
    }
    if (!nullToAbsent || dataVenda != null) {
      map['data_venda'] = Variable<DateTime>(dataVenda);
    }
    if (!nullToAbsent || valorSubtotal != null) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    if (!nullToAbsent || quantidadeParcelas != null) {
      map['quantidade_parcelas'] = Variable<int>(quantidadeParcelas);
    }
    if (!nullToAbsent || primeiroVencimento != null) {
      map['primeiro_vencimento'] = Variable<DateTime>(primeiroVencimento);
    }
    if (!nullToAbsent || dataPrevistaEntrega != null) {
      map['data_prevista_entrega'] = Variable<DateTime>(dataPrevistaEntrega);
    }
    if (!nullToAbsent || dataEntrega != null) {
      map['data_entrega'] = Variable<DateTime>(dataEntrega);
    }
    return map;
  }

  factory VendaCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VendaCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      codigo: serializer.fromJson<int?>(json['codigo']),
      dataVenda: serializer.fromJson<DateTime?>(json['dataVenda']),
      valorSubtotal: serializer.fromJson<double?>(json['valorSubtotal']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
      quantidadeParcelas: serializer.fromJson<int?>(json['quantidadeParcelas']),
      primeiroVencimento:
          serializer.fromJson<DateTime?>(json['primeiroVencimento']),
      dataPrevistaEntrega:
          serializer.fromJson<DateTime?>(json['dataPrevistaEntrega']),
      dataEntrega: serializer.fromJson<DateTime?>(json['dataEntrega']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'codigo': serializer.toJson<int?>(codigo),
      'dataVenda': serializer.toJson<DateTime?>(dataVenda),
      'valorSubtotal': serializer.toJson<double?>(valorSubtotal),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorTotal': serializer.toJson<double?>(valorTotal),
      'quantidadeParcelas': serializer.toJson<int?>(quantidadeParcelas),
      'primeiroVencimento': serializer.toJson<DateTime?>(primeiroVencimento),
      'dataPrevistaEntrega': serializer.toJson<DateTime?>(dataPrevistaEntrega),
      'dataEntrega': serializer.toJson<DateTime?>(dataEntrega),
    };
  }

  VendaCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> codigo = const Value.absent(),
          Value<DateTime?> dataVenda = const Value.absent(),
          Value<double?> valorSubtotal = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorTotal = const Value.absent(),
          Value<int?> quantidadeParcelas = const Value.absent(),
          Value<DateTime?> primeiroVencimento = const Value.absent(),
          Value<DateTime?> dataPrevistaEntrega = const Value.absent(),
          Value<DateTime?> dataEntrega = const Value.absent()}) =>
      VendaCabecalho(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        codigo: codigo.present ? codigo.value : this.codigo,
        dataVenda: dataVenda.present ? dataVenda.value : this.dataVenda,
        valorSubtotal:
            valorSubtotal.present ? valorSubtotal.value : this.valorSubtotal,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
        quantidadeParcelas: quantidadeParcelas.present
            ? quantidadeParcelas.value
            : this.quantidadeParcelas,
        primeiroVencimento: primeiroVencimento.present
            ? primeiroVencimento.value
            : this.primeiroVencimento,
        dataPrevistaEntrega: dataPrevistaEntrega.present
            ? dataPrevistaEntrega.value
            : this.dataPrevistaEntrega,
        dataEntrega: dataEntrega.present ? dataEntrega.value : this.dataEntrega,
      );
  @override
  String toString() {
    return (StringBuffer('VendaCabecalho(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('codigo: $codigo, ')
          ..write('dataVenda: $dataVenda, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('quantidadeParcelas: $quantidadeParcelas, ')
          ..write('primeiroVencimento: $primeiroVencimento, ')
          ..write('dataPrevistaEntrega: $dataPrevistaEntrega, ')
          ..write('dataEntrega: $dataEntrega')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      codigo,
      dataVenda,
      valorSubtotal,
      valorDesconto,
      valorTotal,
      quantidadeParcelas,
      primeiroVencimento,
      dataPrevistaEntrega,
      dataEntrega);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VendaCabecalho &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.codigo == this.codigo &&
          other.dataVenda == this.dataVenda &&
          other.valorSubtotal == this.valorSubtotal &&
          other.valorDesconto == this.valorDesconto &&
          other.valorTotal == this.valorTotal &&
          other.quantidadeParcelas == this.quantidadeParcelas &&
          other.primeiroVencimento == this.primeiroVencimento &&
          other.dataPrevistaEntrega == this.dataPrevistaEntrega &&
          other.dataEntrega == this.dataEntrega);
}

class VendaCabecalhosCompanion extends UpdateCompanion<VendaCabecalho> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<int?> codigo;
  final Value<DateTime?> dataVenda;
  final Value<double?> valorSubtotal;
  final Value<double?> valorDesconto;
  final Value<double?> valorTotal;
  final Value<int?> quantidadeParcelas;
  final Value<DateTime?> primeiroVencimento;
  final Value<DateTime?> dataPrevistaEntrega;
  final Value<DateTime?> dataEntrega;
  const VendaCabecalhosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.codigo = const Value.absent(),
    this.dataVenda = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.quantidadeParcelas = const Value.absent(),
    this.primeiroVencimento = const Value.absent(),
    this.dataPrevistaEntrega = const Value.absent(),
    this.dataEntrega = const Value.absent(),
  });
  VendaCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.codigo = const Value.absent(),
    this.dataVenda = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.quantidadeParcelas = const Value.absent(),
    this.primeiroVencimento = const Value.absent(),
    this.dataPrevistaEntrega = const Value.absent(),
    this.dataEntrega = const Value.absent(),
  });
  static Insertable<VendaCabecalho> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<int>? codigo,
    Expression<DateTime>? dataVenda,
    Expression<double>? valorSubtotal,
    Expression<double>? valorDesconto,
    Expression<double>? valorTotal,
    Expression<int>? quantidadeParcelas,
    Expression<DateTime>? primeiroVencimento,
    Expression<DateTime>? dataPrevistaEntrega,
    Expression<DateTime>? dataEntrega,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (codigo != null) 'codigo': codigo,
      if (dataVenda != null) 'data_venda': dataVenda,
      if (valorSubtotal != null) 'valor_subtotal': valorSubtotal,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorTotal != null) 'valor_total': valorTotal,
      if (quantidadeParcelas != null) 'quantidade_parcelas': quantidadeParcelas,
      if (primeiroVencimento != null) 'primeiro_vencimento': primeiroVencimento,
      if (dataPrevistaEntrega != null)
        'data_prevista_entrega': dataPrevistaEntrega,
      if (dataEntrega != null) 'data_entrega': dataEntrega,
    });
  }

  VendaCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<int?>? codigo,
      Value<DateTime?>? dataVenda,
      Value<double?>? valorSubtotal,
      Value<double?>? valorDesconto,
      Value<double?>? valorTotal,
      Value<int?>? quantidadeParcelas,
      Value<DateTime?>? primeiroVencimento,
      Value<DateTime?>? dataPrevistaEntrega,
      Value<DateTime?>? dataEntrega}) {
    return VendaCabecalhosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      codigo: codigo ?? this.codigo,
      dataVenda: dataVenda ?? this.dataVenda,
      valorSubtotal: valorSubtotal ?? this.valorSubtotal,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorTotal: valorTotal ?? this.valorTotal,
      quantidadeParcelas: quantidadeParcelas ?? this.quantidadeParcelas,
      primeiroVencimento: primeiroVencimento ?? this.primeiroVencimento,
      dataPrevistaEntrega: dataPrevistaEntrega ?? this.dataPrevistaEntrega,
      dataEntrega: dataEntrega ?? this.dataEntrega,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<int>(codigo.value);
    }
    if (dataVenda.present) {
      map['data_venda'] = Variable<DateTime>(dataVenda.value);
    }
    if (valorSubtotal.present) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    if (quantidadeParcelas.present) {
      map['quantidade_parcelas'] = Variable<int>(quantidadeParcelas.value);
    }
    if (primeiroVencimento.present) {
      map['primeiro_vencimento'] = Variable<DateTime>(primeiroVencimento.value);
    }
    if (dataPrevistaEntrega.present) {
      map['data_prevista_entrega'] =
          Variable<DateTime>(dataPrevistaEntrega.value);
    }
    if (dataEntrega.present) {
      map['data_entrega'] = Variable<DateTime>(dataEntrega.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VendaCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('codigo: $codigo, ')
          ..write('dataVenda: $dataVenda, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('quantidadeParcelas: $quantidadeParcelas, ')
          ..write('primeiroVencimento: $primeiroVencimento, ')
          ..write('dataPrevistaEntrega: $dataPrevistaEntrega, ')
          ..write('dataEntrega: $dataEntrega')
          ..write(')'))
        .toString();
  }
}

class $UsuariosTable extends Usuarios with TableInfo<$UsuariosTable, Usuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $UsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, login, senha, nome];
  @override
  String get aliasedName => _alias ?? 'usuario';
  @override
  String get actualTableName => 'usuario';
  @override
  VerificationContext validateIntegrity(Insertable<Usuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Usuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Usuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $UsuariosTable createAlias(String alias) {
    return $UsuariosTable(attachedDatabase, alias);
  }
}

class Usuario extends DataClass implements Insertable<Usuario> {
  final int? id;
  final String? login;
  final String? senha;
  final String? nome;
  const Usuario({this.id, this.login, this.senha, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory Usuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Usuario(
      id: serializer.fromJson<int?>(json['id']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  Usuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      Usuario(
        id: id.present ? id.value : this.id,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('Usuario(')
          ..write('id: $id, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, login, senha, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Usuario &&
          other.id == this.id &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.nome == this.nome);
}

class UsuariosCompanion extends UpdateCompanion<Usuario> {
  final Value<int?> id;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<String?> nome;
  const UsuariosCompanion({
    this.id = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.nome = const Value.absent(),
  });
  UsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<Usuario> custom({
    Expression<int>? id,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (nome != null) 'nome': nome,
    });
  }

  UsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? login,
      Value<String?>? senha,
      Value<String?>? nome}) {
    return UsuariosCompanion(
      id: id ?? this.id,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('UsuariosCompanion(')
          ..write('id: $id, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $ContasPagarsTable extends ContasPagars
    with TableInfo<$ContasPagarsTable, ContasPagar> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContasPagarsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFormaPagamentoMeta =
      const VerificationMeta('idFormaPagamento');
  @override
  late final GeneratedColumn<int> idFormaPagamento = GeneratedColumn<int>(
      'id_forma_pagamento', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idBancoContaCaixaMeta =
      const VerificationMeta('idBancoContaCaixa');
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
      'id_banco_conta_caixa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataLancamentoMeta =
      const VerificationMeta('dataLancamento');
  @override
  late final GeneratedColumn<DateTime> dataLancamento =
      GeneratedColumn<DateTime>('data_lancamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _numeroParcelaMeta =
      const VerificationMeta('numeroParcela');
  @override
  late final GeneratedColumn<int> numeroParcela = GeneratedColumn<int>(
      'numero_parcela', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorParcelaMeta =
      const VerificationMeta('valorParcela');
  @override
  late final GeneratedColumn<double> valorParcela = GeneratedColumn<double>(
      'valor_parcela', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataVencimentoMeta =
      const VerificationMeta('dataVencimento');
  @override
  late final GeneratedColumn<DateTime> dataVencimento =
      GeneratedColumn<DateTime>('data_vencimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataRecebimentoMeta =
      const VerificationMeta('dataRecebimento');
  @override
  late final GeneratedColumn<DateTime> dataRecebimento =
      GeneratedColumn<DateTime>('data_recebimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorRecebidoMeta =
      const VerificationMeta('valorRecebido');
  @override
  late final GeneratedColumn<double> valorRecebido = GeneratedColumn<double>(
      'valor_recebido', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        idFormaPagamento,
        idBancoContaCaixa,
        dataLancamento,
        valorTotal,
        numeroParcela,
        valorParcela,
        dataVencimento,
        dataRecebimento,
        valorRecebido,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? 'contas_pagar';
  @override
  String get actualTableName => 'contas_pagar';
  @override
  VerificationContext validateIntegrity(Insertable<ContasPagar> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_forma_pagamento')) {
      context.handle(
          _idFormaPagamentoMeta,
          idFormaPagamento.isAcceptableOrUnknown(
              data['id_forma_pagamento']!, _idFormaPagamentoMeta));
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
          _idBancoContaCaixaMeta,
          idBancoContaCaixa.isAcceptableOrUnknown(
              data['id_banco_conta_caixa']!, _idBancoContaCaixaMeta));
    }
    if (data.containsKey('data_lancamento')) {
      context.handle(
          _dataLancamentoMeta,
          dataLancamento.isAcceptableOrUnknown(
              data['data_lancamento']!, _dataLancamentoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    if (data.containsKey('numero_parcela')) {
      context.handle(
          _numeroParcelaMeta,
          numeroParcela.isAcceptableOrUnknown(
              data['numero_parcela']!, _numeroParcelaMeta));
    }
    if (data.containsKey('valor_parcela')) {
      context.handle(
          _valorParcelaMeta,
          valorParcela.isAcceptableOrUnknown(
              data['valor_parcela']!, _valorParcelaMeta));
    }
    if (data.containsKey('data_vencimento')) {
      context.handle(
          _dataVencimentoMeta,
          dataVencimento.isAcceptableOrUnknown(
              data['data_vencimento']!, _dataVencimentoMeta));
    }
    if (data.containsKey('data_recebimento')) {
      context.handle(
          _dataRecebimentoMeta,
          dataRecebimento.isAcceptableOrUnknown(
              data['data_recebimento']!, _dataRecebimentoMeta));
    }
    if (data.containsKey('valor_recebido')) {
      context.handle(
          _valorRecebidoMeta,
          valorRecebido.isAcceptableOrUnknown(
              data['valor_recebido']!, _valorRecebidoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContasPagar map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContasPagar(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idFormaPagamento: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_forma_pagamento']),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_banco_conta_caixa']),
      dataLancamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_lancamento']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
      numeroParcela: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero_parcela']),
      valorParcela: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_parcela']),
      dataVencimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_vencimento']),
      dataRecebimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_recebimento']),
      valorRecebido: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_recebido']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $ContasPagarsTable createAlias(String alias) {
    return $ContasPagarsTable(attachedDatabase, alias);
  }
}

class ContasPagar extends DataClass implements Insertable<ContasPagar> {
  final int? id;
  final int? idPessoa;
  final int? idFormaPagamento;
  final int? idBancoContaCaixa;
  final DateTime? dataLancamento;
  final double? valorTotal;
  final int? numeroParcela;
  final double? valorParcela;
  final DateTime? dataVencimento;
  final DateTime? dataRecebimento;
  final double? valorRecebido;
  final String? observacao;
  const ContasPagar(
      {this.id,
      this.idPessoa,
      this.idFormaPagamento,
      this.idBancoContaCaixa,
      this.dataLancamento,
      this.valorTotal,
      this.numeroParcela,
      this.valorParcela,
      this.dataVencimento,
      this.dataRecebimento,
      this.valorRecebido,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idFormaPagamento != null) {
      map['id_forma_pagamento'] = Variable<int>(idFormaPagamento);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || dataLancamento != null) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    if (!nullToAbsent || numeroParcela != null) {
      map['numero_parcela'] = Variable<int>(numeroParcela);
    }
    if (!nullToAbsent || valorParcela != null) {
      map['valor_parcela'] = Variable<double>(valorParcela);
    }
    if (!nullToAbsent || dataVencimento != null) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento);
    }
    if (!nullToAbsent || dataRecebimento != null) {
      map['data_recebimento'] = Variable<DateTime>(dataRecebimento);
    }
    if (!nullToAbsent || valorRecebido != null) {
      map['valor_recebido'] = Variable<double>(valorRecebido);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory ContasPagar.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContasPagar(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idFormaPagamento: serializer.fromJson<int?>(json['idFormaPagamento']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      dataLancamento: serializer.fromJson<DateTime?>(json['dataLancamento']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
      numeroParcela: serializer.fromJson<int?>(json['numeroParcela']),
      valorParcela: serializer.fromJson<double?>(json['valorParcela']),
      dataVencimento: serializer.fromJson<DateTime?>(json['dataVencimento']),
      dataRecebimento: serializer.fromJson<DateTime?>(json['dataRecebimento']),
      valorRecebido: serializer.fromJson<double?>(json['valorRecebido']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idFormaPagamento': serializer.toJson<int?>(idFormaPagamento),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'dataLancamento': serializer.toJson<DateTime?>(dataLancamento),
      'valorTotal': serializer.toJson<double?>(valorTotal),
      'numeroParcela': serializer.toJson<int?>(numeroParcela),
      'valorParcela': serializer.toJson<double?>(valorParcela),
      'dataVencimento': serializer.toJson<DateTime?>(dataVencimento),
      'dataRecebimento': serializer.toJson<DateTime?>(dataRecebimento),
      'valorRecebido': serializer.toJson<double?>(valorRecebido),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  ContasPagar copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idFormaPagamento = const Value.absent(),
          Value<int?> idBancoContaCaixa = const Value.absent(),
          Value<DateTime?> dataLancamento = const Value.absent(),
          Value<double?> valorTotal = const Value.absent(),
          Value<int?> numeroParcela = const Value.absent(),
          Value<double?> valorParcela = const Value.absent(),
          Value<DateTime?> dataVencimento = const Value.absent(),
          Value<DateTime?> dataRecebimento = const Value.absent(),
          Value<double?> valorRecebido = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      ContasPagar(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idFormaPagamento: idFormaPagamento.present
            ? idFormaPagamento.value
            : this.idFormaPagamento,
        idBancoContaCaixa: idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
        dataLancamento:
            dataLancamento.present ? dataLancamento.value : this.dataLancamento,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
        numeroParcela:
            numeroParcela.present ? numeroParcela.value : this.numeroParcela,
        valorParcela:
            valorParcela.present ? valorParcela.value : this.valorParcela,
        dataVencimento:
            dataVencimento.present ? dataVencimento.value : this.dataVencimento,
        dataRecebimento: dataRecebimento.present
            ? dataRecebimento.value
            : this.dataRecebimento,
        valorRecebido:
            valorRecebido.present ? valorRecebido.value : this.valorRecebido,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('ContasPagar(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idFormaPagamento: $idFormaPagamento, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('numeroParcela: $numeroParcela, ')
          ..write('valorParcela: $valorParcela, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataRecebimento: $dataRecebimento, ')
          ..write('valorRecebido: $valorRecebido, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      idFormaPagamento,
      idBancoContaCaixa,
      dataLancamento,
      valorTotal,
      numeroParcela,
      valorParcela,
      dataVencimento,
      dataRecebimento,
      valorRecebido,
      observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContasPagar &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.idFormaPagamento == this.idFormaPagamento &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.dataLancamento == this.dataLancamento &&
          other.valorTotal == this.valorTotal &&
          other.numeroParcela == this.numeroParcela &&
          other.valorParcela == this.valorParcela &&
          other.dataVencimento == this.dataVencimento &&
          other.dataRecebimento == this.dataRecebimento &&
          other.valorRecebido == this.valorRecebido &&
          other.observacao == this.observacao);
}

class ContasPagarsCompanion extends UpdateCompanion<ContasPagar> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<int?> idFormaPagamento;
  final Value<int?> idBancoContaCaixa;
  final Value<DateTime?> dataLancamento;
  final Value<double?> valorTotal;
  final Value<int?> numeroParcela;
  final Value<double?> valorParcela;
  final Value<DateTime?> dataVencimento;
  final Value<DateTime?> dataRecebimento;
  final Value<double?> valorRecebido;
  final Value<String?> observacao;
  const ContasPagarsCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idFormaPagamento = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.numeroParcela = const Value.absent(),
    this.valorParcela = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataRecebimento = const Value.absent(),
    this.valorRecebido = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  ContasPagarsCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idFormaPagamento = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.numeroParcela = const Value.absent(),
    this.valorParcela = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataRecebimento = const Value.absent(),
    this.valorRecebido = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<ContasPagar> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<int>? idFormaPagamento,
    Expression<int>? idBancoContaCaixa,
    Expression<DateTime>? dataLancamento,
    Expression<double>? valorTotal,
    Expression<int>? numeroParcela,
    Expression<double>? valorParcela,
    Expression<DateTime>? dataVencimento,
    Expression<DateTime>? dataRecebimento,
    Expression<double>? valorRecebido,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idFormaPagamento != null) 'id_forma_pagamento': idFormaPagamento,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (dataLancamento != null) 'data_lancamento': dataLancamento,
      if (valorTotal != null) 'valor_total': valorTotal,
      if (numeroParcela != null) 'numero_parcela': numeroParcela,
      if (valorParcela != null) 'valor_parcela': valorParcela,
      if (dataVencimento != null) 'data_vencimento': dataVencimento,
      if (dataRecebimento != null) 'data_recebimento': dataRecebimento,
      if (valorRecebido != null) 'valor_recebido': valorRecebido,
      if (observacao != null) 'observacao': observacao,
    });
  }

  ContasPagarsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<int?>? idFormaPagamento,
      Value<int?>? idBancoContaCaixa,
      Value<DateTime?>? dataLancamento,
      Value<double?>? valorTotal,
      Value<int?>? numeroParcela,
      Value<double?>? valorParcela,
      Value<DateTime?>? dataVencimento,
      Value<DateTime?>? dataRecebimento,
      Value<double?>? valorRecebido,
      Value<String?>? observacao}) {
    return ContasPagarsCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      idFormaPagamento: idFormaPagamento ?? this.idFormaPagamento,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      dataLancamento: dataLancamento ?? this.dataLancamento,
      valorTotal: valorTotal ?? this.valorTotal,
      numeroParcela: numeroParcela ?? this.numeroParcela,
      valorParcela: valorParcela ?? this.valorParcela,
      dataVencimento: dataVencimento ?? this.dataVencimento,
      dataRecebimento: dataRecebimento ?? this.dataRecebimento,
      valorRecebido: valorRecebido ?? this.valorRecebido,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idFormaPagamento.present) {
      map['id_forma_pagamento'] = Variable<int>(idFormaPagamento.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (dataLancamento.present) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    if (numeroParcela.present) {
      map['numero_parcela'] = Variable<int>(numeroParcela.value);
    }
    if (valorParcela.present) {
      map['valor_parcela'] = Variable<double>(valorParcela.value);
    }
    if (dataVencimento.present) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento.value);
    }
    if (dataRecebimento.present) {
      map['data_recebimento'] = Variable<DateTime>(dataRecebimento.value);
    }
    if (valorRecebido.present) {
      map['valor_recebido'] = Variable<double>(valorRecebido.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContasPagarsCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idFormaPagamento: $idFormaPagamento, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('numeroParcela: $numeroParcela, ')
          ..write('valorParcela: $valorParcela, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataRecebimento: $dataRecebimento, ')
          ..write('valorRecebido: $valorRecebido, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $TalaosTable extends Talaos with TableInfo<$TalaosTable, Talao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TalaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'ID', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _anoMeta = const VerificationMeta('ano');
  @override
  late final GeneratedColumn<String> ano = GeneratedColumn<String>(
      'ANO', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _sequenciaMeta =
      const VerificationMeta('sequencia');
  @override
  late final GeneratedColumn<int> sequencia = GeneratedColumn<int>(
      'SEQUENCIA', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, ano, sequencia];
  @override
  String get aliasedName => _alias ?? 'talao';
  @override
  String get actualTableName => 'talao';
  @override
  VerificationContext validateIntegrity(Insertable<Talao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('ID')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['ID']!, _idMeta));
    }
    if (data.containsKey('ANO')) {
      context.handle(
          _anoMeta, ano.isAcceptableOrUnknown(data['ANO']!, _anoMeta));
    }
    if (data.containsKey('SEQUENCIA')) {
      context.handle(_sequenciaMeta,
          sequencia.isAcceptableOrUnknown(data['SEQUENCIA']!, _sequenciaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Talao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Talao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}ID']),
      ano: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ANO']),
      sequencia: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}SEQUENCIA']),
    );
  }

  @override
  $TalaosTable createAlias(String alias) {
    return $TalaosTable(attachedDatabase, alias);
  }
}

class Talao extends DataClass implements Insertable<Talao> {
  final int? id;
  final String? ano;
  final int? sequencia;
  const Talao({this.id, this.ano, this.sequencia});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['ID'] = Variable<int>(id);
    }
    if (!nullToAbsent || ano != null) {
      map['ANO'] = Variable<String>(ano);
    }
    if (!nullToAbsent || sequencia != null) {
      map['SEQUENCIA'] = Variable<int>(sequencia);
    }
    return map;
  }

  factory Talao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Talao(
      id: serializer.fromJson<int?>(json['id']),
      ano: serializer.fromJson<String?>(json['ano']),
      sequencia: serializer.fromJson<int?>(json['sequencia']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'ano': serializer.toJson<String?>(ano),
      'sequencia': serializer.toJson<int?>(sequencia),
    };
  }

  Talao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> ano = const Value.absent(),
          Value<int?> sequencia = const Value.absent()}) =>
      Talao(
        id: id.present ? id.value : this.id,
        ano: ano.present ? ano.value : this.ano,
        sequencia: sequencia.present ? sequencia.value : this.sequencia,
      );
  @override
  String toString() {
    return (StringBuffer('Talao(')
          ..write('id: $id, ')
          ..write('ano: $ano, ')
          ..write('sequencia: $sequencia')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, ano, sequencia);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Talao &&
          other.id == this.id &&
          other.ano == this.ano &&
          other.sequencia == this.sequencia);
}

class TalaosCompanion extends UpdateCompanion<Talao> {
  final Value<int?> id;
  final Value<String?> ano;
  final Value<int?> sequencia;
  const TalaosCompanion({
    this.id = const Value.absent(),
    this.ano = const Value.absent(),
    this.sequencia = const Value.absent(),
  });
  TalaosCompanion.insert({
    this.id = const Value.absent(),
    this.ano = const Value.absent(),
    this.sequencia = const Value.absent(),
  });
  static Insertable<Talao> custom({
    Expression<int>? id,
    Expression<String>? ano,
    Expression<int>? sequencia,
  }) {
    return RawValuesInsertable({
      if (id != null) 'ID': id,
      if (ano != null) 'ANO': ano,
      if (sequencia != null) 'SEQUENCIA': sequencia,
    });
  }

  TalaosCompanion copyWith(
      {Value<int?>? id, Value<String?>? ano, Value<int?>? sequencia}) {
    return TalaosCompanion(
      id: id ?? this.id,
      ano: ano ?? this.ano,
      sequencia: sequencia ?? this.sequencia,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['ID'] = Variable<int>(id.value);
    }
    if (ano.present) {
      map['ANO'] = Variable<String>(ano.value);
    }
    if (sequencia.present) {
      map['SEQUENCIA'] = Variable<int>(sequencia.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TalaosCompanion(')
          ..write('id: $id, ')
          ..write('ano: $ano, ')
          ..write('sequencia: $sequencia')
          ..write(')'))
        .toString();
  }
}

class $ProdutosTable extends Produtos with TableInfo<$ProdutosTable, Produto> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMarcaMeta =
      const VerificationMeta('idProdutoMarca');
  @override
  late final GeneratedColumn<int> idProdutoMarca = GeneratedColumn<int>(
      'id_produto_marca', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoUnidadeMeta =
      const VerificationMeta('idProdutoUnidade');
  @override
  late final GeneratedColumn<int> idProdutoUnidade = GeneratedColumn<int>(
      'id_produto_unidade', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _gtinMeta = const VerificationMeta('gtin');
  @override
  late final GeneratedColumn<String> gtin = GeneratedColumn<String>(
      'gtin', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoInternoMeta =
      const VerificationMeta('codigoInterno');
  @override
  late final GeneratedColumn<String> codigoInterno = GeneratedColumn<String>(
      'codigo_interno', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorCompraMeta =
      const VerificationMeta('valorCompra');
  @override
  late final GeneratedColumn<double> valorCompra = GeneratedColumn<double>(
      'valor_compra', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorVendaMeta =
      const VerificationMeta('valorVenda');
  @override
  late final GeneratedColumn<double> valorVenda = GeneratedColumn<double>(
      'valor_venda', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _codigoNcmMeta =
      const VerificationMeta('codigoNcm');
  @override
  late final GeneratedColumn<String> codigoNcm = GeneratedColumn<String>(
      'codigo_ncm', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _estoqueMinimoMeta =
      const VerificationMeta('estoqueMinimo');
  @override
  late final GeneratedColumn<double> estoqueMinimo = GeneratedColumn<double>(
      'estoque_minimo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _estoqueMaximoMeta =
      const VerificationMeta('estoqueMaximo');
  @override
  late final GeneratedColumn<double> estoqueMaximo = GeneratedColumn<double>(
      'estoque_maximo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeEstoqueMeta =
      const VerificationMeta('quantidadeEstoque');
  @override
  late final GeneratedColumn<double> quantidadeEstoque =
      GeneratedColumn<double>('quantidade_estoque', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idProdutoMarca,
        idProdutoUnidade,
        idPessoa,
        nome,
        dataCadastro,
        descricao,
        gtin,
        codigoInterno,
        valorCompra,
        valorVenda,
        codigoNcm,
        estoqueMinimo,
        estoqueMaximo,
        quantidadeEstoque
      ];
  @override
  String get aliasedName => _alias ?? 'produto';
  @override
  String get actualTableName => 'produto';
  @override
  VerificationContext validateIntegrity(Insertable<Produto> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto_marca')) {
      context.handle(
          _idProdutoMarcaMeta,
          idProdutoMarca.isAcceptableOrUnknown(
              data['id_produto_marca']!, _idProdutoMarcaMeta));
    }
    if (data.containsKey('id_produto_unidade')) {
      context.handle(
          _idProdutoUnidadeMeta,
          idProdutoUnidade.isAcceptableOrUnknown(
              data['id_produto_unidade']!, _idProdutoUnidadeMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('gtin')) {
      context.handle(
          _gtinMeta, gtin.isAcceptableOrUnknown(data['gtin']!, _gtinMeta));
    }
    if (data.containsKey('codigo_interno')) {
      context.handle(
          _codigoInternoMeta,
          codigoInterno.isAcceptableOrUnknown(
              data['codigo_interno']!, _codigoInternoMeta));
    }
    if (data.containsKey('valor_compra')) {
      context.handle(
          _valorCompraMeta,
          valorCompra.isAcceptableOrUnknown(
              data['valor_compra']!, _valorCompraMeta));
    }
    if (data.containsKey('valor_venda')) {
      context.handle(
          _valorVendaMeta,
          valorVenda.isAcceptableOrUnknown(
              data['valor_venda']!, _valorVendaMeta));
    }
    if (data.containsKey('codigo_ncm')) {
      context.handle(_codigoNcmMeta,
          codigoNcm.isAcceptableOrUnknown(data['codigo_ncm']!, _codigoNcmMeta));
    }
    if (data.containsKey('estoque_minimo')) {
      context.handle(
          _estoqueMinimoMeta,
          estoqueMinimo.isAcceptableOrUnknown(
              data['estoque_minimo']!, _estoqueMinimoMeta));
    }
    if (data.containsKey('estoque_maximo')) {
      context.handle(
          _estoqueMaximoMeta,
          estoqueMaximo.isAcceptableOrUnknown(
              data['estoque_maximo']!, _estoqueMaximoMeta));
    }
    if (data.containsKey('quantidade_estoque')) {
      context.handle(
          _quantidadeEstoqueMeta,
          quantidadeEstoque.isAcceptableOrUnknown(
              data['quantidade_estoque']!, _quantidadeEstoqueMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Produto map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Produto(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idProdutoMarca: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_marca']),
      idProdutoUnidade: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_unidade']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      gtin: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gtin']),
      codigoInterno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_interno']),
      valorCompra: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_compra']),
      valorVenda: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_venda']),
      codigoNcm: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_ncm']),
      estoqueMinimo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}estoque_minimo']),
      estoqueMaximo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}estoque_maximo']),
      quantidadeEstoque: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}quantidade_estoque']),
    );
  }

  @override
  $ProdutosTable createAlias(String alias) {
    return $ProdutosTable(attachedDatabase, alias);
  }
}

class Produto extends DataClass implements Insertable<Produto> {
  final int? id;
  final int? idProdutoMarca;
  final int? idProdutoUnidade;
  final int? idPessoa;
  final String? nome;
  final DateTime? dataCadastro;
  final String? descricao;
  final String? gtin;
  final String? codigoInterno;
  final double? valorCompra;
  final double? valorVenda;
  final String? codigoNcm;
  final double? estoqueMinimo;
  final double? estoqueMaximo;
  final double? quantidadeEstoque;
  const Produto(
      {this.id,
      this.idProdutoMarca,
      this.idProdutoUnidade,
      this.idPessoa,
      this.nome,
      this.dataCadastro,
      this.descricao,
      this.gtin,
      this.codigoInterno,
      this.valorCompra,
      this.valorVenda,
      this.codigoNcm,
      this.estoqueMinimo,
      this.estoqueMaximo,
      this.quantidadeEstoque});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProdutoMarca != null) {
      map['id_produto_marca'] = Variable<int>(idProdutoMarca);
    }
    if (!nullToAbsent || idProdutoUnidade != null) {
      map['id_produto_unidade'] = Variable<int>(idProdutoUnidade);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || gtin != null) {
      map['gtin'] = Variable<String>(gtin);
    }
    if (!nullToAbsent || codigoInterno != null) {
      map['codigo_interno'] = Variable<String>(codigoInterno);
    }
    if (!nullToAbsent || valorCompra != null) {
      map['valor_compra'] = Variable<double>(valorCompra);
    }
    if (!nullToAbsent || valorVenda != null) {
      map['valor_venda'] = Variable<double>(valorVenda);
    }
    if (!nullToAbsent || codigoNcm != null) {
      map['codigo_ncm'] = Variable<String>(codigoNcm);
    }
    if (!nullToAbsent || estoqueMinimo != null) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo);
    }
    if (!nullToAbsent || estoqueMaximo != null) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo);
    }
    if (!nullToAbsent || quantidadeEstoque != null) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque);
    }
    return map;
  }

  factory Produto.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Produto(
      id: serializer.fromJson<int?>(json['id']),
      idProdutoMarca: serializer.fromJson<int?>(json['idProdutoMarca']),
      idProdutoUnidade: serializer.fromJson<int?>(json['idProdutoUnidade']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      nome: serializer.fromJson<String?>(json['nome']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      gtin: serializer.fromJson<String?>(json['gtin']),
      codigoInterno: serializer.fromJson<String?>(json['codigoInterno']),
      valorCompra: serializer.fromJson<double?>(json['valorCompra']),
      valorVenda: serializer.fromJson<double?>(json['valorVenda']),
      codigoNcm: serializer.fromJson<String?>(json['codigoNcm']),
      estoqueMinimo: serializer.fromJson<double?>(json['estoqueMinimo']),
      estoqueMaximo: serializer.fromJson<double?>(json['estoqueMaximo']),
      quantidadeEstoque:
          serializer.fromJson<double?>(json['quantidadeEstoque']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProdutoMarca': serializer.toJson<int?>(idProdutoMarca),
      'idProdutoUnidade': serializer.toJson<int?>(idProdutoUnidade),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'nome': serializer.toJson<String?>(nome),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'descricao': serializer.toJson<String?>(descricao),
      'gtin': serializer.toJson<String?>(gtin),
      'codigoInterno': serializer.toJson<String?>(codigoInterno),
      'valorCompra': serializer.toJson<double?>(valorCompra),
      'valorVenda': serializer.toJson<double?>(valorVenda),
      'codigoNcm': serializer.toJson<String?>(codigoNcm),
      'estoqueMinimo': serializer.toJson<double?>(estoqueMinimo),
      'estoqueMaximo': serializer.toJson<double?>(estoqueMaximo),
      'quantidadeEstoque': serializer.toJson<double?>(quantidadeEstoque),
    };
  }

  Produto copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idProdutoMarca = const Value.absent(),
          Value<int?> idProdutoUnidade = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> gtin = const Value.absent(),
          Value<String?> codigoInterno = const Value.absent(),
          Value<double?> valorCompra = const Value.absent(),
          Value<double?> valorVenda = const Value.absent(),
          Value<String?> codigoNcm = const Value.absent(),
          Value<double?> estoqueMinimo = const Value.absent(),
          Value<double?> estoqueMaximo = const Value.absent(),
          Value<double?> quantidadeEstoque = const Value.absent()}) =>
      Produto(
        id: id.present ? id.value : this.id,
        idProdutoMarca:
            idProdutoMarca.present ? idProdutoMarca.value : this.idProdutoMarca,
        idProdutoUnidade: idProdutoUnidade.present
            ? idProdutoUnidade.value
            : this.idProdutoUnidade,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        nome: nome.present ? nome.value : this.nome,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        descricao: descricao.present ? descricao.value : this.descricao,
        gtin: gtin.present ? gtin.value : this.gtin,
        codigoInterno:
            codigoInterno.present ? codigoInterno.value : this.codigoInterno,
        valorCompra: valorCompra.present ? valorCompra.value : this.valorCompra,
        valorVenda: valorVenda.present ? valorVenda.value : this.valorVenda,
        codigoNcm: codigoNcm.present ? codigoNcm.value : this.codigoNcm,
        estoqueMinimo:
            estoqueMinimo.present ? estoqueMinimo.value : this.estoqueMinimo,
        estoqueMaximo:
            estoqueMaximo.present ? estoqueMaximo.value : this.estoqueMaximo,
        quantidadeEstoque: quantidadeEstoque.present
            ? quantidadeEstoque.value
            : this.quantidadeEstoque,
      );
  @override
  String toString() {
    return (StringBuffer('Produto(')
          ..write('id: $id, ')
          ..write('idProdutoMarca: $idProdutoMarca, ')
          ..write('idProdutoUnidade: $idProdutoUnidade, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('nome: $nome, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idProdutoMarca,
      idProdutoUnidade,
      idPessoa,
      nome,
      dataCadastro,
      descricao,
      gtin,
      codigoInterno,
      valorCompra,
      valorVenda,
      codigoNcm,
      estoqueMinimo,
      estoqueMaximo,
      quantidadeEstoque);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Produto &&
          other.id == this.id &&
          other.idProdutoMarca == this.idProdutoMarca &&
          other.idProdutoUnidade == this.idProdutoUnidade &&
          other.idPessoa == this.idPessoa &&
          other.nome == this.nome &&
          other.dataCadastro == this.dataCadastro &&
          other.descricao == this.descricao &&
          other.gtin == this.gtin &&
          other.codigoInterno == this.codigoInterno &&
          other.valorCompra == this.valorCompra &&
          other.valorVenda == this.valorVenda &&
          other.codigoNcm == this.codigoNcm &&
          other.estoqueMinimo == this.estoqueMinimo &&
          other.estoqueMaximo == this.estoqueMaximo &&
          other.quantidadeEstoque == this.quantidadeEstoque);
}

class ProdutosCompanion extends UpdateCompanion<Produto> {
  final Value<int?> id;
  final Value<int?> idProdutoMarca;
  final Value<int?> idProdutoUnidade;
  final Value<int?> idPessoa;
  final Value<String?> nome;
  final Value<DateTime?> dataCadastro;
  final Value<String?> descricao;
  final Value<String?> gtin;
  final Value<String?> codigoInterno;
  final Value<double?> valorCompra;
  final Value<double?> valorVenda;
  final Value<String?> codigoNcm;
  final Value<double?> estoqueMinimo;
  final Value<double?> estoqueMaximo;
  final Value<double?> quantidadeEstoque;
  const ProdutosCompanion({
    this.id = const Value.absent(),
    this.idProdutoMarca = const Value.absent(),
    this.idProdutoUnidade = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
  });
  ProdutosCompanion.insert({
    this.id = const Value.absent(),
    this.idProdutoMarca = const Value.absent(),
    this.idProdutoUnidade = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
  });
  static Insertable<Produto> custom({
    Expression<int>? id,
    Expression<int>? idProdutoMarca,
    Expression<int>? idProdutoUnidade,
    Expression<int>? idPessoa,
    Expression<String>? nome,
    Expression<DateTime>? dataCadastro,
    Expression<String>? descricao,
    Expression<String>? gtin,
    Expression<String>? codigoInterno,
    Expression<double>? valorCompra,
    Expression<double>? valorVenda,
    Expression<String>? codigoNcm,
    Expression<double>? estoqueMinimo,
    Expression<double>? estoqueMaximo,
    Expression<double>? quantidadeEstoque,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProdutoMarca != null) 'id_produto_marca': idProdutoMarca,
      if (idProdutoUnidade != null) 'id_produto_unidade': idProdutoUnidade,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (nome != null) 'nome': nome,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (descricao != null) 'descricao': descricao,
      if (gtin != null) 'gtin': gtin,
      if (codigoInterno != null) 'codigo_interno': codigoInterno,
      if (valorCompra != null) 'valor_compra': valorCompra,
      if (valorVenda != null) 'valor_venda': valorVenda,
      if (codigoNcm != null) 'codigo_ncm': codigoNcm,
      if (estoqueMinimo != null) 'estoque_minimo': estoqueMinimo,
      if (estoqueMaximo != null) 'estoque_maximo': estoqueMaximo,
      if (quantidadeEstoque != null) 'quantidade_estoque': quantidadeEstoque,
    });
  }

  ProdutosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idProdutoMarca,
      Value<int?>? idProdutoUnidade,
      Value<int?>? idPessoa,
      Value<String?>? nome,
      Value<DateTime?>? dataCadastro,
      Value<String?>? descricao,
      Value<String?>? gtin,
      Value<String?>? codigoInterno,
      Value<double?>? valorCompra,
      Value<double?>? valorVenda,
      Value<String?>? codigoNcm,
      Value<double?>? estoqueMinimo,
      Value<double?>? estoqueMaximo,
      Value<double?>? quantidadeEstoque}) {
    return ProdutosCompanion(
      id: id ?? this.id,
      idProdutoMarca: idProdutoMarca ?? this.idProdutoMarca,
      idProdutoUnidade: idProdutoUnidade ?? this.idProdutoUnidade,
      idPessoa: idPessoa ?? this.idPessoa,
      nome: nome ?? this.nome,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      descricao: descricao ?? this.descricao,
      gtin: gtin ?? this.gtin,
      codigoInterno: codigoInterno ?? this.codigoInterno,
      valorCompra: valorCompra ?? this.valorCompra,
      valorVenda: valorVenda ?? this.valorVenda,
      codigoNcm: codigoNcm ?? this.codigoNcm,
      estoqueMinimo: estoqueMinimo ?? this.estoqueMinimo,
      estoqueMaximo: estoqueMaximo ?? this.estoqueMaximo,
      quantidadeEstoque: quantidadeEstoque ?? this.quantidadeEstoque,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProdutoMarca.present) {
      map['id_produto_marca'] = Variable<int>(idProdutoMarca.value);
    }
    if (idProdutoUnidade.present) {
      map['id_produto_unidade'] = Variable<int>(idProdutoUnidade.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (gtin.present) {
      map['gtin'] = Variable<String>(gtin.value);
    }
    if (codigoInterno.present) {
      map['codigo_interno'] = Variable<String>(codigoInterno.value);
    }
    if (valorCompra.present) {
      map['valor_compra'] = Variable<double>(valorCompra.value);
    }
    if (valorVenda.present) {
      map['valor_venda'] = Variable<double>(valorVenda.value);
    }
    if (codigoNcm.present) {
      map['codigo_ncm'] = Variable<String>(codigoNcm.value);
    }
    if (estoqueMinimo.present) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo.value);
    }
    if (estoqueMaximo.present) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo.value);
    }
    if (quantidadeEstoque.present) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutosCompanion(')
          ..write('id: $id, ')
          ..write('idProdutoMarca: $idProdutoMarca, ')
          ..write('idProdutoUnidade: $idProdutoUnidade, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('nome: $nome, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque')
          ..write(')'))
        .toString();
  }
}

class $ContasRecebersTable extends ContasRecebers
    with TableInfo<$ContasRecebersTable, ContasReceber> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContasRecebersTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFormaPagamentoMeta =
      const VerificationMeta('idFormaPagamento');
  @override
  late final GeneratedColumn<int> idFormaPagamento = GeneratedColumn<int>(
      'id_forma_pagamento', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendaCabecalhoMeta =
      const VerificationMeta('idVendaCabecalho');
  @override
  late final GeneratedColumn<int> idVendaCabecalho = GeneratedColumn<int>(
      'id_venda_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idBancoContaCaixaMeta =
      const VerificationMeta('idBancoContaCaixa');
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
      'id_banco_conta_caixa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataLancamentoMeta =
      const VerificationMeta('dataLancamento');
  @override
  late final GeneratedColumn<DateTime> dataLancamento =
      GeneratedColumn<DateTime>('data_lancamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _numeroParcelaMeta =
      const VerificationMeta('numeroParcela');
  @override
  late final GeneratedColumn<int> numeroParcela = GeneratedColumn<int>(
      'numero_parcela', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorParcelaMeta =
      const VerificationMeta('valorParcela');
  @override
  late final GeneratedColumn<double> valorParcela = GeneratedColumn<double>(
      'valor_parcela', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataVencimentoMeta =
      const VerificationMeta('dataVencimento');
  @override
  late final GeneratedColumn<DateTime> dataVencimento =
      GeneratedColumn<DateTime>('data_vencimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataRecebimentoMeta =
      const VerificationMeta('dataRecebimento');
  @override
  late final GeneratedColumn<DateTime> dataRecebimento =
      GeneratedColumn<DateTime>('data_recebimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorRecebidoMeta =
      const VerificationMeta('valorRecebido');
  @override
  late final GeneratedColumn<double> valorRecebido = GeneratedColumn<double>(
      'valor_recebido', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        idFormaPagamento,
        idVendaCabecalho,
        idBancoContaCaixa,
        dataLancamento,
        valorTotal,
        numeroParcela,
        valorParcela,
        dataVencimento,
        dataRecebimento,
        valorRecebido,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? 'contas_receber';
  @override
  String get actualTableName => 'contas_receber';
  @override
  VerificationContext validateIntegrity(Insertable<ContasReceber> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_forma_pagamento')) {
      context.handle(
          _idFormaPagamentoMeta,
          idFormaPagamento.isAcceptableOrUnknown(
              data['id_forma_pagamento']!, _idFormaPagamentoMeta));
    }
    if (data.containsKey('id_venda_cabecalho')) {
      context.handle(
          _idVendaCabecalhoMeta,
          idVendaCabecalho.isAcceptableOrUnknown(
              data['id_venda_cabecalho']!, _idVendaCabecalhoMeta));
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
          _idBancoContaCaixaMeta,
          idBancoContaCaixa.isAcceptableOrUnknown(
              data['id_banco_conta_caixa']!, _idBancoContaCaixaMeta));
    }
    if (data.containsKey('data_lancamento')) {
      context.handle(
          _dataLancamentoMeta,
          dataLancamento.isAcceptableOrUnknown(
              data['data_lancamento']!, _dataLancamentoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    if (data.containsKey('numero_parcela')) {
      context.handle(
          _numeroParcelaMeta,
          numeroParcela.isAcceptableOrUnknown(
              data['numero_parcela']!, _numeroParcelaMeta));
    }
    if (data.containsKey('valor_parcela')) {
      context.handle(
          _valorParcelaMeta,
          valorParcela.isAcceptableOrUnknown(
              data['valor_parcela']!, _valorParcelaMeta));
    }
    if (data.containsKey('data_vencimento')) {
      context.handle(
          _dataVencimentoMeta,
          dataVencimento.isAcceptableOrUnknown(
              data['data_vencimento']!, _dataVencimentoMeta));
    }
    if (data.containsKey('data_recebimento')) {
      context.handle(
          _dataRecebimentoMeta,
          dataRecebimento.isAcceptableOrUnknown(
              data['data_recebimento']!, _dataRecebimentoMeta));
    }
    if (data.containsKey('valor_recebido')) {
      context.handle(
          _valorRecebidoMeta,
          valorRecebido.isAcceptableOrUnknown(
              data['valor_recebido']!, _valorRecebidoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContasReceber map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContasReceber(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idFormaPagamento: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_forma_pagamento']),
      idVendaCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_venda_cabecalho']),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_banco_conta_caixa']),
      dataLancamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_lancamento']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
      numeroParcela: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero_parcela']),
      valorParcela: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_parcela']),
      dataVencimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_vencimento']),
      dataRecebimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_recebimento']),
      valorRecebido: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_recebido']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $ContasRecebersTable createAlias(String alias) {
    return $ContasRecebersTable(attachedDatabase, alias);
  }
}

class ContasReceber extends DataClass implements Insertable<ContasReceber> {
  final int? id;
  final int? idPessoa;
  final int? idFormaPagamento;
  final int? idVendaCabecalho;
  final int? idBancoContaCaixa;
  final DateTime? dataLancamento;
  final double? valorTotal;
  final int? numeroParcela;
  final double? valorParcela;
  final DateTime? dataVencimento;
  final DateTime? dataRecebimento;
  final double? valorRecebido;
  final String? observacao;
  const ContasReceber(
      {this.id,
      this.idPessoa,
      this.idFormaPagamento,
      this.idVendaCabecalho,
      this.idBancoContaCaixa,
      this.dataLancamento,
      this.valorTotal,
      this.numeroParcela,
      this.valorParcela,
      this.dataVencimento,
      this.dataRecebimento,
      this.valorRecebido,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idFormaPagamento != null) {
      map['id_forma_pagamento'] = Variable<int>(idFormaPagamento);
    }
    if (!nullToAbsent || idVendaCabecalho != null) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || dataLancamento != null) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    if (!nullToAbsent || numeroParcela != null) {
      map['numero_parcela'] = Variable<int>(numeroParcela);
    }
    if (!nullToAbsent || valorParcela != null) {
      map['valor_parcela'] = Variable<double>(valorParcela);
    }
    if (!nullToAbsent || dataVencimento != null) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento);
    }
    if (!nullToAbsent || dataRecebimento != null) {
      map['data_recebimento'] = Variable<DateTime>(dataRecebimento);
    }
    if (!nullToAbsent || valorRecebido != null) {
      map['valor_recebido'] = Variable<double>(valorRecebido);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory ContasReceber.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContasReceber(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idFormaPagamento: serializer.fromJson<int?>(json['idFormaPagamento']),
      idVendaCabecalho: serializer.fromJson<int?>(json['idVendaCabecalho']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      dataLancamento: serializer.fromJson<DateTime?>(json['dataLancamento']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
      numeroParcela: serializer.fromJson<int?>(json['numeroParcela']),
      valorParcela: serializer.fromJson<double?>(json['valorParcela']),
      dataVencimento: serializer.fromJson<DateTime?>(json['dataVencimento']),
      dataRecebimento: serializer.fromJson<DateTime?>(json['dataRecebimento']),
      valorRecebido: serializer.fromJson<double?>(json['valorRecebido']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idFormaPagamento': serializer.toJson<int?>(idFormaPagamento),
      'idVendaCabecalho': serializer.toJson<int?>(idVendaCabecalho),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'dataLancamento': serializer.toJson<DateTime?>(dataLancamento),
      'valorTotal': serializer.toJson<double?>(valorTotal),
      'numeroParcela': serializer.toJson<int?>(numeroParcela),
      'valorParcela': serializer.toJson<double?>(valorParcela),
      'dataVencimento': serializer.toJson<DateTime?>(dataVencimento),
      'dataRecebimento': serializer.toJson<DateTime?>(dataRecebimento),
      'valorRecebido': serializer.toJson<double?>(valorRecebido),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  ContasReceber copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idFormaPagamento = const Value.absent(),
          Value<int?> idVendaCabecalho = const Value.absent(),
          Value<int?> idBancoContaCaixa = const Value.absent(),
          Value<DateTime?> dataLancamento = const Value.absent(),
          Value<double?> valorTotal = const Value.absent(),
          Value<int?> numeroParcela = const Value.absent(),
          Value<double?> valorParcela = const Value.absent(),
          Value<DateTime?> dataVencimento = const Value.absent(),
          Value<DateTime?> dataRecebimento = const Value.absent(),
          Value<double?> valorRecebido = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      ContasReceber(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idFormaPagamento: idFormaPagamento.present
            ? idFormaPagamento.value
            : this.idFormaPagamento,
        idVendaCabecalho: idVendaCabecalho.present
            ? idVendaCabecalho.value
            : this.idVendaCabecalho,
        idBancoContaCaixa: idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
        dataLancamento:
            dataLancamento.present ? dataLancamento.value : this.dataLancamento,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
        numeroParcela:
            numeroParcela.present ? numeroParcela.value : this.numeroParcela,
        valorParcela:
            valorParcela.present ? valorParcela.value : this.valorParcela,
        dataVencimento:
            dataVencimento.present ? dataVencimento.value : this.dataVencimento,
        dataRecebimento: dataRecebimento.present
            ? dataRecebimento.value
            : this.dataRecebimento,
        valorRecebido:
            valorRecebido.present ? valorRecebido.value : this.valorRecebido,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('ContasReceber(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idFormaPagamento: $idFormaPagamento, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('numeroParcela: $numeroParcela, ')
          ..write('valorParcela: $valorParcela, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataRecebimento: $dataRecebimento, ')
          ..write('valorRecebido: $valorRecebido, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      idFormaPagamento,
      idVendaCabecalho,
      idBancoContaCaixa,
      dataLancamento,
      valorTotal,
      numeroParcela,
      valorParcela,
      dataVencimento,
      dataRecebimento,
      valorRecebido,
      observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContasReceber &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.idFormaPagamento == this.idFormaPagamento &&
          other.idVendaCabecalho == this.idVendaCabecalho &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.dataLancamento == this.dataLancamento &&
          other.valorTotal == this.valorTotal &&
          other.numeroParcela == this.numeroParcela &&
          other.valorParcela == this.valorParcela &&
          other.dataVencimento == this.dataVencimento &&
          other.dataRecebimento == this.dataRecebimento &&
          other.valorRecebido == this.valorRecebido &&
          other.observacao == this.observacao);
}

class ContasRecebersCompanion extends UpdateCompanion<ContasReceber> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<int?> idFormaPagamento;
  final Value<int?> idVendaCabecalho;
  final Value<int?> idBancoContaCaixa;
  final Value<DateTime?> dataLancamento;
  final Value<double?> valorTotal;
  final Value<int?> numeroParcela;
  final Value<double?> valorParcela;
  final Value<DateTime?> dataVencimento;
  final Value<DateTime?> dataRecebimento;
  final Value<double?> valorRecebido;
  final Value<String?> observacao;
  const ContasRecebersCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idFormaPagamento = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.numeroParcela = const Value.absent(),
    this.valorParcela = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataRecebimento = const Value.absent(),
    this.valorRecebido = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  ContasRecebersCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idFormaPagamento = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.numeroParcela = const Value.absent(),
    this.valorParcela = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataRecebimento = const Value.absent(),
    this.valorRecebido = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<ContasReceber> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<int>? idFormaPagamento,
    Expression<int>? idVendaCabecalho,
    Expression<int>? idBancoContaCaixa,
    Expression<DateTime>? dataLancamento,
    Expression<double>? valorTotal,
    Expression<int>? numeroParcela,
    Expression<double>? valorParcela,
    Expression<DateTime>? dataVencimento,
    Expression<DateTime>? dataRecebimento,
    Expression<double>? valorRecebido,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idFormaPagamento != null) 'id_forma_pagamento': idFormaPagamento,
      if (idVendaCabecalho != null) 'id_venda_cabecalho': idVendaCabecalho,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (dataLancamento != null) 'data_lancamento': dataLancamento,
      if (valorTotal != null) 'valor_total': valorTotal,
      if (numeroParcela != null) 'numero_parcela': numeroParcela,
      if (valorParcela != null) 'valor_parcela': valorParcela,
      if (dataVencimento != null) 'data_vencimento': dataVencimento,
      if (dataRecebimento != null) 'data_recebimento': dataRecebimento,
      if (valorRecebido != null) 'valor_recebido': valorRecebido,
      if (observacao != null) 'observacao': observacao,
    });
  }

  ContasRecebersCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<int?>? idFormaPagamento,
      Value<int?>? idVendaCabecalho,
      Value<int?>? idBancoContaCaixa,
      Value<DateTime?>? dataLancamento,
      Value<double?>? valorTotal,
      Value<int?>? numeroParcela,
      Value<double?>? valorParcela,
      Value<DateTime?>? dataVencimento,
      Value<DateTime?>? dataRecebimento,
      Value<double?>? valorRecebido,
      Value<String?>? observacao}) {
    return ContasRecebersCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      idFormaPagamento: idFormaPagamento ?? this.idFormaPagamento,
      idVendaCabecalho: idVendaCabecalho ?? this.idVendaCabecalho,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      dataLancamento: dataLancamento ?? this.dataLancamento,
      valorTotal: valorTotal ?? this.valorTotal,
      numeroParcela: numeroParcela ?? this.numeroParcela,
      valorParcela: valorParcela ?? this.valorParcela,
      dataVencimento: dataVencimento ?? this.dataVencimento,
      dataRecebimento: dataRecebimento ?? this.dataRecebimento,
      valorRecebido: valorRecebido ?? this.valorRecebido,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idFormaPagamento.present) {
      map['id_forma_pagamento'] = Variable<int>(idFormaPagamento.value);
    }
    if (idVendaCabecalho.present) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (dataLancamento.present) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    if (numeroParcela.present) {
      map['numero_parcela'] = Variable<int>(numeroParcela.value);
    }
    if (valorParcela.present) {
      map['valor_parcela'] = Variable<double>(valorParcela.value);
    }
    if (dataVencimento.present) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento.value);
    }
    if (dataRecebimento.present) {
      map['data_recebimento'] = Variable<DateTime>(dataRecebimento.value);
    }
    if (valorRecebido.present) {
      map['valor_recebido'] = Variable<double>(valorRecebido.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContasRecebersCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idFormaPagamento: $idFormaPagamento, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('numeroParcela: $numeroParcela, ')
          ..write('valorParcela: $valorParcela, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataRecebimento: $dataRecebimento, ')
          ..write('valorRecebido: $valorRecebido, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoMarcasTable extends ProdutoMarcas
    with TableInfo<$ProdutoMarcasTable, ProdutoMarca> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoMarcasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? 'produto_marca';
  @override
  String get actualTableName => 'produto_marca';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoMarca> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoMarca map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoMarca(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoMarcasTable createAlias(String alias) {
    return $ProdutoMarcasTable(attachedDatabase, alias);
  }
}

class ProdutoMarca extends DataClass implements Insertable<ProdutoMarca> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ProdutoMarca({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoMarca.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoMarca(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoMarca copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoMarca(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoMarca(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoMarca &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoMarcasCompanion extends UpdateCompanion<ProdutoMarca> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoMarcasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoMarcasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoMarca> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoMarcasCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ProdutoMarcasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoMarcasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $BancoAgenciasTable extends BancoAgencias
    with TableInfo<$BancoAgenciasTable, BancoAgencia> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BancoAgenciasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idBancoMeta =
      const VerificationMeta('idBanco');
  @override
  late final GeneratedColumn<int> idBanco = GeneratedColumn<int>(
      'id_banco', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _digitoMeta = const VerificationMeta('digito');
  @override
  late final GeneratedColumn<String> digito = GeneratedColumn<String>(
      'digito', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _telefoneMeta =
      const VerificationMeta('telefone');
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
      'telefone', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contatoMeta =
      const VerificationMeta('contato');
  @override
  late final GeneratedColumn<String> contato = GeneratedColumn<String>(
      'contato', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _gerenteMeta =
      const VerificationMeta('gerente');
  @override
  late final GeneratedColumn<String> gerente = GeneratedColumn<String>(
      'gerente', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idBanco,
        numero,
        digito,
        nome,
        telefone,
        contato,
        gerente,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? 'banco_agencia';
  @override
  String get actualTableName => 'banco_agencia';
  @override
  VerificationContext validateIntegrity(Insertable<BancoAgencia> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco')) {
      context.handle(_idBancoMeta,
          idBanco.isAcceptableOrUnknown(data['id_banco']!, _idBancoMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('digito')) {
      context.handle(_digitoMeta,
          digito.isAcceptableOrUnknown(data['digito']!, _digitoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('telefone')) {
      context.handle(_telefoneMeta,
          telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta));
    }
    if (data.containsKey('contato')) {
      context.handle(_contatoMeta,
          contato.isAcceptableOrUnknown(data['contato']!, _contatoMeta));
    }
    if (data.containsKey('gerente')) {
      context.handle(_gerenteMeta,
          gerente.isAcceptableOrUnknown(data['gerente']!, _gerenteMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BancoAgencia map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BancoAgencia(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idBanco: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_banco']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      digito: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}digito']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      telefone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}telefone']),
      contato: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}contato']),
      gerente: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gerente']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $BancoAgenciasTable createAlias(String alias) {
    return $BancoAgenciasTable(attachedDatabase, alias);
  }
}

class BancoAgencia extends DataClass implements Insertable<BancoAgencia> {
  final int? id;
  final int? idBanco;
  final String? numero;
  final String? digito;
  final String? nome;
  final String? telefone;
  final String? contato;
  final String? gerente;
  final String? observacao;
  const BancoAgencia(
      {this.id,
      this.idBanco,
      this.numero,
      this.digito,
      this.nome,
      this.telefone,
      this.contato,
      this.gerente,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBanco != null) {
      map['id_banco'] = Variable<int>(idBanco);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || digito != null) {
      map['digito'] = Variable<String>(digito);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || contato != null) {
      map['contato'] = Variable<String>(contato);
    }
    if (!nullToAbsent || gerente != null) {
      map['gerente'] = Variable<String>(gerente);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory BancoAgencia.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BancoAgencia(
      id: serializer.fromJson<int?>(json['id']),
      idBanco: serializer.fromJson<int?>(json['idBanco']),
      numero: serializer.fromJson<String?>(json['numero']),
      digito: serializer.fromJson<String?>(json['digito']),
      nome: serializer.fromJson<String?>(json['nome']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      contato: serializer.fromJson<String?>(json['contato']),
      gerente: serializer.fromJson<String?>(json['gerente']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBanco': serializer.toJson<int?>(idBanco),
      'numero': serializer.toJson<String?>(numero),
      'digito': serializer.toJson<String?>(digito),
      'nome': serializer.toJson<String?>(nome),
      'telefone': serializer.toJson<String?>(telefone),
      'contato': serializer.toJson<String?>(contato),
      'gerente': serializer.toJson<String?>(gerente),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  BancoAgencia copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idBanco = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> digito = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> telefone = const Value.absent(),
          Value<String?> contato = const Value.absent(),
          Value<String?> gerente = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      BancoAgencia(
        id: id.present ? id.value : this.id,
        idBanco: idBanco.present ? idBanco.value : this.idBanco,
        numero: numero.present ? numero.value : this.numero,
        digito: digito.present ? digito.value : this.digito,
        nome: nome.present ? nome.value : this.nome,
        telefone: telefone.present ? telefone.value : this.telefone,
        contato: contato.present ? contato.value : this.contato,
        gerente: gerente.present ? gerente.value : this.gerente,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('BancoAgencia(')
          ..write('id: $id, ')
          ..write('idBanco: $idBanco, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('nome: $nome, ')
          ..write('telefone: $telefone, ')
          ..write('contato: $contato, ')
          ..write('gerente: $gerente, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idBanco, numero, digito, nome, telefone,
      contato, gerente, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BancoAgencia &&
          other.id == this.id &&
          other.idBanco == this.idBanco &&
          other.numero == this.numero &&
          other.digito == this.digito &&
          other.nome == this.nome &&
          other.telefone == this.telefone &&
          other.contato == this.contato &&
          other.gerente == this.gerente &&
          other.observacao == this.observacao);
}

class BancoAgenciasCompanion extends UpdateCompanion<BancoAgencia> {
  final Value<int?> id;
  final Value<int?> idBanco;
  final Value<String?> numero;
  final Value<String?> digito;
  final Value<String?> nome;
  final Value<String?> telefone;
  final Value<String?> contato;
  final Value<String?> gerente;
  final Value<String?> observacao;
  const BancoAgenciasCompanion({
    this.id = const Value.absent(),
    this.idBanco = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.nome = const Value.absent(),
    this.telefone = const Value.absent(),
    this.contato = const Value.absent(),
    this.gerente = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  BancoAgenciasCompanion.insert({
    this.id = const Value.absent(),
    this.idBanco = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.nome = const Value.absent(),
    this.telefone = const Value.absent(),
    this.contato = const Value.absent(),
    this.gerente = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<BancoAgencia> custom({
    Expression<int>? id,
    Expression<int>? idBanco,
    Expression<String>? numero,
    Expression<String>? digito,
    Expression<String>? nome,
    Expression<String>? telefone,
    Expression<String>? contato,
    Expression<String>? gerente,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBanco != null) 'id_banco': idBanco,
      if (numero != null) 'numero': numero,
      if (digito != null) 'digito': digito,
      if (nome != null) 'nome': nome,
      if (telefone != null) 'telefone': telefone,
      if (contato != null) 'contato': contato,
      if (gerente != null) 'gerente': gerente,
      if (observacao != null) 'observacao': observacao,
    });
  }

  BancoAgenciasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idBanco,
      Value<String?>? numero,
      Value<String?>? digito,
      Value<String?>? nome,
      Value<String?>? telefone,
      Value<String?>? contato,
      Value<String?>? gerente,
      Value<String?>? observacao}) {
    return BancoAgenciasCompanion(
      id: id ?? this.id,
      idBanco: idBanco ?? this.idBanco,
      numero: numero ?? this.numero,
      digito: digito ?? this.digito,
      nome: nome ?? this.nome,
      telefone: telefone ?? this.telefone,
      contato: contato ?? this.contato,
      gerente: gerente ?? this.gerente,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBanco.present) {
      map['id_banco'] = Variable<int>(idBanco.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (digito.present) {
      map['digito'] = Variable<String>(digito.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (contato.present) {
      map['contato'] = Variable<String>(contato.value);
    }
    if (gerente.present) {
      map['gerente'] = Variable<String>(gerente.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BancoAgenciasCompanion(')
          ..write('id: $id, ')
          ..write('idBanco: $idBanco, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('nome: $nome, ')
          ..write('telefone: $telefone, ')
          ..write('contato: $contato, ')
          ..write('gerente: $gerente, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $EmpresasTable extends Empresas with TableInfo<$EmpresasTable, Empresa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EmpresasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _razaoSocialMeta =
      const VerificationMeta('razaoSocial');
  @override
  late final GeneratedColumn<String> razaoSocial = GeneratedColumn<String>(
      'razao_social', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeFantasiaMeta =
      const VerificationMeta('nomeFantasia');
  @override
  late final GeneratedColumn<String> nomeFantasia = GeneratedColumn<String>(
      'nome_fantasia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 18),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _inscricaoEstadualMeta =
      const VerificationMeta('inscricaoEstadual');
  @override
  late final GeneratedColumn<String> inscricaoEstadual =
      GeneratedColumn<String>('inscricao_estadual', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 45),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _inscricaoMunicipalMeta =
      const VerificationMeta('inscricaoMunicipal');
  @override
  late final GeneratedColumn<String> inscricaoMunicipal =
      GeneratedColumn<String>('inscricao_municipal', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 45),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _tipoRegimeMeta =
      const VerificationMeta('tipoRegime');
  @override
  late final GeneratedColumn<String> tipoRegime = GeneratedColumn<String>(
      'tipo_regime', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _crtMeta = const VerificationMeta('crt');
  @override
  late final GeneratedColumn<String> crt = GeneratedColumn<String>(
      'crt', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contatoMeta =
      const VerificationMeta('contato');
  @override
  late final GeneratedColumn<String> contato = GeneratedColumn<String>(
      'contato', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataConstituicaoMeta =
      const VerificationMeta('dataConstituicao');
  @override
  late final GeneratedColumn<DateTime> dataConstituicao =
      GeneratedColumn<DateTime>('data_constituicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _codigoIbgeCidadeMeta =
      const VerificationMeta('codigoIbgeCidade');
  @override
  late final GeneratedColumn<int> codigoIbgeCidade = GeneratedColumn<int>(
      'codigo_ibge_cidade', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoIbgeUfMeta =
      const VerificationMeta('codigoIbgeUf');
  @override
  late final GeneratedColumn<int> codigoIbgeUf = GeneratedColumn<int>(
      'codigo_ibge_uf', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ceiMeta = const VerificationMeta('cei');
  @override
  late final GeneratedColumn<String> cei = GeneratedColumn<String>(
      'cei', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 12),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoCnaePrincipalMeta =
      const VerificationMeta('codigoCnaePrincipal');
  @override
  late final GeneratedColumn<String> codigoCnaePrincipal =
      GeneratedColumn<String>('codigo_cnae_principal', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 7),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _imagemLogotipoMeta =
      const VerificationMeta('imagemLogotipo');
  @override
  late final GeneratedColumn<Uint8List> imagemLogotipo =
      GeneratedColumn<Uint8List>('imagem_logotipo', aliasedName, true,
          type: DriftSqlType.blob, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        razaoSocial,
        nomeFantasia,
        cnpj,
        inscricaoEstadual,
        inscricaoMunicipal,
        tipoRegime,
        crt,
        email,
        site,
        contato,
        dataConstituicao,
        codigoIbgeCidade,
        codigoIbgeUf,
        cei,
        codigoCnaePrincipal,
        imagemLogotipo
      ];
  @override
  String get aliasedName => _alias ?? 'empresa';
  @override
  String get actualTableName => 'empresa';
  @override
  VerificationContext validateIntegrity(Insertable<Empresa> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('razao_social')) {
      context.handle(
          _razaoSocialMeta,
          razaoSocial.isAcceptableOrUnknown(
              data['razao_social']!, _razaoSocialMeta));
    }
    if (data.containsKey('nome_fantasia')) {
      context.handle(
          _nomeFantasiaMeta,
          nomeFantasia.isAcceptableOrUnknown(
              data['nome_fantasia']!, _nomeFantasiaMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('inscricao_estadual')) {
      context.handle(
          _inscricaoEstadualMeta,
          inscricaoEstadual.isAcceptableOrUnknown(
              data['inscricao_estadual']!, _inscricaoEstadualMeta));
    }
    if (data.containsKey('inscricao_municipal')) {
      context.handle(
          _inscricaoMunicipalMeta,
          inscricaoMunicipal.isAcceptableOrUnknown(
              data['inscricao_municipal']!, _inscricaoMunicipalMeta));
    }
    if (data.containsKey('tipo_regime')) {
      context.handle(
          _tipoRegimeMeta,
          tipoRegime.isAcceptableOrUnknown(
              data['tipo_regime']!, _tipoRegimeMeta));
    }
    if (data.containsKey('crt')) {
      context.handle(
          _crtMeta, crt.isAcceptableOrUnknown(data['crt']!, _crtMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('contato')) {
      context.handle(_contatoMeta,
          contato.isAcceptableOrUnknown(data['contato']!, _contatoMeta));
    }
    if (data.containsKey('data_constituicao')) {
      context.handle(
          _dataConstituicaoMeta,
          dataConstituicao.isAcceptableOrUnknown(
              data['data_constituicao']!, _dataConstituicaoMeta));
    }
    if (data.containsKey('codigo_ibge_cidade')) {
      context.handle(
          _codigoIbgeCidadeMeta,
          codigoIbgeCidade.isAcceptableOrUnknown(
              data['codigo_ibge_cidade']!, _codigoIbgeCidadeMeta));
    }
    if (data.containsKey('codigo_ibge_uf')) {
      context.handle(
          _codigoIbgeUfMeta,
          codigoIbgeUf.isAcceptableOrUnknown(
              data['codigo_ibge_uf']!, _codigoIbgeUfMeta));
    }
    if (data.containsKey('cei')) {
      context.handle(
          _ceiMeta, cei.isAcceptableOrUnknown(data['cei']!, _ceiMeta));
    }
    if (data.containsKey('codigo_cnae_principal')) {
      context.handle(
          _codigoCnaePrincipalMeta,
          codigoCnaePrincipal.isAcceptableOrUnknown(
              data['codigo_cnae_principal']!, _codigoCnaePrincipalMeta));
    }
    if (data.containsKey('imagem_logotipo')) {
      context.handle(
          _imagemLogotipoMeta,
          imagemLogotipo.isAcceptableOrUnknown(
              data['imagem_logotipo']!, _imagemLogotipoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Empresa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Empresa(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      razaoSocial: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}razao_social']),
      nomeFantasia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_fantasia']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      inscricaoEstadual: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}inscricao_estadual']),
      inscricaoMunicipal: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}inscricao_municipal']),
      tipoRegime: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_regime']),
      crt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}crt']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      contato: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}contato']),
      dataConstituicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_constituicao']),
      codigoIbgeCidade: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_ibge_cidade']),
      codigoIbgeUf: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_ibge_uf']),
      cei: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cei']),
      codigoCnaePrincipal: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_cnae_principal']),
      imagemLogotipo: attachedDatabase.typeMapping
          .read(DriftSqlType.blob, data['${effectivePrefix}imagem_logotipo']),
    );
  }

  @override
  $EmpresasTable createAlias(String alias) {
    return $EmpresasTable(attachedDatabase, alias);
  }
}

class Empresa extends DataClass implements Insertable<Empresa> {
  final int? id;
  final String? razaoSocial;
  final String? nomeFantasia;
  final String? cnpj;
  final String? inscricaoEstadual;
  final String? inscricaoMunicipal;
  final String? tipoRegime;
  final String? crt;
  final String? email;
  final String? site;
  final String? contato;
  final DateTime? dataConstituicao;
  final int? codigoIbgeCidade;
  final int? codigoIbgeUf;
  final String? cei;
  final String? codigoCnaePrincipal;
  final Uint8List? imagemLogotipo;
  const Empresa(
      {this.id,
      this.razaoSocial,
      this.nomeFantasia,
      this.cnpj,
      this.inscricaoEstadual,
      this.inscricaoMunicipal,
      this.tipoRegime,
      this.crt,
      this.email,
      this.site,
      this.contato,
      this.dataConstituicao,
      this.codigoIbgeCidade,
      this.codigoIbgeUf,
      this.cei,
      this.codigoCnaePrincipal,
      this.imagemLogotipo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || razaoSocial != null) {
      map['razao_social'] = Variable<String>(razaoSocial);
    }
    if (!nullToAbsent || nomeFantasia != null) {
      map['nome_fantasia'] = Variable<String>(nomeFantasia);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || inscricaoEstadual != null) {
      map['inscricao_estadual'] = Variable<String>(inscricaoEstadual);
    }
    if (!nullToAbsent || inscricaoMunicipal != null) {
      map['inscricao_municipal'] = Variable<String>(inscricaoMunicipal);
    }
    if (!nullToAbsent || tipoRegime != null) {
      map['tipo_regime'] = Variable<String>(tipoRegime);
    }
    if (!nullToAbsent || crt != null) {
      map['crt'] = Variable<String>(crt);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || contato != null) {
      map['contato'] = Variable<String>(contato);
    }
    if (!nullToAbsent || dataConstituicao != null) {
      map['data_constituicao'] = Variable<DateTime>(dataConstituicao);
    }
    if (!nullToAbsent || codigoIbgeCidade != null) {
      map['codigo_ibge_cidade'] = Variable<int>(codigoIbgeCidade);
    }
    if (!nullToAbsent || codigoIbgeUf != null) {
      map['codigo_ibge_uf'] = Variable<int>(codigoIbgeUf);
    }
    if (!nullToAbsent || cei != null) {
      map['cei'] = Variable<String>(cei);
    }
    if (!nullToAbsent || codigoCnaePrincipal != null) {
      map['codigo_cnae_principal'] = Variable<String>(codigoCnaePrincipal);
    }
    if (!nullToAbsent || imagemLogotipo != null) {
      map['imagem_logotipo'] = Variable<Uint8List>(imagemLogotipo);
    }
    return map;
  }

  factory Empresa.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Empresa(
      id: serializer.fromJson<int?>(json['id']),
      razaoSocial: serializer.fromJson<String?>(json['razaoSocial']),
      nomeFantasia: serializer.fromJson<String?>(json['nomeFantasia']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      inscricaoEstadual:
          serializer.fromJson<String?>(json['inscricaoEstadual']),
      inscricaoMunicipal:
          serializer.fromJson<String?>(json['inscricaoMunicipal']),
      tipoRegime: serializer.fromJson<String?>(json['tipoRegime']),
      crt: serializer.fromJson<String?>(json['crt']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      contato: serializer.fromJson<String?>(json['contato']),
      dataConstituicao:
          serializer.fromJson<DateTime?>(json['dataConstituicao']),
      codigoIbgeCidade: serializer.fromJson<int?>(json['codigoIbgeCidade']),
      codigoIbgeUf: serializer.fromJson<int?>(json['codigoIbgeUf']),
      cei: serializer.fromJson<String?>(json['cei']),
      codigoCnaePrincipal:
          serializer.fromJson<String?>(json['codigoCnaePrincipal']),
      imagemLogotipo: serializer.fromJson<Uint8List?>(json['imagemLogotipo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'razaoSocial': serializer.toJson<String?>(razaoSocial),
      'nomeFantasia': serializer.toJson<String?>(nomeFantasia),
      'cnpj': serializer.toJson<String?>(cnpj),
      'inscricaoEstadual': serializer.toJson<String?>(inscricaoEstadual),
      'inscricaoMunicipal': serializer.toJson<String?>(inscricaoMunicipal),
      'tipoRegime': serializer.toJson<String?>(tipoRegime),
      'crt': serializer.toJson<String?>(crt),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'contato': serializer.toJson<String?>(contato),
      'dataConstituicao': serializer.toJson<DateTime?>(dataConstituicao),
      'codigoIbgeCidade': serializer.toJson<int?>(codigoIbgeCidade),
      'codigoIbgeUf': serializer.toJson<int?>(codigoIbgeUf),
      'cei': serializer.toJson<String?>(cei),
      'codigoCnaePrincipal': serializer.toJson<String?>(codigoCnaePrincipal),
      'imagemLogotipo': serializer.toJson<Uint8List?>(imagemLogotipo),
    };
  }

  Empresa copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> razaoSocial = const Value.absent(),
          Value<String?> nomeFantasia = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> inscricaoEstadual = const Value.absent(),
          Value<String?> inscricaoMunicipal = const Value.absent(),
          Value<String?> tipoRegime = const Value.absent(),
          Value<String?> crt = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> contato = const Value.absent(),
          Value<DateTime?> dataConstituicao = const Value.absent(),
          Value<int?> codigoIbgeCidade = const Value.absent(),
          Value<int?> codigoIbgeUf = const Value.absent(),
          Value<String?> cei = const Value.absent(),
          Value<String?> codigoCnaePrincipal = const Value.absent(),
          Value<Uint8List?> imagemLogotipo = const Value.absent()}) =>
      Empresa(
        id: id.present ? id.value : this.id,
        razaoSocial: razaoSocial.present ? razaoSocial.value : this.razaoSocial,
        nomeFantasia:
            nomeFantasia.present ? nomeFantasia.value : this.nomeFantasia,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        inscricaoEstadual: inscricaoEstadual.present
            ? inscricaoEstadual.value
            : this.inscricaoEstadual,
        inscricaoMunicipal: inscricaoMunicipal.present
            ? inscricaoMunicipal.value
            : this.inscricaoMunicipal,
        tipoRegime: tipoRegime.present ? tipoRegime.value : this.tipoRegime,
        crt: crt.present ? crt.value : this.crt,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        contato: contato.present ? contato.value : this.contato,
        dataConstituicao: dataConstituicao.present
            ? dataConstituicao.value
            : this.dataConstituicao,
        codigoIbgeCidade: codigoIbgeCidade.present
            ? codigoIbgeCidade.value
            : this.codigoIbgeCidade,
        codigoIbgeUf:
            codigoIbgeUf.present ? codigoIbgeUf.value : this.codigoIbgeUf,
        cei: cei.present ? cei.value : this.cei,
        codigoCnaePrincipal: codigoCnaePrincipal.present
            ? codigoCnaePrincipal.value
            : this.codigoCnaePrincipal,
        imagemLogotipo:
            imagemLogotipo.present ? imagemLogotipo.value : this.imagemLogotipo,
      );
  @override
  String toString() {
    return (StringBuffer('Empresa(')
          ..write('id: $id, ')
          ..write('razaoSocial: $razaoSocial, ')
          ..write('nomeFantasia: $nomeFantasia, ')
          ..write('cnpj: $cnpj, ')
          ..write('inscricaoEstadual: $inscricaoEstadual, ')
          ..write('inscricaoMunicipal: $inscricaoMunicipal, ')
          ..write('tipoRegime: $tipoRegime, ')
          ..write('crt: $crt, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('contato: $contato, ')
          ..write('dataConstituicao: $dataConstituicao, ')
          ..write('codigoIbgeCidade: $codigoIbgeCidade, ')
          ..write('codigoIbgeUf: $codigoIbgeUf, ')
          ..write('cei: $cei, ')
          ..write('codigoCnaePrincipal: $codigoCnaePrincipal, ')
          ..write('imagemLogotipo: $imagemLogotipo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      razaoSocial,
      nomeFantasia,
      cnpj,
      inscricaoEstadual,
      inscricaoMunicipal,
      tipoRegime,
      crt,
      email,
      site,
      contato,
      dataConstituicao,
      codigoIbgeCidade,
      codigoIbgeUf,
      cei,
      codigoCnaePrincipal,
      $driftBlobEquality.hash(imagemLogotipo));
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Empresa &&
          other.id == this.id &&
          other.razaoSocial == this.razaoSocial &&
          other.nomeFantasia == this.nomeFantasia &&
          other.cnpj == this.cnpj &&
          other.inscricaoEstadual == this.inscricaoEstadual &&
          other.inscricaoMunicipal == this.inscricaoMunicipal &&
          other.tipoRegime == this.tipoRegime &&
          other.crt == this.crt &&
          other.email == this.email &&
          other.site == this.site &&
          other.contato == this.contato &&
          other.dataConstituicao == this.dataConstituicao &&
          other.codigoIbgeCidade == this.codigoIbgeCidade &&
          other.codigoIbgeUf == this.codigoIbgeUf &&
          other.cei == this.cei &&
          other.codigoCnaePrincipal == this.codigoCnaePrincipal &&
          $driftBlobEquality.equals(other.imagemLogotipo, this.imagemLogotipo));
}

class EmpresasCompanion extends UpdateCompanion<Empresa> {
  final Value<int?> id;
  final Value<String?> razaoSocial;
  final Value<String?> nomeFantasia;
  final Value<String?> cnpj;
  final Value<String?> inscricaoEstadual;
  final Value<String?> inscricaoMunicipal;
  final Value<String?> tipoRegime;
  final Value<String?> crt;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> contato;
  final Value<DateTime?> dataConstituicao;
  final Value<int?> codigoIbgeCidade;
  final Value<int?> codigoIbgeUf;
  final Value<String?> cei;
  final Value<String?> codigoCnaePrincipal;
  final Value<Uint8List?> imagemLogotipo;
  const EmpresasCompanion({
    this.id = const Value.absent(),
    this.razaoSocial = const Value.absent(),
    this.nomeFantasia = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.inscricaoEstadual = const Value.absent(),
    this.inscricaoMunicipal = const Value.absent(),
    this.tipoRegime = const Value.absent(),
    this.crt = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.contato = const Value.absent(),
    this.dataConstituicao = const Value.absent(),
    this.codigoIbgeCidade = const Value.absent(),
    this.codigoIbgeUf = const Value.absent(),
    this.cei = const Value.absent(),
    this.codigoCnaePrincipal = const Value.absent(),
    this.imagemLogotipo = const Value.absent(),
  });
  EmpresasCompanion.insert({
    this.id = const Value.absent(),
    this.razaoSocial = const Value.absent(),
    this.nomeFantasia = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.inscricaoEstadual = const Value.absent(),
    this.inscricaoMunicipal = const Value.absent(),
    this.tipoRegime = const Value.absent(),
    this.crt = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.contato = const Value.absent(),
    this.dataConstituicao = const Value.absent(),
    this.codigoIbgeCidade = const Value.absent(),
    this.codigoIbgeUf = const Value.absent(),
    this.cei = const Value.absent(),
    this.codigoCnaePrincipal = const Value.absent(),
    this.imagemLogotipo = const Value.absent(),
  });
  static Insertable<Empresa> custom({
    Expression<int>? id,
    Expression<String>? razaoSocial,
    Expression<String>? nomeFantasia,
    Expression<String>? cnpj,
    Expression<String>? inscricaoEstadual,
    Expression<String>? inscricaoMunicipal,
    Expression<String>? tipoRegime,
    Expression<String>? crt,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? contato,
    Expression<DateTime>? dataConstituicao,
    Expression<int>? codigoIbgeCidade,
    Expression<int>? codigoIbgeUf,
    Expression<String>? cei,
    Expression<String>? codigoCnaePrincipal,
    Expression<Uint8List>? imagemLogotipo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (razaoSocial != null) 'razao_social': razaoSocial,
      if (nomeFantasia != null) 'nome_fantasia': nomeFantasia,
      if (cnpj != null) 'cnpj': cnpj,
      if (inscricaoEstadual != null) 'inscricao_estadual': inscricaoEstadual,
      if (inscricaoMunicipal != null) 'inscricao_municipal': inscricaoMunicipal,
      if (tipoRegime != null) 'tipo_regime': tipoRegime,
      if (crt != null) 'crt': crt,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (contato != null) 'contato': contato,
      if (dataConstituicao != null) 'data_constituicao': dataConstituicao,
      if (codigoIbgeCidade != null) 'codigo_ibge_cidade': codigoIbgeCidade,
      if (codigoIbgeUf != null) 'codigo_ibge_uf': codigoIbgeUf,
      if (cei != null) 'cei': cei,
      if (codigoCnaePrincipal != null)
        'codigo_cnae_principal': codigoCnaePrincipal,
      if (imagemLogotipo != null) 'imagem_logotipo': imagemLogotipo,
    });
  }

  EmpresasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? razaoSocial,
      Value<String?>? nomeFantasia,
      Value<String?>? cnpj,
      Value<String?>? inscricaoEstadual,
      Value<String?>? inscricaoMunicipal,
      Value<String?>? tipoRegime,
      Value<String?>? crt,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? contato,
      Value<DateTime?>? dataConstituicao,
      Value<int?>? codigoIbgeCidade,
      Value<int?>? codigoIbgeUf,
      Value<String?>? cei,
      Value<String?>? codigoCnaePrincipal,
      Value<Uint8List?>? imagemLogotipo}) {
    return EmpresasCompanion(
      id: id ?? this.id,
      razaoSocial: razaoSocial ?? this.razaoSocial,
      nomeFantasia: nomeFantasia ?? this.nomeFantasia,
      cnpj: cnpj ?? this.cnpj,
      inscricaoEstadual: inscricaoEstadual ?? this.inscricaoEstadual,
      inscricaoMunicipal: inscricaoMunicipal ?? this.inscricaoMunicipal,
      tipoRegime: tipoRegime ?? this.tipoRegime,
      crt: crt ?? this.crt,
      email: email ?? this.email,
      site: site ?? this.site,
      contato: contato ?? this.contato,
      dataConstituicao: dataConstituicao ?? this.dataConstituicao,
      codigoIbgeCidade: codigoIbgeCidade ?? this.codigoIbgeCidade,
      codigoIbgeUf: codigoIbgeUf ?? this.codigoIbgeUf,
      cei: cei ?? this.cei,
      codigoCnaePrincipal: codigoCnaePrincipal ?? this.codigoCnaePrincipal,
      imagemLogotipo: imagemLogotipo ?? this.imagemLogotipo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (razaoSocial.present) {
      map['razao_social'] = Variable<String>(razaoSocial.value);
    }
    if (nomeFantasia.present) {
      map['nome_fantasia'] = Variable<String>(nomeFantasia.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (inscricaoEstadual.present) {
      map['inscricao_estadual'] = Variable<String>(inscricaoEstadual.value);
    }
    if (inscricaoMunicipal.present) {
      map['inscricao_municipal'] = Variable<String>(inscricaoMunicipal.value);
    }
    if (tipoRegime.present) {
      map['tipo_regime'] = Variable<String>(tipoRegime.value);
    }
    if (crt.present) {
      map['crt'] = Variable<String>(crt.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (contato.present) {
      map['contato'] = Variable<String>(contato.value);
    }
    if (dataConstituicao.present) {
      map['data_constituicao'] = Variable<DateTime>(dataConstituicao.value);
    }
    if (codigoIbgeCidade.present) {
      map['codigo_ibge_cidade'] = Variable<int>(codigoIbgeCidade.value);
    }
    if (codigoIbgeUf.present) {
      map['codigo_ibge_uf'] = Variable<int>(codigoIbgeUf.value);
    }
    if (cei.present) {
      map['cei'] = Variable<String>(cei.value);
    }
    if (codigoCnaePrincipal.present) {
      map['codigo_cnae_principal'] =
          Variable<String>(codigoCnaePrincipal.value);
    }
    if (imagemLogotipo.present) {
      map['imagem_logotipo'] = Variable<Uint8List>(imagemLogotipo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EmpresasCompanion(')
          ..write('id: $id, ')
          ..write('razaoSocial: $razaoSocial, ')
          ..write('nomeFantasia: $nomeFantasia, ')
          ..write('cnpj: $cnpj, ')
          ..write('inscricaoEstadual: $inscricaoEstadual, ')
          ..write('inscricaoMunicipal: $inscricaoMunicipal, ')
          ..write('tipoRegime: $tipoRegime, ')
          ..write('crt: $crt, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('contato: $contato, ')
          ..write('dataConstituicao: $dataConstituicao, ')
          ..write('codigoIbgeCidade: $codigoIbgeCidade, ')
          ..write('codigoIbgeUf: $codigoIbgeUf, ')
          ..write('cei: $cei, ')
          ..write('codigoCnaePrincipal: $codigoCnaePrincipal, ')
          ..write('imagemLogotipo: $imagemLogotipo')
          ..write(')'))
        .toString();
  }
}

class $FormaPagamentosTable extends FormaPagamentos
    with TableInfo<$FormaPagamentosTable, FormaPagamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FormaPagamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome];
  @override
  String get aliasedName => _alias ?? 'forma_pagamento';
  @override
  String get actualTableName => 'forma_pagamento';
  @override
  VerificationContext validateIntegrity(Insertable<FormaPagamento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FormaPagamento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FormaPagamento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $FormaPagamentosTable createAlias(String alias) {
    return $FormaPagamentosTable(attachedDatabase, alias);
  }
}

class FormaPagamento extends DataClass implements Insertable<FormaPagamento> {
  final int? id;
  final String? nome;
  const FormaPagamento({this.id, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory FormaPagamento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FormaPagamento(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  FormaPagamento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      FormaPagamento(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('FormaPagamento(')
          ..write('id: $id, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FormaPagamento &&
          other.id == this.id &&
          other.nome == this.nome);
}

class FormaPagamentosCompanion extends UpdateCompanion<FormaPagamento> {
  final Value<int?> id;
  final Value<String?> nome;
  const FormaPagamentosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
  });
  FormaPagamentosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<FormaPagamento> custom({
    Expression<int>? id,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
    });
  }

  FormaPagamentosCompanion copyWith({Value<int?>? id, Value<String?>? nome}) {
    return FormaPagamentosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FormaPagamentosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $NivelFormacaosTable extends NivelFormacaos
    with TableInfo<$NivelFormacaosTable, NivelFormacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NivelFormacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? 'nivel_formacao';
  @override
  String get actualTableName => 'nivel_formacao';
  @override
  VerificationContext validateIntegrity(Insertable<NivelFormacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NivelFormacao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NivelFormacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $NivelFormacaosTable createAlias(String alias) {
    return $NivelFormacaosTable(attachedDatabase, alias);
  }
}

class NivelFormacao extends DataClass implements Insertable<NivelFormacao> {
  final int? id;
  final String? nome;
  final String? descricao;
  const NivelFormacao({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory NivelFormacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NivelFormacao(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  NivelFormacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      NivelFormacao(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('NivelFormacao(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NivelFormacao &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class NivelFormacaosCompanion extends UpdateCompanion<NivelFormacao> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const NivelFormacaosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  NivelFormacaosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<NivelFormacao> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  NivelFormacaosCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return NivelFormacaosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NivelFormacaosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $BancosTable extends Bancos with TableInfo<$BancosTable, Banco> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BancosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _urlMeta = const VerificationMeta('url');
  @override
  late final GeneratedColumn<String> url = GeneratedColumn<String>(
      'url', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome, url];
  @override
  String get aliasedName => _alias ?? 'banco';
  @override
  String get actualTableName => 'banco';
  @override
  VerificationContext validateIntegrity(Insertable<Banco> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('url')) {
      context.handle(
          _urlMeta, url.isAcceptableOrUnknown(data['url']!, _urlMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Banco map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Banco(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      url: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}url']),
    );
  }

  @override
  $BancosTable createAlias(String alias) {
    return $BancosTable(attachedDatabase, alias);
  }
}

class Banco extends DataClass implements Insertable<Banco> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? url;
  const Banco({this.id, this.codigo, this.nome, this.url});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || url != null) {
      map['url'] = Variable<String>(url);
    }
    return map;
  }

  factory Banco.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Banco(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      url: serializer.fromJson<String?>(json['url']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'url': serializer.toJson<String?>(url),
    };
  }

  Banco copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> url = const Value.absent()}) =>
      Banco(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        url: url.present ? url.value : this.url,
      );
  @override
  String toString() {
    return (StringBuffer('Banco(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('url: $url')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome, url);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Banco &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.url == this.url);
}

class BancosCompanion extends UpdateCompanion<Banco> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> url;
  const BancosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.url = const Value.absent(),
  });
  BancosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.url = const Value.absent(),
  });
  static Insertable<Banco> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? url,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (url != null) 'url': url,
    });
  }

  BancosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? url}) {
    return BancosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      url: url ?? this.url,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (url.present) {
      map['url'] = Variable<String>(url.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BancosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('url: $url')
          ..write(')'))
        .toString();
  }
}

class $BancoContaCaixasTable extends BancoContaCaixas
    with TableInfo<$BancoContaCaixasTable, BancoContaCaixa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BancoContaCaixasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idBancoAgenciaMeta =
      const VerificationMeta('idBancoAgencia');
  @override
  late final GeneratedColumn<int> idBancoAgencia = GeneratedColumn<int>(
      'id_banco_agencia', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _digitoMeta = const VerificationMeta('digito');
  @override
  late final GeneratedColumn<String> digito = GeneratedColumn<String>(
      'digito', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idBancoAgencia, numero, digito, tipo, nome, descricao];
  @override
  String get aliasedName => _alias ?? 'banco_conta_caixa';
  @override
  String get actualTableName => 'banco_conta_caixa';
  @override
  VerificationContext validateIntegrity(Insertable<BancoContaCaixa> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco_agencia')) {
      context.handle(
          _idBancoAgenciaMeta,
          idBancoAgencia.isAcceptableOrUnknown(
              data['id_banco_agencia']!, _idBancoAgenciaMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('digito')) {
      context.handle(_digitoMeta,
          digito.isAcceptableOrUnknown(data['digito']!, _digitoMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BancoContaCaixa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BancoContaCaixa(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idBancoAgencia: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_banco_agencia']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      digito: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}digito']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $BancoContaCaixasTable createAlias(String alias) {
    return $BancoContaCaixasTable(attachedDatabase, alias);
  }
}

class BancoContaCaixa extends DataClass implements Insertable<BancoContaCaixa> {
  final int? id;
  final int? idBancoAgencia;
  final String? numero;
  final String? digito;
  final String? tipo;
  final String? nome;
  final String? descricao;
  const BancoContaCaixa(
      {this.id,
      this.idBancoAgencia,
      this.numero,
      this.digito,
      this.tipo,
      this.nome,
      this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBancoAgencia != null) {
      map['id_banco_agencia'] = Variable<int>(idBancoAgencia);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || digito != null) {
      map['digito'] = Variable<String>(digito);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory BancoContaCaixa.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BancoContaCaixa(
      id: serializer.fromJson<int?>(json['id']),
      idBancoAgencia: serializer.fromJson<int?>(json['idBancoAgencia']),
      numero: serializer.fromJson<String?>(json['numero']),
      digito: serializer.fromJson<String?>(json['digito']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBancoAgencia': serializer.toJson<int?>(idBancoAgencia),
      'numero': serializer.toJson<String?>(numero),
      'digito': serializer.toJson<String?>(digito),
      'tipo': serializer.toJson<String?>(tipo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  BancoContaCaixa copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idBancoAgencia = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> digito = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      BancoContaCaixa(
        id: id.present ? id.value : this.id,
        idBancoAgencia:
            idBancoAgencia.present ? idBancoAgencia.value : this.idBancoAgencia,
        numero: numero.present ? numero.value : this.numero,
        digito: digito.present ? digito.value : this.digito,
        tipo: tipo.present ? tipo.value : this.tipo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('BancoContaCaixa(')
          ..write('id: $id, ')
          ..write('idBancoAgencia: $idBancoAgencia, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('tipo: $tipo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idBancoAgencia, numero, digito, tipo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BancoContaCaixa &&
          other.id == this.id &&
          other.idBancoAgencia == this.idBancoAgencia &&
          other.numero == this.numero &&
          other.digito == this.digito &&
          other.tipo == this.tipo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class BancoContaCaixasCompanion extends UpdateCompanion<BancoContaCaixa> {
  final Value<int?> id;
  final Value<int?> idBancoAgencia;
  final Value<String?> numero;
  final Value<String?> digito;
  final Value<String?> tipo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const BancoContaCaixasCompanion({
    this.id = const Value.absent(),
    this.idBancoAgencia = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.tipo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  BancoContaCaixasCompanion.insert({
    this.id = const Value.absent(),
    this.idBancoAgencia = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.tipo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<BancoContaCaixa> custom({
    Expression<int>? id,
    Expression<int>? idBancoAgencia,
    Expression<String>? numero,
    Expression<String>? digito,
    Expression<String>? tipo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBancoAgencia != null) 'id_banco_agencia': idBancoAgencia,
      if (numero != null) 'numero': numero,
      if (digito != null) 'digito': digito,
      if (tipo != null) 'tipo': tipo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  BancoContaCaixasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idBancoAgencia,
      Value<String?>? numero,
      Value<String?>? digito,
      Value<String?>? tipo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return BancoContaCaixasCompanion(
      id: id ?? this.id,
      idBancoAgencia: idBancoAgencia ?? this.idBancoAgencia,
      numero: numero ?? this.numero,
      digito: digito ?? this.digito,
      tipo: tipo ?? this.tipo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBancoAgencia.present) {
      map['id_banco_agencia'] = Variable<int>(idBancoAgencia.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (digito.present) {
      map['digito'] = Variable<String>(digito.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BancoContaCaixasCompanion(')
          ..write('id: $id, ')
          ..write('idBancoAgencia: $idBancoAgencia, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('tipo: $tipo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoUnidadesTable extends ProdutoUnidades
    with TableInfo<$ProdutoUnidadesTable, ProdutoUnidade> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoUnidadesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _siglaMeta = const VerificationMeta('sigla');
  @override
  late final GeneratedColumn<String> sigla = GeneratedColumn<String>(
      'sigla', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, sigla, descricao];
  @override
  String get aliasedName => _alias ?? 'produto_unidade';
  @override
  String get actualTableName => 'produto_unidade';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoUnidade> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('sigla')) {
      context.handle(
          _siglaMeta, sigla.isAcceptableOrUnknown(data['sigla']!, _siglaMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoUnidade map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoUnidade(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      sigla: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sigla']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoUnidadesTable createAlias(String alias) {
    return $ProdutoUnidadesTable(attachedDatabase, alias);
  }
}

class ProdutoUnidade extends DataClass implements Insertable<ProdutoUnidade> {
  final int? id;
  final String? sigla;
  final String? descricao;
  const ProdutoUnidade({this.id, this.sigla, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || sigla != null) {
      map['sigla'] = Variable<String>(sigla);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoUnidade.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoUnidade(
      id: serializer.fromJson<int?>(json['id']),
      sigla: serializer.fromJson<String?>(json['sigla']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'sigla': serializer.toJson<String?>(sigla),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoUnidade copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> sigla = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoUnidade(
        id: id.present ? id.value : this.id,
        sigla: sigla.present ? sigla.value : this.sigla,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoUnidade(')
          ..write('id: $id, ')
          ..write('sigla: $sigla, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, sigla, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoUnidade &&
          other.id == this.id &&
          other.sigla == this.sigla &&
          other.descricao == this.descricao);
}

class ProdutoUnidadesCompanion extends UpdateCompanion<ProdutoUnidade> {
  final Value<int?> id;
  final Value<String?> sigla;
  final Value<String?> descricao;
  const ProdutoUnidadesCompanion({
    this.id = const Value.absent(),
    this.sigla = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoUnidadesCompanion.insert({
    this.id = const Value.absent(),
    this.sigla = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoUnidade> custom({
    Expression<int>? id,
    Expression<String>? sigla,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (sigla != null) 'sigla': sigla,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoUnidadesCompanion copyWith(
      {Value<int?>? id, Value<String?>? sigla, Value<String?>? descricao}) {
    return ProdutoUnidadesCompanion(
      id: id ?? this.id,
      sigla: sigla ?? this.sigla,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (sigla.present) {
      map['sigla'] = Variable<String>(sigla.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoUnidadesCompanion(')
          ..write('id: $id, ')
          ..write('sigla: $sigla, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $EstadoCivilsTable extends EstadoCivils
    with TableInfo<$EstadoCivilsTable, EstadoCivil> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EstadoCivilsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? 'estado_civil';
  @override
  String get actualTableName => 'estado_civil';
  @override
  VerificationContext validateIntegrity(Insertable<EstadoCivil> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EstadoCivil map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EstadoCivil(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $EstadoCivilsTable createAlias(String alias) {
    return $EstadoCivilsTable(attachedDatabase, alias);
  }
}

class EstadoCivil extends DataClass implements Insertable<EstadoCivil> {
  final int? id;
  final String? nome;
  final String? descricao;
  const EstadoCivil({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory EstadoCivil.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EstadoCivil(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  EstadoCivil copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      EstadoCivil(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('EstadoCivil(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EstadoCivil &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class EstadoCivilsCompanion extends UpdateCompanion<EstadoCivil> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const EstadoCivilsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  EstadoCivilsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<EstadoCivil> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  EstadoCivilsCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return EstadoCivilsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EstadoCivilsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $PessoaContatosTable pessoaContatos = $PessoaContatosTable(this);
  late final $ClientesTable clientes = $ClientesTable(this);
  late final $PessoaFisicasTable pessoaFisicas = $PessoaFisicasTable(this);
  late final $VendaDetalhesTable vendaDetalhes = $VendaDetalhesTable(this);
  late final $FornecedorsTable fornecedors = $FornecedorsTable(this);
  late final $PessoaEnderecosTable pessoaEnderecos =
      $PessoaEnderecosTable(this);
  late final $AtendimentosTable atendimentos = $AtendimentosTable(this);
  late final $PessoaTelefonesTable pessoaTelefones =
      $PessoaTelefonesTable(this);
  late final $PessoaJuridicasTable pessoaJuridicas =
      $PessoaJuridicasTable(this);
  late final $PessoasTable pessoas = $PessoasTable(this);
  late final $VendaCabecalhosTable vendaCabecalhos =
      $VendaCabecalhosTable(this);
  late final $UsuariosTable usuarios = $UsuariosTable(this);
  late final $ContasPagarsTable contasPagars = $ContasPagarsTable(this);
  late final $TalaosTable talaos = $TalaosTable(this);
  late final $ProdutosTable produtos = $ProdutosTable(this);
  late final $ContasRecebersTable contasRecebers = $ContasRecebersTable(this);
  late final $ProdutoMarcasTable produtoMarcas = $ProdutoMarcasTable(this);
  late final $BancoAgenciasTable bancoAgencias = $BancoAgenciasTable(this);
  late final $EmpresasTable empresas = $EmpresasTable(this);
  late final $FormaPagamentosTable formaPagamentos =
      $FormaPagamentosTable(this);
  late final $NivelFormacaosTable nivelFormacaos = $NivelFormacaosTable(this);
  late final $BancosTable bancos = $BancosTable(this);
  late final $BancoContaCaixasTable bancoContaCaixas =
      $BancoContaCaixasTable(this);
  late final $ProdutoUnidadesTable produtoUnidades =
      $ProdutoUnidadesTable(this);
  late final $EstadoCivilsTable estadoCivils = $EstadoCivilsTable(this);
  late final PessoaDao pessoaDao = PessoaDao(this as AppDatabase);
  late final VendaCabecalhoDao vendaCabecalhoDao =
      VendaCabecalhoDao(this as AppDatabase);
  late final UsuarioDao usuarioDao = UsuarioDao(this as AppDatabase);
  late final ContasPagarDao contasPagarDao =
      ContasPagarDao(this as AppDatabase);
  late final TalaoDao talaoDao = TalaoDao(this as AppDatabase);
  late final ProdutoDao produtoDao = ProdutoDao(this as AppDatabase);
  late final ContasReceberDao contasReceberDao =
      ContasReceberDao(this as AppDatabase);
  late final ProdutoMarcaDao produtoMarcaDao =
      ProdutoMarcaDao(this as AppDatabase);
  late final BancoAgenciaDao bancoAgenciaDao =
      BancoAgenciaDao(this as AppDatabase);
  late final EmpresaDao empresaDao = EmpresaDao(this as AppDatabase);
  late final FormaPagamentoDao formaPagamentoDao =
      FormaPagamentoDao(this as AppDatabase);
  late final NivelFormacaoDao nivelFormacaoDao =
      NivelFormacaoDao(this as AppDatabase);
  late final BancoDao bancoDao = BancoDao(this as AppDatabase);
  late final BancoContaCaixaDao bancoContaCaixaDao =
      BancoContaCaixaDao(this as AppDatabase);
  late final ProdutoUnidadeDao produtoUnidadeDao =
      ProdutoUnidadeDao(this as AppDatabase);
  late final EstadoCivilDao estadoCivilDao =
      EstadoCivilDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        pessoaContatos,
        clientes,
        pessoaFisicas,
        vendaDetalhes,
        fornecedors,
        pessoaEnderecos,
        atendimentos,
        pessoaTelefones,
        pessoaJuridicas,
        pessoas,
        vendaCabecalhos,
        usuarios,
        contasPagars,
        talaos,
        produtos,
        contasRecebers,
        produtoMarcas,
        bancoAgencias,
        empresas,
        formaPagamentos,
        nivelFormacaos,
        bancos,
        bancoContaCaixas,
        produtoUnidades,
        estadoCivils
      ];
}
