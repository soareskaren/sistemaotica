import 'package:otica/app/data/provider/drift/database/database_imports.dart';
import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/data/provider/api/api_provider_base.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/model/model_imports.dart';

class VendaCabecalhoDriftProvider extends ApiProviderBase {

	Future<List<VendaCabecalhoModel>?> getList({Filter? filter}) async {
		List<VendaCabecalhoGrouped> vendaCabecalhoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				vendaCabecalhoDriftList = await Session.database.vendaCabecalhoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				vendaCabecalhoDriftList = await Session.database.vendaCabecalhoDao.getGroupedList(); 
			}
			if (vendaCabecalhoDriftList.isNotEmpty) {
				return toListModel(vendaCabecalhoDriftList);
			} else {
				return [];
			}			 
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<VendaCabecalhoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.vendaCabecalhoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<VendaCabecalhoModel?>? insert(VendaCabecalhoModel vendaCabecalhoModel) async {
		try {
			final lastPk = await Session.database.vendaCabecalhoDao.insertObject(toDrift(vendaCabecalhoModel));
			vendaCabecalhoModel.id = lastPk;
			return vendaCabecalhoModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<VendaCabecalhoModel?>? update(VendaCabecalhoModel vendaCabecalhoModel) async {
		try {
			await Session.database.vendaCabecalhoDao.updateObject(toDrift(vendaCabecalhoModel));
			return vendaCabecalhoModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.vendaCabecalhoDao.deleteObject(toDrift(VendaCabecalhoModel(id: pk)));
			return true;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<VendaCabecalhoModel> toListModel(List<VendaCabecalhoGrouped> vendaCabecalhoDriftList) {
		List<VendaCabecalhoModel> listModel = [];
		for (var vendaCabecalhoDrift in vendaCabecalhoDriftList) {
			listModel.add(toModel(vendaCabecalhoDrift)!);
		}
		return listModel;
	}	

	VendaCabecalhoModel? toModel(VendaCabecalhoGrouped? vendaCabecalhoDrift) {
		if (vendaCabecalhoDrift != null) {
			return VendaCabecalhoModel(
				id: vendaCabecalhoDrift.vendaCabecalho?.id,
				idPessoa: vendaCabecalhoDrift.vendaCabecalho?.idPessoa,
				codigo: vendaCabecalhoDrift.vendaCabecalho?.codigo,
				dataVenda: vendaCabecalhoDrift.vendaCabecalho?.dataVenda,
				valorSubtotal: vendaCabecalhoDrift.vendaCabecalho?.valorSubtotal,
				valorDesconto: vendaCabecalhoDrift.vendaCabecalho?.valorDesconto,
				valorTotal: vendaCabecalhoDrift.vendaCabecalho?.valorTotal,
				quantidadeParcelas: vendaCabecalhoDrift.vendaCabecalho?.quantidadeParcelas,
				primeiroVencimento: vendaCabecalhoDrift.vendaCabecalho?.primeiroVencimento,
				dataPrevistaEntrega: vendaCabecalhoDrift.vendaCabecalho?.dataPrevistaEntrega,
				dataEntrega: vendaCabecalhoDrift.vendaCabecalho?.dataEntrega,
				vendaDetalheModelList: vendaDetalheDriftToModel(vendaCabecalhoDrift.vendaDetalheGroupedList),
				pessoaModel: PessoaModel(
					id: vendaCabecalhoDrift.pessoa?.id,
					nome: vendaCabecalhoDrift.pessoa?.nome,
					tipo: vendaCabecalhoDrift.pessoa?.tipo,
					referencia: vendaCabecalhoDrift.pessoa?.referencia,
					email: vendaCabecalhoDrift.pessoa?.email,
					ehCliente: vendaCabecalhoDrift.pessoa?.ehCliente,
					ehFornecedor: vendaCabecalhoDrift.pessoa?.ehFornecedor,
					site: vendaCabecalhoDrift.pessoa?.site,
					observacao: vendaCabecalhoDrift.pessoa?.observacao,
				),
			);
		} else {
			return null;
		}
	}

	List<VendaDetalheModel> vendaDetalheDriftToModel(List<VendaDetalheGrouped>? vendaDetalheDriftList) { 
		List<VendaDetalheModel> vendaDetalheModelList = [];
		if (vendaDetalheDriftList != null) {
			for (var vendaDetalheGrouped in vendaDetalheDriftList) {
				vendaDetalheModelList.add(
					VendaDetalheModel(
						id: vendaDetalheGrouped.vendaDetalhe?.id,
						idVendaCabecalho: vendaDetalheGrouped.vendaDetalhe?.idVendaCabecalho,
						idProduto: vendaDetalheGrouped.vendaDetalhe?.idProduto,
						produtoModel: ProdutoModel(
							id: vendaDetalheGrouped.produto?.id,
							idProdutoMarca: vendaDetalheGrouped.produto?.idProdutoMarca,
							idProdutoUnidade: vendaDetalheGrouped.produto?.idProdutoUnidade,
							idPessoa: vendaDetalheGrouped.produto?.idPessoa,
							nome: vendaDetalheGrouped.produto?.nome,
							dataCadastro: vendaDetalheGrouped.produto?.dataCadastro,
							descricao: vendaDetalheGrouped.produto?.descricao,
							gtin: vendaDetalheGrouped.produto?.gtin,
							codigoInterno: vendaDetalheGrouped.produto?.codigoInterno,
							valorCompra: vendaDetalheGrouped.produto?.valorCompra,
							valorVenda: vendaDetalheGrouped.produto?.valorVenda,
							codigoNcm: vendaDetalheGrouped.produto?.codigoNcm,
							estoqueMinimo: vendaDetalheGrouped.produto?.estoqueMinimo,
							estoqueMaximo: vendaDetalheGrouped.produto?.estoqueMaximo,
							quantidadeEstoque: vendaDetalheGrouped.produto?.quantidadeEstoque,
						),
						quantidade: vendaDetalheGrouped.vendaDetalhe?.quantidade,
						valorUnitario: vendaDetalheGrouped.vendaDetalhe?.valorUnitario,
						taxaDesconto: vendaDetalheGrouped.vendaDetalhe?.taxaDesconto,
						valorDesconto: vendaDetalheGrouped.vendaDetalhe?.valorDesconto,
						valorTotal: vendaDetalheGrouped.vendaDetalhe?.valorTotal,
					)
				);
			}
			return vendaDetalheModelList;
		}
		return [];
	}


	VendaCabecalhoGrouped toDrift(VendaCabecalhoModel vendaCabecalhoModel) {
		return VendaCabecalhoGrouped(
			vendaCabecalho: VendaCabecalho(
				id: vendaCabecalhoModel.id,
				idPessoa: vendaCabecalhoModel.idPessoa,
				codigo: vendaCabecalhoModel.codigo,
				dataVenda: vendaCabecalhoModel.dataVenda,
				valorSubtotal: vendaCabecalhoModel.valorSubtotal,
				valorDesconto: vendaCabecalhoModel.valorDesconto,
				valorTotal: vendaCabecalhoModel.valorTotal,
				quantidadeParcelas: vendaCabecalhoModel.quantidadeParcelas,
				primeiroVencimento: vendaCabecalhoModel.primeiroVencimento,
				dataPrevistaEntrega: vendaCabecalhoModel.dataPrevistaEntrega,
				dataEntrega: vendaCabecalhoModel.dataEntrega,
			),
			vendaDetalheGroupedList: vendaDetalheModelToDrift(vendaCabecalhoModel.vendaDetalheModelList),
		);
	}

	List<VendaDetalheGrouped> vendaDetalheModelToDrift(List<VendaDetalheModel>? vendaDetalheModelList) { 
		List<VendaDetalheGrouped> vendaDetalheGroupedList = [];
		if (vendaDetalheModelList != null) {
			for (var vendaDetalheModel in vendaDetalheModelList) {
				vendaDetalheGroupedList.add(
					VendaDetalheGrouped(
						vendaDetalhe: VendaDetalhe(
							id: vendaDetalheModel.id,
							idVendaCabecalho: vendaDetalheModel.idVendaCabecalho,
							idProduto: vendaDetalheModel.idProduto,
							quantidade: vendaDetalheModel.quantidade,
							valorUnitario: vendaDetalheModel.valorUnitario,
							taxaDesconto: vendaDetalheModel.taxaDesconto,
							valorDesconto: vendaDetalheModel.valorDesconto,
							valorTotal: vendaDetalheModel.valorTotal,
						),
					),
				);
			}
			return vendaDetalheGroupedList;
		}
		return [];
	}

		
}
