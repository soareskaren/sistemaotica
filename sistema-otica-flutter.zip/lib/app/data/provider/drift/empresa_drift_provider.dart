import 'package:otica/app/data/provider/drift/database/database_imports.dart';
import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/data/provider/api/api_provider_base.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/model/model_imports.dart';
import 'package:otica/app/data/domain/domain_imports.dart';

class EmpresaDriftProvider extends ApiProviderBase {

	Future<List<EmpresaModel>?> getList({Filter? filter}) async {
		List<EmpresaGrouped> empresaDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				empresaDriftList = await Session.database.empresaDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				empresaDriftList = await Session.database.empresaDao.getGroupedList(); 
			}
			if (empresaDriftList.isNotEmpty) {
				return toListModel(empresaDriftList);
			} else {
				return [];
			}			 
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<EmpresaModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.empresaDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<EmpresaModel?>? insert(EmpresaModel empresaModel) async {
		try {
			final lastPk = await Session.database.empresaDao.insertObject(toDrift(empresaModel));
			empresaModel.id = lastPk;
			return empresaModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<EmpresaModel?>? update(EmpresaModel empresaModel) async {
		try {
			await Session.database.empresaDao.updateObject(toDrift(empresaModel));
			return empresaModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.empresaDao.deleteObject(toDrift(EmpresaModel(id: pk)));
			return true;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<EmpresaModel> toListModel(List<EmpresaGrouped> empresaDriftList) {
		List<EmpresaModel> listModel = [];
		for (var empresaDrift in empresaDriftList) {
			listModel.add(toModel(empresaDrift)!);
		}
		return listModel;
	}	

	EmpresaModel? toModel(EmpresaGrouped? empresaDrift) {
		if (empresaDrift != null) {
			return EmpresaModel(
				id: empresaDrift.empresa?.id,
				razaoSocial: empresaDrift.empresa?.razaoSocial,
				nomeFantasia: empresaDrift.empresa?.nomeFantasia,
				cnpj: empresaDrift.empresa?.cnpj,
				inscricaoEstadual: empresaDrift.empresa?.inscricaoEstadual,
				inscricaoMunicipal: empresaDrift.empresa?.inscricaoMunicipal,
				tipoRegime: EmpresaDomain.getTipoRegime(empresaDrift.empresa?.tipoRegime),
				crt: EmpresaDomain.getCrt(empresaDrift.empresa?.crt),
				email: empresaDrift.empresa?.email,
				site: empresaDrift.empresa?.site,
				contato: empresaDrift.empresa?.contato,
				dataConstituicao: empresaDrift.empresa?.dataConstituicao,
				codigoIbgeCidade: empresaDrift.empresa?.codigoIbgeCidade,
				codigoIbgeUf: empresaDrift.empresa?.codigoIbgeUf,
				cei: empresaDrift.empresa?.cei,
				codigoCnaePrincipal: empresaDrift.empresa?.codigoCnaePrincipal,
				imagemLogotipo: empresaDrift.empresa?.imagemLogotipo,
			);
		} else {
			return null;
		}
	}


	EmpresaGrouped toDrift(EmpresaModel empresaModel) {
		return EmpresaGrouped(
			empresa: Empresa(
				id: empresaModel.id,
				razaoSocial: empresaModel.razaoSocial,
				nomeFantasia: empresaModel.nomeFantasia,
				cnpj: Util.removeMask(empresaModel.cnpj),
				inscricaoEstadual: empresaModel.inscricaoEstadual,
				inscricaoMunicipal: empresaModel.inscricaoMunicipal,
				tipoRegime: EmpresaDomain.setTipoRegime(empresaModel.tipoRegime),
				crt: EmpresaDomain.setCrt(empresaModel.crt),
				email: empresaModel.email,
				site: empresaModel.site,
				contato: empresaModel.contato,
				dataConstituicao: empresaModel.dataConstituicao,
				codigoIbgeCidade: empresaModel.codigoIbgeCidade,
				codigoIbgeUf: empresaModel.codigoIbgeUf,
				cei: empresaModel.cei,
				codigoCnaePrincipal: empresaModel.codigoCnaePrincipal,
				imagemLogotipo: empresaModel.imagemLogotipo,
			),
		);
	}

		
}
