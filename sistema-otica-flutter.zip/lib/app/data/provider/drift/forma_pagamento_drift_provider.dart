import 'package:otica/app/data/provider/drift/database/database_imports.dart';
import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/data/provider/api/api_provider_base.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/model/model_imports.dart';

class FormaPagamentoDriftProvider extends ApiProviderBase {

	Future<List<FormaPagamentoModel>?> getList({Filter? filter}) async {
		List<FormaPagamentoGrouped> formaPagamentoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				formaPagamentoDriftList = await Session.database.formaPagamentoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				formaPagamentoDriftList = await Session.database.formaPagamentoDao.getGroupedList(); 
			}
			if (formaPagamentoDriftList.isNotEmpty) {
				return toListModel(formaPagamentoDriftList);
			} else {
				return [];
			}			 
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<FormaPagamentoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.formaPagamentoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<FormaPagamentoModel?>? insert(FormaPagamentoModel formaPagamentoModel) async {
		try {
			final lastPk = await Session.database.formaPagamentoDao.insertObject(toDrift(formaPagamentoModel));
			formaPagamentoModel.id = lastPk;
			return formaPagamentoModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<FormaPagamentoModel?>? update(FormaPagamentoModel formaPagamentoModel) async {
		try {
			await Session.database.formaPagamentoDao.updateObject(toDrift(formaPagamentoModel));
			return formaPagamentoModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.formaPagamentoDao.deleteObject(toDrift(FormaPagamentoModel(id: pk)));
			return true;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<FormaPagamentoModel> toListModel(List<FormaPagamentoGrouped> formaPagamentoDriftList) {
		List<FormaPagamentoModel> listModel = [];
		for (var formaPagamentoDrift in formaPagamentoDriftList) {
			listModel.add(toModel(formaPagamentoDrift)!);
		}
		return listModel;
	}	

	FormaPagamentoModel? toModel(FormaPagamentoGrouped? formaPagamentoDrift) {
		if (formaPagamentoDrift != null) {
			return FormaPagamentoModel(
				id: formaPagamentoDrift.formaPagamento?.id,
				nome: formaPagamentoDrift.formaPagamento?.nome,
			);
		} else {
			return null;
		}
	}


	FormaPagamentoGrouped toDrift(FormaPagamentoModel formaPagamentoModel) {
		return FormaPagamentoGrouped(
			formaPagamento: FormaPagamento(
				id: formaPagamentoModel.id,
				nome: formaPagamentoModel.nome,
			),
		);
	}

		
}
