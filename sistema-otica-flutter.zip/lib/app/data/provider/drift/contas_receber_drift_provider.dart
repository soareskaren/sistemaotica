import 'package:otica/app/data/provider/drift/database/database_imports.dart';
import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/data/provider/api/api_provider_base.dart';
import 'package:otica/app/data/provider/drift/database/database.dart';
import 'package:otica/app/data/model/model_imports.dart';

class ContasReceberDriftProvider extends ApiProviderBase {

	Future<List<ContasReceberModel>?> getList({Filter? filter}) async {
		List<ContasReceberGrouped> contasReceberDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				contasReceberDriftList = await Session.database.contasReceberDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				contasReceberDriftList = await Session.database.contasReceberDao.getGroupedList(); 
			}
			if (contasReceberDriftList.isNotEmpty) {
				return toListModel(contasReceberDriftList);
			} else {
				return [];
			}			 
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<ContasReceberModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.contasReceberDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ContasReceberModel?>? insert(ContasReceberModel contasReceberModel) async {
		try {
			final lastPk = await Session.database.contasReceberDao.insertObject(toDrift(contasReceberModel));
			contasReceberModel.id = lastPk;
			return contasReceberModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ContasReceberModel?>? update(ContasReceberModel contasReceberModel) async {
		try {
			await Session.database.contasReceberDao.updateObject(toDrift(contasReceberModel));
			return contasReceberModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.contasReceberDao.deleteObject(toDrift(ContasReceberModel(id: pk)));
			return true;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<ContasReceberModel> toListModel(List<ContasReceberGrouped> contasReceberDriftList) {
		List<ContasReceberModel> listModel = [];
		for (var contasReceberDrift in contasReceberDriftList) {
			listModel.add(toModel(contasReceberDrift)!);
		}
		return listModel;
	}	

	ContasReceberModel? toModel(ContasReceberGrouped? contasReceberDrift) {
		if (contasReceberDrift != null) {
			return ContasReceberModel(
				id: contasReceberDrift.contasReceber?.id,
				idPessoa: contasReceberDrift.contasReceber?.idPessoa,
				idFormaPagamento: contasReceberDrift.contasReceber?.idFormaPagamento,
				idVendaCabecalho: contasReceberDrift.contasReceber?.idVendaCabecalho,
				idBancoContaCaixa: contasReceberDrift.contasReceber?.idBancoContaCaixa,
				dataLancamento: contasReceberDrift.contasReceber?.dataLancamento,
				valorTotal: contasReceberDrift.contasReceber?.valorTotal,
				numeroParcela: contasReceberDrift.contasReceber?.numeroParcela,
				valorParcela: contasReceberDrift.contasReceber?.valorParcela,
				dataVencimento: contasReceberDrift.contasReceber?.dataVencimento,
				dataRecebimento: contasReceberDrift.contasReceber?.dataRecebimento,
				valorRecebido: contasReceberDrift.contasReceber?.valorRecebido,
				observacao: contasReceberDrift.contasReceber?.observacao,
				vendaCabecalhoModel: VendaCabecalhoModel(
					id: contasReceberDrift.vendaCabecalho?.id,
					idPessoa: contasReceberDrift.vendaCabecalho?.idPessoa,
					codigo: contasReceberDrift.vendaCabecalho?.codigo,
					dataVenda: contasReceberDrift.vendaCabecalho?.dataVenda,
					valorSubtotal: contasReceberDrift.vendaCabecalho?.valorSubtotal,
					valorDesconto: contasReceberDrift.vendaCabecalho?.valorDesconto,
					valorTotal: contasReceberDrift.vendaCabecalho?.valorTotal,
					quantidadeParcelas: contasReceberDrift.vendaCabecalho?.quantidadeParcelas,
					primeiroVencimento: contasReceberDrift.vendaCabecalho?.primeiroVencimento,
					dataPrevistaEntrega: contasReceberDrift.vendaCabecalho?.dataPrevistaEntrega,
					dataEntrega: contasReceberDrift.vendaCabecalho?.dataEntrega,
				),
				pessoaModel: PessoaModel(
					id: contasReceberDrift.pessoa?.id,
					nome: contasReceberDrift.pessoa?.nome,
					tipo: contasReceberDrift.pessoa?.tipo,
					referencia: contasReceberDrift.pessoa?.referencia,
					email: contasReceberDrift.pessoa?.email,
					ehCliente: contasReceberDrift.pessoa?.ehCliente,
					ehFornecedor: contasReceberDrift.pessoa?.ehFornecedor,
					site: contasReceberDrift.pessoa?.site,
					observacao: contasReceberDrift.pessoa?.observacao,
				),
				formaPagamentoModel: FormaPagamentoModel(
					id: contasReceberDrift.formaPagamento?.id,
					nome: contasReceberDrift.formaPagamento?.nome,
				),
				bancoContaCaixaModel: BancoContaCaixaModel(
					id: contasReceberDrift.bancoContaCaixa?.id,
					idBancoAgencia: contasReceberDrift.bancoContaCaixa?.idBancoAgencia,
					numero: contasReceberDrift.bancoContaCaixa?.numero,
					digito: contasReceberDrift.bancoContaCaixa?.digito,
					tipo: contasReceberDrift.bancoContaCaixa?.tipo,
					nome: contasReceberDrift.bancoContaCaixa?.nome,
					descricao: contasReceberDrift.bancoContaCaixa?.descricao,
				),
			);
		} else {
			return null;
		}
	}


	ContasReceberGrouped toDrift(ContasReceberModel contasReceberModel) {
		return ContasReceberGrouped(
			contasReceber: ContasReceber(
				id: contasReceberModel.id,
				idPessoa: contasReceberModel.idPessoa,
				idFormaPagamento: contasReceberModel.idFormaPagamento,
				idVendaCabecalho: contasReceberModel.idVendaCabecalho,
				idBancoContaCaixa: contasReceberModel.idBancoContaCaixa,
				dataLancamento: contasReceberModel.dataLancamento,
				valorTotal: contasReceberModel.valorTotal,
				numeroParcela: contasReceberModel.numeroParcela,
				valorParcela: contasReceberModel.valorParcela,
				dataVencimento: contasReceberModel.dataVencimento,
				dataRecebimento: contasReceberModel.dataRecebimento,
				valorRecebido: contasReceberModel.valorRecebido,
				observacao: contasReceberModel.observacao,
			),
		);
	}

		
}
