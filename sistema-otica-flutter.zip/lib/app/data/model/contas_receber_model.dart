import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:otica/app/data/model/model_imports.dart';
import 'package:intl/intl.dart';
import 'package:otica/app/infra/infra_imports.dart';

class ContasReceberModel {
	int? id;
	int? idPessoa;
	int? idFormaPagamento;
	int? idVendaCabecalho;
	int? idBancoContaCaixa;
	DateTime? dataLancamento;
	double? valorTotal;
	int? numeroParcela;
	double? valorParcela;
	DateTime? dataVencimento;
	DateTime? dataRecebimento;
	double? valorRecebido;
	String? observacao;
	VendaCabecalhoModel? vendaCabecalhoModel;
	PessoaModel? pessoaModel;
	FormaPagamentoModel? formaPagamentoModel;
	BancoContaCaixaModel? bancoContaCaixaModel;

	ContasReceberModel({
		this.id,
		this.idPessoa,
		this.idFormaPagamento,
		this.idVendaCabecalho,
		this.idBancoContaCaixa,
		this.dataLancamento,
		this.valorTotal,
		this.numeroParcela,
		this.valorParcela,
		this.dataVencimento,
		this.dataRecebimento,
		this.valorRecebido,
		this.observacao,
		this.vendaCabecalhoModel,
		this.pessoaModel,
		this.formaPagamentoModel,
		this.bancoContaCaixaModel,
	});

	static List<String> dbColumns = <String>[
		'id',
		'data_lancamento',
		'valor_total',
		'numero_parcela',
		'valor_parcela',
		'data_vencimento',
		'data_recebimento',
		'valor_recebido',
		'observacao',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Data Lancamento',
		'Valor Total',
		'Numero Parcela',
		'Valor Parcela',
		'Data Vencimento',
		'Data Recebimento',
		'Valor Recebido',
		'Observacao',
	];

	ContasReceberModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idPessoa = jsonData['idPessoa'];
		idFormaPagamento = jsonData['idFormaPagamento'];
		idVendaCabecalho = jsonData['idVendaCabecalho'];
		idBancoContaCaixa = jsonData['idBancoContaCaixa'];
		dataLancamento = jsonData['dataLancamento'] != null ? DateTime.tryParse(jsonData['dataLancamento']) : null;
		valorTotal = jsonData['valorTotal']?.toDouble();
		numeroParcela = jsonData['numeroParcela'];
		valorParcela = jsonData['valorParcela']?.toDouble();
		dataVencimento = jsonData['dataVencimento'] != null ? DateTime.tryParse(jsonData['dataVencimento']) : null;
		dataRecebimento = jsonData['dataRecebimento'] != null ? DateTime.tryParse(jsonData['dataRecebimento']) : null;
		valorRecebido = jsonData['valorRecebido']?.toDouble();
		observacao = jsonData['observacao'];
		vendaCabecalhoModel = jsonData['vendaCabecalhoModel'] == null ? VendaCabecalhoModel() : VendaCabecalhoModel.fromJson(jsonData['vendaCabecalhoModel']);
		pessoaModel = jsonData['pessoaModel'] == null ? PessoaModel() : PessoaModel.fromJson(jsonData['pessoaModel']);
		formaPagamentoModel = jsonData['formaPagamentoModel'] == null ? FormaPagamentoModel() : FormaPagamentoModel.fromJson(jsonData['formaPagamentoModel']);
		bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
		jsonData['idFormaPagamento'] = idFormaPagamento != 0 ? idFormaPagamento : null;
		jsonData['idVendaCabecalho'] = idVendaCabecalho != 0 ? idVendaCabecalho : null;
		jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
		jsonData['dataLancamento'] = dataLancamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataLancamento!) : null;
		jsonData['valorTotal'] = valorTotal;
		jsonData['numeroParcela'] = numeroParcela;
		jsonData['valorParcela'] = valorParcela;
		jsonData['dataVencimento'] = dataVencimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVencimento!) : null;
		jsonData['dataRecebimento'] = dataRecebimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRecebimento!) : null;
		jsonData['valorRecebido'] = valorRecebido;
		jsonData['observacao'] = observacao;
		jsonData['vendaCabecalhoModel'] = vendaCabecalhoModel?.toJson;
		jsonData['pessoaModel'] = pessoaModel?.toJson;
		jsonData['formaPagamentoModel'] = formaPagamentoModel?.toJson;
		jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idPessoa = plutoRow.cells['idPessoa']?.value;
		idFormaPagamento = plutoRow.cells['idFormaPagamento']?.value;
		idVendaCabecalho = plutoRow.cells['idVendaCabecalho']?.value;
		idBancoContaCaixa = plutoRow.cells['idBancoContaCaixa']?.value;
		dataLancamento = Util.stringToDate(plutoRow.cells['dataLancamento']?.value);
		valorTotal = plutoRow.cells['valorTotal']?.value?.toDouble();
		numeroParcela = plutoRow.cells['numeroParcela']?.value;
		valorParcela = plutoRow.cells['valorParcela']?.value?.toDouble();
		dataVencimento = Util.stringToDate(plutoRow.cells['dataVencimento']?.value);
		dataRecebimento = Util.stringToDate(plutoRow.cells['dataRecebimento']?.value);
		valorRecebido = plutoRow.cells['valorRecebido']?.value?.toDouble();
		observacao = plutoRow.cells['observacao']?.value;
		vendaCabecalhoModel = VendaCabecalhoModel();
		vendaCabecalhoModel?.codigo = plutoRow.cells['vendaCabecalhoModel']?.value;
		pessoaModel = PessoaModel();
		pessoaModel?.nome = plutoRow.cells['pessoaModel']?.value;
		formaPagamentoModel = FormaPagamentoModel();
		formaPagamentoModel?.nome = plutoRow.cells['formaPagamentoModel']?.value;
		bancoContaCaixaModel = BancoContaCaixaModel();
		bancoContaCaixaModel?.nome = plutoRow.cells['bancoContaCaixaModel']?.value;
	}	

	ContasReceberModel clone() {
		return ContasReceberModel(
			id: id,
			idPessoa: idPessoa,
			idFormaPagamento: idFormaPagamento,
			idVendaCabecalho: idVendaCabecalho,
			idBancoContaCaixa: idBancoContaCaixa,
			dataLancamento: dataLancamento,
			valorTotal: valorTotal,
			numeroParcela: numeroParcela,
			valorParcela: valorParcela,
			dataVencimento: dataVencimento,
			dataRecebimento: dataRecebimento,
			valorRecebido: valorRecebido,
			observacao: observacao,
		);			
	}

	
}