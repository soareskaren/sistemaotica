import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:otica/app/data/model/model_imports.dart';
import 'package:intl/intl.dart';
import 'package:otica/app/infra/infra_imports.dart';

class ProdutoModel {
	int? id;
	int? idProdutoMarca;
	int? idProdutoUnidade;
	int? idPessoa;
	String? nome;
	DateTime? dataCadastro;
	String? descricao;
	String? gtin;
	String? codigoInterno;
	double? valorCompra;
	double? valorVenda;
	String? codigoNcm;
	double? estoqueMinimo;
	double? estoqueMaximo;
	double? quantidadeEstoque;
	ProdutoUnidadeModel? produtoUnidadeModel;
	ProdutoMarcaModel? produtoMarcaModel;
	PessoaModel? pessoaModel;

	ProdutoModel({
		this.id,
		this.idProdutoMarca,
		this.idProdutoUnidade,
		this.idPessoa,
		this.nome,
		this.dataCadastro,
		this.descricao,
		this.gtin,
		this.codigoInterno,
		this.valorCompra,
		this.valorVenda,
		this.codigoNcm,
		this.estoqueMinimo,
		this.estoqueMaximo,
		this.quantidadeEstoque,
		this.produtoUnidadeModel,
		this.produtoMarcaModel,
		this.pessoaModel,
	});

	static List<String> dbColumns = <String>[
		'id',
		'nome',
		'data_cadastro',
		'descricao',
		'gtin',
		'codigo_interno',
		'valor_compra',
		'valor_venda',
		'codigo_ncm',
		'estoque_minimo',
		'estoque_maximo',
		'quantidade_estoque',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Nome',
		'Data Cadastro',
		'Descricao',
		'Gtin',
		'Codigo Interno',
		'Valor Compra',
		'Valor Venda',
		'Codigo Ncm',
		'Estoque Minimo',
		'Estoque Maximo',
		'Quantidade Estoque',
	];

	ProdutoModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idProdutoMarca = jsonData['idProdutoMarca'];
		idProdutoUnidade = jsonData['idProdutoUnidade'];
		idPessoa = jsonData['idPessoa'];
		nome = jsonData['nome'];
		dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
		descricao = jsonData['descricao'];
		gtin = jsonData['gtin'];
		codigoInterno = jsonData['codigoInterno'];
		valorCompra = jsonData['valorCompra']?.toDouble();
		valorVenda = jsonData['valorVenda']?.toDouble();
		codigoNcm = jsonData['codigoNcm'];
		estoqueMinimo = jsonData['estoqueMinimo']?.toDouble();
		estoqueMaximo = jsonData['estoqueMaximo']?.toDouble();
		quantidadeEstoque = jsonData['quantidadeEstoque']?.toDouble();
		produtoUnidadeModel = jsonData['produtoUnidadeModel'] == null ? ProdutoUnidadeModel() : ProdutoUnidadeModel.fromJson(jsonData['produtoUnidadeModel']);
		produtoMarcaModel = jsonData['produtoMarcaModel'] == null ? ProdutoMarcaModel() : ProdutoMarcaModel.fromJson(jsonData['produtoMarcaModel']);
		pessoaModel = jsonData['pessoaModel'] == null ? PessoaModel() : PessoaModel.fromJson(jsonData['pessoaModel']);
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idProdutoMarca'] = idProdutoMarca != 0 ? idProdutoMarca : null;
		jsonData['idProdutoUnidade'] = idProdutoUnidade != 0 ? idProdutoUnidade : null;
		jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
		jsonData['nome'] = nome;
		jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
		jsonData['descricao'] = descricao;
		jsonData['gtin'] = gtin;
		jsonData['codigoInterno'] = codigoInterno;
		jsonData['valorCompra'] = valorCompra;
		jsonData['valorVenda'] = valorVenda;
		jsonData['codigoNcm'] = codigoNcm;
		jsonData['estoqueMinimo'] = estoqueMinimo;
		jsonData['estoqueMaximo'] = estoqueMaximo;
		jsonData['quantidadeEstoque'] = quantidadeEstoque;
		jsonData['produtoUnidadeModel'] = produtoUnidadeModel?.toJson;
		jsonData['produtoMarcaModel'] = produtoMarcaModel?.toJson;
		jsonData['pessoaModel'] = pessoaModel?.toJson;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idProdutoMarca = plutoRow.cells['idProdutoMarca']?.value;
		idProdutoUnidade = plutoRow.cells['idProdutoUnidade']?.value;
		idPessoa = plutoRow.cells['idPessoa']?.value;
		nome = plutoRow.cells['nome']?.value;
		dataCadastro = Util.stringToDate(plutoRow.cells['dataCadastro']?.value);
		descricao = plutoRow.cells['descricao']?.value;
		gtin = plutoRow.cells['gtin']?.value;
		codigoInterno = plutoRow.cells['codigoInterno']?.value;
		valorCompra = plutoRow.cells['valorCompra']?.value?.toDouble();
		valorVenda = plutoRow.cells['valorVenda']?.value?.toDouble();
		codigoNcm = plutoRow.cells['codigoNcm']?.value;
		estoqueMinimo = plutoRow.cells['estoqueMinimo']?.value?.toDouble();
		estoqueMaximo = plutoRow.cells['estoqueMaximo']?.value?.toDouble();
		quantidadeEstoque = plutoRow.cells['quantidadeEstoque']?.value?.toDouble();
		produtoUnidadeModel = ProdutoUnidadeModel();
		produtoUnidadeModel?.sigla = plutoRow.cells['produtoUnidadeModel']?.value;
		produtoMarcaModel = ProdutoMarcaModel();
		produtoMarcaModel?.nome = plutoRow.cells['produtoMarcaModel']?.value;
		pessoaModel = PessoaModel();
		pessoaModel?.nome = plutoRow.cells['pessoaModel']?.value;
	}	

	ProdutoModel clone() {
		return ProdutoModel(
			id: id,
			idProdutoMarca: idProdutoMarca,
			idProdutoUnidade: idProdutoUnidade,
			idPessoa: idPessoa,
			nome: nome,
			dataCadastro: dataCadastro,
			descricao: descricao,
			gtin: gtin,
			codigoInterno: codigoInterno,
			valorCompra: valorCompra,
			valorVenda: valorVenda,
			codigoNcm: codigoNcm,
			estoqueMinimo: estoqueMinimo,
			estoqueMaximo: estoqueMaximo,
			quantidadeEstoque: quantidadeEstoque,
		);			
	}

	
}