import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';


class FormaPagamentoModel {
	int? id;
	String? nome;

	FormaPagamentoModel({
		this.id,
		this.nome,
	});

	static List<String> dbColumns = <String>[
		'id',
		'nome',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Nome',
	];

	FormaPagamentoModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		nome = jsonData['nome'];
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['nome'] = nome;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		nome = plutoRow.cells['nome']?.value;
	}	

	FormaPagamentoModel clone() {
		return FormaPagamentoModel(
			id: id,
			nome: nome,
		);			
	}

	
}