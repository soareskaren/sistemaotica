import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/data/model/model_imports.dart';
import 'package:intl/intl.dart';
import 'package:otica/app/data/domain/domain_imports.dart';

class PessoaFisicaModel {
	int? id;
	int? idPessoa;
	int? idNivelFormacao;
	int? idEstadoCivil;
	DateTime? dataNascimento;
	String? cpf;
	String? rg;
	String? orgaoRg;
	DateTime? dataEmissaoRg;
	String? sexo;
	String? raca;
	String? nacionalidade;
	String? naturalidade;
	String? nomePai;
	String? nomeMae;
	NivelFormacaoModel? nivelFormacaoModel;
	EstadoCivilModel? estadoCivilModel;

	PessoaFisicaModel({
		this.id,
		this.idPessoa,
		this.idNivelFormacao,
		this.idEstadoCivil,
		this.dataNascimento,
		this.cpf,
		this.rg,
		this.orgaoRg,
		this.dataEmissaoRg,
		this.sexo,
		this.raca,
		this.nacionalidade,
		this.naturalidade,
		this.nomePai,
		this.nomeMae,
		this.nivelFormacaoModel,
		this.estadoCivilModel,
	});

	static List<String> dbColumns = <String>[
		'id',
		'data_nascimento',
		'cpf',
		'rg',
		'orgao_rg',
		'data_emissao_rg',
		'sexo',
		'raca',
		'nacionalidade',
		'naturalidade',
		'nome_pai',
		'nome_mae',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Data Nascimento',
		'Cpf',
		'Rg',
		'Orgao Rg',
		'Data Emissao Rg',
		'Sexo',
		'Raca',
		'Nacionalidade',
		'Naturalidade',
		'Nome Pai',
		'Nome Mae',
	];

	PessoaFisicaModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idPessoa = jsonData['idPessoa'];
		idNivelFormacao = jsonData['idNivelFormacao'];
		idEstadoCivil = jsonData['idEstadoCivil'];
		dataNascimento = jsonData['dataNascimento'] != null ? DateTime.tryParse(jsonData['dataNascimento']) : null;
		cpf = jsonData['cpf'];
		rg = jsonData['rg'];
		orgaoRg = jsonData['orgaoRg'];
		dataEmissaoRg = jsonData['dataEmissaoRg'] != null ? DateTime.tryParse(jsonData['dataEmissaoRg']) : null;
		sexo = PessoaFisicaDomain.getSexo(jsonData['sexo']);
		raca = PessoaFisicaDomain.getRaca(jsonData['raca']);
		nacionalidade = jsonData['nacionalidade'];
		naturalidade = jsonData['naturalidade'];
		nomePai = jsonData['nomePai'];
		nomeMae = jsonData['nomeMae'];
		nivelFormacaoModel = jsonData['nivelFormacaoModel'] == null ? NivelFormacaoModel() : NivelFormacaoModel.fromJson(jsonData['nivelFormacaoModel']);
		estadoCivilModel = jsonData['estadoCivilModel'] == null ? EstadoCivilModel() : EstadoCivilModel.fromJson(jsonData['estadoCivilModel']);
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
		jsonData['idNivelFormacao'] = idNivelFormacao != 0 ? idNivelFormacao : null;
		jsonData['idEstadoCivil'] = idEstadoCivil != 0 ? idEstadoCivil : null;
		jsonData['dataNascimento'] = dataNascimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataNascimento!) : null;
		jsonData['cpf'] = Util.removeMask(cpf);
		jsonData['rg'] = rg;
		jsonData['orgaoRg'] = orgaoRg;
		jsonData['dataEmissaoRg'] = dataEmissaoRg != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissaoRg!) : null;
		jsonData['sexo'] = PessoaFisicaDomain.setSexo(sexo);
		jsonData['raca'] = PessoaFisicaDomain.setRaca(raca);
		jsonData['nacionalidade'] = nacionalidade;
		jsonData['naturalidade'] = naturalidade;
		jsonData['nomePai'] = nomePai;
		jsonData['nomeMae'] = nomeMae;
		jsonData['nivelFormacaoModel'] = nivelFormacaoModel?.toJson;
		jsonData['estadoCivilModel'] = estadoCivilModel?.toJson;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idPessoa = plutoRow.cells['idPessoa']?.value;
		idNivelFormacao = plutoRow.cells['idNivelFormacao']?.value;
		idEstadoCivil = plutoRow.cells['idEstadoCivil']?.value;
		dataNascimento = Util.stringToDate(plutoRow.cells['dataNascimento']?.value);
		cpf = plutoRow.cells['cpf']?.value;
		rg = plutoRow.cells['rg']?.value;
		orgaoRg = plutoRow.cells['orgaoRg']?.value;
		dataEmissaoRg = Util.stringToDate(plutoRow.cells['dataEmissaoRg']?.value);
		sexo = plutoRow.cells['sexo']?.value != '' ? plutoRow.cells['sexo']?.value : 'Masculino';
		raca = plutoRow.cells['raca']?.value != '' ? plutoRow.cells['raca']?.value : 'Branco';
		nacionalidade = plutoRow.cells['nacionalidade']?.value;
		naturalidade = plutoRow.cells['naturalidade']?.value;
		nomePai = plutoRow.cells['nomePai']?.value;
		nomeMae = plutoRow.cells['nomeMae']?.value;
		nivelFormacaoModel = NivelFormacaoModel();
		nivelFormacaoModel?.nome = plutoRow.cells['nivelFormacaoModel']?.value;
		estadoCivilModel = EstadoCivilModel();
		estadoCivilModel?.nome = plutoRow.cells['estadoCivilModel']?.value;
	}	

	PessoaFisicaModel clone() {
		return PessoaFisicaModel(
			id: id,
			idPessoa: idPessoa,
			idNivelFormacao: idNivelFormacao,
			idEstadoCivil: idEstadoCivil,
			dataNascimento: dataNascimento,
			cpf: cpf,
			rg: rg,
			orgaoRg: orgaoRg,
			dataEmissaoRg: dataEmissaoRg,
			sexo: sexo,
			raca: raca,
			nacionalidade: nacionalidade,
			naturalidade: naturalidade,
			nomePai: nomePai,
			nomeMae: nomeMae,
		);			
	}

	
}