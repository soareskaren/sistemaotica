import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:otica/app/data/model/model_imports.dart';
import 'package:otica/app/data/domain/domain_imports.dart';

class BancoContaCaixaModel {
	int? id;
	int? idBancoAgencia;
	String? numero;
	String? digito;
	String? tipo;
	String? nome;
	String? descricao;
	BancoAgenciaModel? bancoAgenciaModel;

	BancoContaCaixaModel({
		this.id,
		this.idBancoAgencia,
		this.numero,
		this.digito,
		this.tipo,
		this.nome,
		this.descricao,
		this.bancoAgenciaModel,
	});

	static List<String> dbColumns = <String>[
		'id',
		'numero',
		'digito',
		'tipo',
		'nome',
		'descricao',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Numero',
		'Digito',
		'Tipo',
		'Nome',
		'Descricao',
	];

	BancoContaCaixaModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idBancoAgencia = jsonData['idBancoAgencia'];
		numero = jsonData['numero'];
		digito = jsonData['digito'];
		tipo = BancoContaCaixaDomain.getTipo(jsonData['tipo']);
		nome = jsonData['nome'];
		descricao = jsonData['descricao'];
		bancoAgenciaModel = jsonData['bancoAgenciaModel'] == null ? BancoAgenciaModel() : BancoAgenciaModel.fromJson(jsonData['bancoAgenciaModel']);
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idBancoAgencia'] = idBancoAgencia != 0 ? idBancoAgencia : null;
		jsonData['numero'] = numero;
		jsonData['digito'] = digito;
		jsonData['tipo'] = BancoContaCaixaDomain.setTipo(tipo);
		jsonData['nome'] = nome;
		jsonData['descricao'] = descricao;
		jsonData['bancoAgenciaModel'] = bancoAgenciaModel?.toJson;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idBancoAgencia = plutoRow.cells['idBancoAgencia']?.value;
		numero = plutoRow.cells['numero']?.value;
		digito = plutoRow.cells['digito']?.value;
		tipo = plutoRow.cells['tipo']?.value != '' ? plutoRow.cells['tipo']?.value : 'Corrente';
		nome = plutoRow.cells['nome']?.value;
		descricao = plutoRow.cells['descricao']?.value;
		bancoAgenciaModel = BancoAgenciaModel();
		bancoAgenciaModel?.nome = plutoRow.cells['bancoAgenciaModel']?.value;
	}	

	BancoContaCaixaModel clone() {
		return BancoContaCaixaModel(
			id: id,
			idBancoAgencia: idBancoAgencia,
			numero: numero,
			digito: digito,
			tipo: tipo,
			nome: nome,
			descricao: descricao,
		);			
	}

	
}