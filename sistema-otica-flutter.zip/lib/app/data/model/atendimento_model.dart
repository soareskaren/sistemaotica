import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:intl/intl.dart';
import 'package:otica/app/data/domain/domain_imports.dart';
import 'package:otica/app/infra/infra_imports.dart';

class AtendimentoModel {
	int? id;
	int? idPessoa;
	int? talao;
	DateTime? dataAtendimento;
	DateTime? dataRetorno;
	double? valorEsfericoOd;
	double? valorEsfericoOe;
	double? valorCilindricoOd;
	double? valorCilindricoOe;
	int? posicaoEixoOd;
	int? posicaoEixoOe;
	double? distanciaNasoPupilarOd;
	double? distanciaNasoPupilarOe;
	String? acuidadeVisualLongeOd;
	String? acuidadeVisualLongeOe;
	double? adicao;
	String? acuidadeVisualPertoOd;
	String? acuidadeVisualPertoOe;
	String? examinador;
	String? observacao;

	AtendimentoModel({
		this.id,
		this.idPessoa,
		this.talao,
		this.dataAtendimento,
		this.dataRetorno,
		this.valorEsfericoOd,
		this.valorEsfericoOe,
		this.valorCilindricoOd,
		this.valorCilindricoOe,
		this.posicaoEixoOd,
		this.posicaoEixoOe,
		this.distanciaNasoPupilarOd,
		this.distanciaNasoPupilarOe,
		this.acuidadeVisualLongeOd,
		this.acuidadeVisualLongeOe,
		this.adicao,
		this.acuidadeVisualPertoOd,
		this.acuidadeVisualPertoOe,
		this.examinador,
		this.observacao,
	});

	static List<String> dbColumns = <String>[
		'ID',
		'talao',
		'data_atendimento',
		'data_retorno',
		'valor_esferico_od',
		'valor_esferico_oe',
		'valor_cilindrico_od',
		'valor_cilindrico_oe',
		'posicao_eixo_od',
		'posicao_eixo_oe',
		'distancia_naso_pupilar_od',
		'distancia_naso_pupilar_oe',
		'acuidade_visual_longe_od',
		'acuidade_visual_longe_oe',
		'adicao',
		'acuidade_visual_perto_od',
		'acuidade_visual_perto_oe',
		'examinador',
		'observacao',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Talao',
		'Data Atendimento',
		'Data Retorno',
		'Valor Esferico Od',
		'Valor Esferico Oe',
		'Valor Cilindrico Od',
		'Valor Cilindrico Oe',
		'Posicao Eixo Od',
		'Posicao Eixo Oe',
		'Distancia Naso Pupilar Od',
		'Distancia Naso Pupilar Oe',
		'Acuidade Visual Longe Od',
		'Acuidade Visual Longe Oe',
		'Adicao',
		'Acuidade Visual Perto Od',
		'Acuidade Visual Perto Oe',
		'Examinador',
		'Observacao',
	];

	AtendimentoModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idPessoa = jsonData['idPessoa'];
		talao = jsonData['talao'];
		dataAtendimento = jsonData['dataAtendimento'] != null ? DateTime.tryParse(jsonData['dataAtendimento']) : null;
		dataRetorno = jsonData['dataRetorno'] != null ? DateTime.tryParse(jsonData['dataRetorno']) : null;
		valorEsfericoOd = jsonData['valorEsfericoOd']?.toDouble();
		valorEsfericoOe = jsonData['valorEsfericoOe']?.toDouble();
		valorCilindricoOd = jsonData['valorCilindricoOd']?.toDouble();
		valorCilindricoOe = jsonData['valorCilindricoOe']?.toDouble();
		posicaoEixoOd = jsonData['posicaoEixoOd'];
		posicaoEixoOe = jsonData['posicaoEixoOe'];
		distanciaNasoPupilarOd = jsonData['distanciaNasoPupilarOd']?.toDouble();
		distanciaNasoPupilarOe = jsonData['distanciaNasoPupilarOe']?.toDouble();
		acuidadeVisualLongeOd = AtendimentoDomain.getAcuidadeVisualLongeOd(jsonData['acuidadeVisualLongeOd']);
		acuidadeVisualLongeOe = AtendimentoDomain.getAcuidadeVisualLongeOe(jsonData['acuidadeVisualLongeOe']);
		adicao = jsonData['adicao']?.toDouble();
		acuidadeVisualPertoOd = AtendimentoDomain.getAcuidadeVisualPertoOd(jsonData['acuidadeVisualPertoOd']);
		acuidadeVisualPertoOe = AtendimentoDomain.getAcuidadeVisualPertoOe(jsonData['acuidadeVisualPertoOe']);
		examinador = jsonData['examinador'];
		observacao = jsonData['observacao'];
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
		jsonData['talao'] = talao;
		jsonData['dataAtendimento'] = dataAtendimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataAtendimento!) : null;
		jsonData['dataRetorno'] = dataRetorno != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRetorno!) : null;
		jsonData['valorEsfericoOd'] = valorEsfericoOd;
		jsonData['valorEsfericoOe'] = valorEsfericoOe;
		jsonData['valorCilindricoOd'] = valorCilindricoOd;
		jsonData['valorCilindricoOe'] = valorCilindricoOe;
		jsonData['posicaoEixoOd'] = posicaoEixoOd;
		jsonData['posicaoEixoOe'] = posicaoEixoOe;
		jsonData['distanciaNasoPupilarOd'] = distanciaNasoPupilarOd;
		jsonData['distanciaNasoPupilarOe'] = distanciaNasoPupilarOe;
		jsonData['acuidadeVisualLongeOd'] = AtendimentoDomain.setAcuidadeVisualLongeOd(acuidadeVisualLongeOd);
		jsonData['acuidadeVisualLongeOe'] = AtendimentoDomain.setAcuidadeVisualLongeOe(acuidadeVisualLongeOe);
		jsonData['adicao'] = adicao;
		jsonData['acuidadeVisualPertoOd'] = AtendimentoDomain.setAcuidadeVisualPertoOd(acuidadeVisualPertoOd);
		jsonData['acuidadeVisualPertoOe'] = AtendimentoDomain.setAcuidadeVisualPertoOe(acuidadeVisualPertoOe);
		jsonData['examinador'] = examinador;
		jsonData['observacao'] = observacao;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idPessoa = plutoRow.cells['idPessoa']?.value;
		talao = plutoRow.cells['talao']?.value;
		dataAtendimento = Util.stringToDate(plutoRow.cells['dataAtendimento']?.value);
		dataRetorno = Util.stringToDate(plutoRow.cells['dataRetorno']?.value);
		valorEsfericoOd = plutoRow.cells['valorEsfericoOd']?.value?.toDouble();
		valorEsfericoOe = plutoRow.cells['valorEsfericoOe']?.value?.toDouble();
		valorCilindricoOd = plutoRow.cells['valorCilindricoOd']?.value?.toDouble();
		valorCilindricoOe = plutoRow.cells['valorCilindricoOe']?.value?.toDouble();
		posicaoEixoOd = plutoRow.cells['posicaoEixoOd']?.value;
		posicaoEixoOe = plutoRow.cells['posicaoEixoOe']?.value;
		distanciaNasoPupilarOd = plutoRow.cells['distanciaNasoPupilarOd']?.value?.toDouble();
		distanciaNasoPupilarOe = plutoRow.cells['distanciaNasoPupilarOe']?.value?.toDouble();
		acuidadeVisualLongeOd = plutoRow.cells['acuidadeVisualLongeOd']?.value != '' ? plutoRow.cells['acuidadeVisualLongeOd']?.value : '20/20';
		acuidadeVisualLongeOe = plutoRow.cells['acuidadeVisualLongeOe']?.value != '' ? plutoRow.cells['acuidadeVisualLongeOe']?.value : '20/20';
		adicao = plutoRow.cells['adicao']?.value?.toDouble();
		acuidadeVisualPertoOd = plutoRow.cells['acuidadeVisualPertoOd']?.value != '' ? plutoRow.cells['acuidadeVisualPertoOd']?.value : 'J1';
		acuidadeVisualPertoOe = plutoRow.cells['acuidadeVisualPertoOe']?.value != '' ? plutoRow.cells['acuidadeVisualPertoOe']?.value : 'J1';
		examinador = plutoRow.cells['examinador']?.value;
		observacao = plutoRow.cells['observacao']?.value;
	}	

	AtendimentoModel clone() {
		return AtendimentoModel(
			id: id,
			idPessoa: idPessoa,
			talao: talao,
			dataAtendimento: dataAtendimento,
			dataRetorno: dataRetorno,
			valorEsfericoOd: valorEsfericoOd,
			valorEsfericoOe: valorEsfericoOe,
			valorCilindricoOd: valorCilindricoOd,
			valorCilindricoOe: valorCilindricoOe,
			posicaoEixoOd: posicaoEixoOd,
			posicaoEixoOe: posicaoEixoOe,
			distanciaNasoPupilarOd: distanciaNasoPupilarOd,
			distanciaNasoPupilarOe: distanciaNasoPupilarOe,
			acuidadeVisualLongeOd: acuidadeVisualLongeOd,
			acuidadeVisualLongeOe: acuidadeVisualLongeOe,
			adicao: adicao,
			acuidadeVisualPertoOd: acuidadeVisualPertoOd,
			acuidadeVisualPertoOe: acuidadeVisualPertoOe,
			examinador: examinador,
			observacao: observacao,
		);			
	}

	
}