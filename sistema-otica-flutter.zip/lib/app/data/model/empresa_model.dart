import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:otica/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:otica/app/data/domain/domain_imports.dart';
import 'dart:typed_data';

class EmpresaModel {
	int? id;
	String? razaoSocial;
	String? nomeFantasia;
	String? cnpj;
	String? inscricaoEstadual;
	String? inscricaoMunicipal;
	String? tipoRegime;
	String? crt;
	String? email;
	String? site;
	String? contato;
	DateTime? dataConstituicao;
	int? codigoIbgeCidade;
	int? codigoIbgeUf;
	String? cei;
	String? codigoCnaePrincipal;
	Uint8List? imagemLogotipo;

	EmpresaModel({
		this.id,
		this.razaoSocial,
		this.nomeFantasia,
		this.cnpj,
		this.inscricaoEstadual,
		this.inscricaoMunicipal,
		this.tipoRegime,
		this.crt,
		this.email,
		this.site,
		this.contato,
		this.dataConstituicao,
		this.codigoIbgeCidade,
		this.codigoIbgeUf,
		this.cei,
		this.codigoCnaePrincipal,
		this.imagemLogotipo,
	});

	static List<String> dbColumns = <String>[
		'id',
		'razao_social',
		'nome_fantasia',
		'cnpj',
		'inscricao_estadual',
		'inscricao_municipal',
		'tipo_regime',
		'crt',
		'email',
		'site',
		'contato',
		'data_constituicao',
		'codigo_ibge_cidade',
		'codigo_ibge_uf',
		'cei',
		'codigo_cnae_principal',
		'imagem_logotipo',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Razao Social',
		'Nome Fantasia',
		'Cnpj',
		'Inscricao Estadual',
		'Inscricao Municipal',
		'Tipo Regime',
		'Crt',
		'Email',
		'Site',
		'Contato',
		'Data Constituicao',
		'Codigo Ibge Cidade',
		'Codigo Ibge Uf',
		'Cei',
		'Codigo Cnae Principal',
		'Imagem Logotipo',
	];

	EmpresaModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		razaoSocial = jsonData['razaoSocial'];
		nomeFantasia = jsonData['nomeFantasia'];
		cnpj = jsonData['cnpj'];
		inscricaoEstadual = jsonData['inscricaoEstadual'];
		inscricaoMunicipal = jsonData['inscricaoMunicipal'];
		tipoRegime = EmpresaDomain.getTipoRegime(jsonData['tipoRegime']);
		crt = EmpresaDomain.getCrt(jsonData['crt']);
		email = jsonData['email'];
		site = jsonData['site'];
		contato = jsonData['contato'];
		dataConstituicao = jsonData['dataConstituicao'] != null ? DateTime.tryParse(jsonData['dataConstituicao']) : null;
		codigoIbgeCidade = jsonData['codigoIbgeCidade'];
		codigoIbgeUf = jsonData['codigoIbgeUf'];
		cei = jsonData['cei'];
		codigoCnaePrincipal = jsonData['codigoCnaePrincipal'];
		imagemLogotipo = jsonData['imagemLogotipo'];
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['razaoSocial'] = razaoSocial;
		jsonData['nomeFantasia'] = nomeFantasia;
		jsonData['cnpj'] = Util.removeMask(cnpj);
		jsonData['inscricaoEstadual'] = inscricaoEstadual;
		jsonData['inscricaoMunicipal'] = inscricaoMunicipal;
		jsonData['tipoRegime'] = EmpresaDomain.setTipoRegime(tipoRegime);
		jsonData['crt'] = EmpresaDomain.setCrt(crt);
		jsonData['email'] = email;
		jsonData['site'] = site;
		jsonData['contato'] = contato;
		jsonData['dataConstituicao'] = dataConstituicao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataConstituicao!) : null;
		jsonData['codigoIbgeCidade'] = codigoIbgeCidade;
		jsonData['codigoIbgeUf'] = codigoIbgeUf;
		jsonData['cei'] = cei;
		jsonData['codigoCnaePrincipal'] = codigoCnaePrincipal;
		jsonData['imagemLogotipo'] = imagemLogotipo;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		razaoSocial = plutoRow.cells['razaoSocial']?.value;
		nomeFantasia = plutoRow.cells['nomeFantasia']?.value;
		cnpj = plutoRow.cells['cnpj']?.value;
		inscricaoEstadual = plutoRow.cells['inscricaoEstadual']?.value;
		inscricaoMunicipal = plutoRow.cells['inscricaoMunicipal']?.value;
		tipoRegime = plutoRow.cells['tipoRegime']?.value != '' ? plutoRow.cells['tipoRegime']?.value : '1-lucro real';
		crt = plutoRow.cells['crt']?.value != '' ? plutoRow.cells['crt']?.value : '1-simples nacional';
		email = plutoRow.cells['email']?.value;
		site = plutoRow.cells['site']?.value;
		contato = plutoRow.cells['contato']?.value;
		dataConstituicao = Util.stringToDate(plutoRow.cells['dataConstituicao']?.value);
		codigoIbgeCidade = plutoRow.cells['codigoIbgeCidade']?.value;
		codigoIbgeUf = plutoRow.cells['codigoIbgeUf']?.value;
		cei = plutoRow.cells['cei']?.value;
		codigoCnaePrincipal = plutoRow.cells['codigoCnaePrincipal']?.value;
		//imagemLogotipo = plutoRow.cells['imagemLogotipo']?.value; TODO: implement the specific way to handle your BLOB data.
	}	

	EmpresaModel clone() {
		return EmpresaModel(
			id: id,
			razaoSocial: razaoSocial,
			nomeFantasia: nomeFantasia,
			cnpj: cnpj,
			inscricaoEstadual: inscricaoEstadual,
			inscricaoMunicipal: inscricaoMunicipal,
			tipoRegime: tipoRegime,
			crt: crt,
			email: email,
			site: site,
			contato: contato,
			dataConstituicao: dataConstituicao,
			codigoIbgeCidade: codigoIbgeCidade,
			codigoIbgeUf: codigoIbgeUf,
			cei: cei,
			codigoCnaePrincipal: codigoCnaePrincipal,
			imagemLogotipo: imagemLogotipo,
		);			
	}

	
}