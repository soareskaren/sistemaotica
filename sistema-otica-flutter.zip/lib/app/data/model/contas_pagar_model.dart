import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:otica/app/data/model/model_imports.dart';
import 'package:intl/intl.dart';
import 'package:otica/app/infra/infra_imports.dart';

class ContasPagarModel {
	int? id;
	int? idPessoa;
	int? idFormaPagamento;
	int? idBancoContaCaixa;
	DateTime? dataLancamento;
	double? valorTotal;
	int? numeroParcela;
	double? valorParcela;
	DateTime? dataVencimento;
	DateTime? dataRecebimento;
	double? valorRecebido;
	String? observacao;
	FormaPagamentoModel? formaPagamentoModel;
	PessoaModel? pessoaModel;
	BancoContaCaixaModel? bancoContaCaixaModel;

	ContasPagarModel({
		this.id,
		this.idPessoa,
		this.idFormaPagamento,
		this.idBancoContaCaixa,
		this.dataLancamento,
		this.valorTotal,
		this.numeroParcela,
		this.valorParcela,
		this.dataVencimento,
		this.dataRecebimento,
		this.valorRecebido,
		this.observacao,
		this.formaPagamentoModel,
		this.pessoaModel,
		this.bancoContaCaixaModel,
	});

	static List<String> dbColumns = <String>[
		'id',
		'data_lancamento',
		'valor_total',
		'numero_parcela',
		'valor_parcela',
		'data_vencimento',
		'data_recebimento',
		'valor_recebido',
		'observacao',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Data Lancamento',
		'Valor Total',
		'Numero Parcela',
		'Valor Parcela',
		'Data Vencimento',
		'Data Recebimento',
		'Valor Recebido',
		'Observacao',
	];

	ContasPagarModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idPessoa = jsonData['idPessoa'];
		idFormaPagamento = jsonData['idFormaPagamento'];
		idBancoContaCaixa = jsonData['idBancoContaCaixa'];
		dataLancamento = jsonData['dataLancamento'] != null ? DateTime.tryParse(jsonData['dataLancamento']) : null;
		valorTotal = jsonData['valorTotal']?.toDouble();
		numeroParcela = jsonData['numeroParcela'];
		valorParcela = jsonData['valorParcela']?.toDouble();
		dataVencimento = jsonData['dataVencimento'] != null ? DateTime.tryParse(jsonData['dataVencimento']) : null;
		dataRecebimento = jsonData['dataRecebimento'] != null ? DateTime.tryParse(jsonData['dataRecebimento']) : null;
		valorRecebido = jsonData['valorRecebido']?.toDouble();
		observacao = jsonData['observacao'];
		formaPagamentoModel = jsonData['formaPagamentoModel'] == null ? FormaPagamentoModel() : FormaPagamentoModel.fromJson(jsonData['formaPagamentoModel']);
		pessoaModel = jsonData['pessoaModel'] == null ? PessoaModel() : PessoaModel.fromJson(jsonData['pessoaModel']);
		bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
		jsonData['idFormaPagamento'] = idFormaPagamento != 0 ? idFormaPagamento : null;
		jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
		jsonData['dataLancamento'] = dataLancamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataLancamento!) : null;
		jsonData['valorTotal'] = valorTotal;
		jsonData['numeroParcela'] = numeroParcela;
		jsonData['valorParcela'] = valorParcela;
		jsonData['dataVencimento'] = dataVencimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVencimento!) : null;
		jsonData['dataRecebimento'] = dataRecebimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRecebimento!) : null;
		jsonData['valorRecebido'] = valorRecebido;
		jsonData['observacao'] = observacao;
		jsonData['formaPagamentoModel'] = formaPagamentoModel?.toJson;
		jsonData['pessoaModel'] = pessoaModel?.toJson;
		jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idPessoa = plutoRow.cells['idPessoa']?.value;
		idFormaPagamento = plutoRow.cells['idFormaPagamento']?.value;
		idBancoContaCaixa = plutoRow.cells['idBancoContaCaixa']?.value;
		dataLancamento = Util.stringToDate(plutoRow.cells['dataLancamento']?.value);
		valorTotal = plutoRow.cells['valorTotal']?.value?.toDouble();
		numeroParcela = plutoRow.cells['numeroParcela']?.value;
		valorParcela = plutoRow.cells['valorParcela']?.value?.toDouble();
		dataVencimento = Util.stringToDate(plutoRow.cells['dataVencimento']?.value);
		dataRecebimento = Util.stringToDate(plutoRow.cells['dataRecebimento']?.value);
		valorRecebido = plutoRow.cells['valorRecebido']?.value?.toDouble();
		observacao = plutoRow.cells['observacao']?.value;
		formaPagamentoModel = FormaPagamentoModel();
		formaPagamentoModel?.nome = plutoRow.cells['formaPagamentoModel']?.value;
		pessoaModel = PessoaModel();
		pessoaModel?.nome = plutoRow.cells['pessoaModel']?.value;
		bancoContaCaixaModel = BancoContaCaixaModel();
		bancoContaCaixaModel?.nome = plutoRow.cells['bancoContaCaixaModel']?.value;
	}	

	ContasPagarModel clone() {
		return ContasPagarModel(
			id: id,
			idPessoa: idPessoa,
			idFormaPagamento: idFormaPagamento,
			idBancoContaCaixa: idBancoContaCaixa,
			dataLancamento: dataLancamento,
			valorTotal: valorTotal,
			numeroParcela: numeroParcela,
			valorParcela: valorParcela,
			dataVencimento: dataVencimento,
			dataRecebimento: dataRecebimento,
			valorRecebido: valorRecebido,
			observacao: observacao,
		);			
	}

	
}