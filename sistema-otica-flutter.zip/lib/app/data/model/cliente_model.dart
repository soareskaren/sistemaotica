import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:intl/intl.dart';
import 'package:otica/app/infra/infra_imports.dart';

class ClienteModel {
	int? id;
	int? idPessoa;
	DateTime? desde;
	double? taxaDesconto;
	double? limiteCredito;
	String? ocupacao;
	String? observacao;

	ClienteModel({
		this.id,
		this.idPessoa,
		this.desde,
		this.taxaDesconto,
		this.limiteCredito,
		this.ocupacao,
		this.observacao,
	});

	static List<String> dbColumns = <String>[
		'id',
		'desde',
		'taxa_desconto',
		'limite_credito',
		'ocupacao',
		'observacao',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Desde',
		'Taxa Desconto',
		'Limite Credito',
		'Ocupacao',
		'Observacao',
	];

	ClienteModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idPessoa = jsonData['idPessoa'];
		desde = jsonData['desde'] != null ? DateTime.tryParse(jsonData['desde']) : null;
		taxaDesconto = jsonData['taxaDesconto']?.toDouble();
		limiteCredito = jsonData['limiteCredito']?.toDouble();
		ocupacao = jsonData['ocupacao'];
		observacao = jsonData['observacao'];
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
		jsonData['desde'] = desde != null ? DateFormat('yyyy-MM-ddT00:00:00').format(desde!) : null;
		jsonData['taxaDesconto'] = taxaDesconto;
		jsonData['limiteCredito'] = limiteCredito;
		jsonData['ocupacao'] = ocupacao;
		jsonData['observacao'] = observacao;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idPessoa = plutoRow.cells['idPessoa']?.value;
		desde = Util.stringToDate(plutoRow.cells['desde']?.value);
		taxaDesconto = plutoRow.cells['taxaDesconto']?.value?.toDouble();
		limiteCredito = plutoRow.cells['limiteCredito']?.value?.toDouble();
		ocupacao = plutoRow.cells['ocupacao']?.value;
		observacao = plutoRow.cells['observacao']?.value;
	}	

	ClienteModel clone() {
		return ClienteModel(
			id: id,
			idPessoa: idPessoa,
			desde: desde,
			taxaDesconto: taxaDesconto,
			limiteCredito: limiteCredito,
			ocupacao: ocupacao,
			observacao: observacao,
		);			
	}

	
}