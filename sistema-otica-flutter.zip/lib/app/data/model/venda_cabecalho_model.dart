import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:otica/app/data/model/model_imports.dart';
import 'package:intl/intl.dart';
import 'package:otica/app/infra/infra_imports.dart';

class VendaCabecalhoModel {
	int? id;
	int? idPessoa;
	int? codigo;
	DateTime? dataVenda;
	double? valorSubtotal;
	double? valorDesconto;
	double? valorTotal;
	int? quantidadeParcelas;
	DateTime? primeiroVencimento;
	DateTime? dataPrevistaEntrega;
	DateTime? dataEntrega;
	List<VendaDetalheModel>? vendaDetalheModelList;
	PessoaModel? pessoaModel;

	VendaCabecalhoModel({
		this.id,
		this.idPessoa,
		this.codigo,
		this.dataVenda,
		this.valorSubtotal,
		this.valorDesconto,
		this.valorTotal,
		this.quantidadeParcelas,
		this.primeiroVencimento,
		this.dataPrevistaEntrega,
		this.dataEntrega,
		this.vendaDetalheModelList,
		this.pessoaModel,
	});

	static List<String> dbColumns = <String>[
		'id',
		'codigo',
		'data_venda',
		'valor_subtotal',
		'valor_desconto',
		'valor_total',
		'quantidade_parcelas',
		'primeiro_vencimento',
		'data_prevista_entrega',
		'data_entrega',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Codigo',
		'Data Venda',
		'Valor Subtotal',
		'Valor Desconto',
		'Valor Total',
		'Quantidade Parcelas',
		'Primeiro Vencimento',
		'Data Prevista Entrega',
		'Data Entrega',
	];

	VendaCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idPessoa = jsonData['idPessoa'];
		codigo = jsonData['codigo'];
		dataVenda = jsonData['dataVenda'] != null ? DateTime.tryParse(jsonData['dataVenda']) : null;
		valorSubtotal = jsonData['valorSubtotal']?.toDouble();
		valorDesconto = jsonData['valorDesconto']?.toDouble();
		valorTotal = jsonData['valorTotal']?.toDouble();
		quantidadeParcelas = jsonData['quantidadeParcelas'];
		primeiroVencimento = jsonData['primeiroVencimento'] != null ? DateTime.tryParse(jsonData['primeiroVencimento']) : null;
		dataPrevistaEntrega = jsonData['dataPrevistaEntrega'] != null ? DateTime.tryParse(jsonData['dataPrevistaEntrega']) : null;
		dataEntrega = jsonData['dataEntrega'] != null ? DateTime.tryParse(jsonData['dataEntrega']) : null;
		vendaDetalheModelList = (jsonData['vendaDetalheModelList'] as Iterable?)?.map((m) => VendaDetalheModel.fromJson(m)).toList() ?? [];
		pessoaModel = jsonData['pessoaModel'] == null ? PessoaModel() : PessoaModel.fromJson(jsonData['pessoaModel']);
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
		jsonData['codigo'] = codigo;
		jsonData['dataVenda'] = dataVenda != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVenda!) : null;
		jsonData['valorSubtotal'] = valorSubtotal;
		jsonData['valorDesconto'] = valorDesconto;
		jsonData['valorTotal'] = valorTotal;
		jsonData['quantidadeParcelas'] = quantidadeParcelas;
		jsonData['primeiroVencimento'] = primeiroVencimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(primeiroVencimento!) : null;
		jsonData['dataPrevistaEntrega'] = dataPrevistaEntrega != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataPrevistaEntrega!) : null;
		jsonData['dataEntrega'] = dataEntrega != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEntrega!) : null;
		
		var vendaDetalheModelLocalList = []; 
		for (VendaDetalheModel object in vendaDetalheModelList ?? []) { 
			vendaDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['vendaDetalheModelList'] = vendaDetalheModelLocalList;
		jsonData['pessoaModel'] = pessoaModel?.toJson;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idPessoa = plutoRow.cells['idPessoa']?.value;
		codigo = plutoRow.cells['codigo']?.value;
		dataVenda = Util.stringToDate(plutoRow.cells['dataVenda']?.value);
		valorSubtotal = plutoRow.cells['valorSubtotal']?.value?.toDouble();
		valorDesconto = plutoRow.cells['valorDesconto']?.value?.toDouble();
		valorTotal = plutoRow.cells['valorTotal']?.value?.toDouble();
		quantidadeParcelas = plutoRow.cells['quantidadeParcelas']?.value;
		primeiroVencimento = Util.stringToDate(plutoRow.cells['primeiroVencimento']?.value);
		dataPrevistaEntrega = Util.stringToDate(plutoRow.cells['dataPrevistaEntrega']?.value);
		dataEntrega = Util.stringToDate(plutoRow.cells['dataEntrega']?.value);
		vendaDetalheModelList = [];
		pessoaModel = PessoaModel();
		pessoaModel?.nome = plutoRow.cells['pessoaModel']?.value;
	}	

	VendaCabecalhoModel clone() {
		return VendaCabecalhoModel(
			id: id,
			idPessoa: idPessoa,
			codigo: codigo,
			dataVenda: dataVenda,
			valorSubtotal: valorSubtotal,
			valorDesconto: valorDesconto,
			valorTotal: valorTotal,
			quantidadeParcelas: quantidadeParcelas,
			primeiroVencimento: primeiroVencimento,
			dataPrevistaEntrega: dataPrevistaEntrega,
			dataEntrega: dataEntrega,
			vendaDetalheModelList: vendaDetalheModelListClone(vendaDetalheModelList!),
		);			
	}

	vendaDetalheModelListClone(List<VendaDetalheModel> vendaDetalheModelList) { 
		List<VendaDetalheModel> resultList = [];
		for (var vendaDetalheModel in vendaDetalheModelList) {
			resultList.add(
				VendaDetalheModel(
					id: vendaDetalheModel.id,
					idVendaCabecalho: vendaDetalheModel.idVendaCabecalho,
					idProduto: vendaDetalheModel.idProduto,
					quantidade: vendaDetalheModel.quantidade,
					valorUnitario: vendaDetalheModel.valorUnitario,
					taxaDesconto: vendaDetalheModel.taxaDesconto,
					valorDesconto: vendaDetalheModel.valorDesconto,
					valorTotal: vendaDetalheModel.valorTotal,
				)
			);
		}
		return resultList;
	}

	
}