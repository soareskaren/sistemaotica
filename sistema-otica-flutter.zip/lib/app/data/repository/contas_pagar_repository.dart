import 'package:otica/app/infra/constants.dart';
import 'package:otica/app/data/provider/api/contas_pagar_api_provider.dart';
import 'package:otica/app/data/provider/drift/contas_pagar_drift_provider.dart';
import 'package:otica/app/data/model/model_imports.dart';

class ContasPagarRepository {
  final ContasPagarApiProvider contasPagarApiProvider;
  final ContasPagarDriftProvider contasPagarDriftProvider;

  ContasPagarRepository({required this.contasPagarApiProvider, required this.contasPagarDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await contasPagarDriftProvider.getList(filter: filter);
    } else {
      return await contasPagarApiProvider.getList(filter: filter);
    }
  }

  Future<ContasPagarModel?>? save({required ContasPagarModel contasPagarModel}) async {
    if (contasPagarModel.id! > 0) {
      if (Constants.usingLocalDatabase) {
        return await contasPagarDriftProvider.update(contasPagarModel);
      } else {
        return await contasPagarApiProvider.update(contasPagarModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await contasPagarDriftProvider.insert(contasPagarModel);
      } else {
        return await contasPagarApiProvider.insert(contasPagarModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await contasPagarDriftProvider.delete(id) ?? false;
    } else {
      return await contasPagarApiProvider.delete(id) ?? false;
    }
  }
}