import 'package:otica/app/infra/constants.dart';
import 'package:otica/app/data/provider/api/contas_receber_api_provider.dart';
import 'package:otica/app/data/provider/drift/contas_receber_drift_provider.dart';
import 'package:otica/app/data/model/model_imports.dart';

class ContasReceberRepository {
  final ContasReceberApiProvider contasReceberApiProvider;
  final ContasReceberDriftProvider contasReceberDriftProvider;

  ContasReceberRepository({required this.contasReceberApiProvider, required this.contasReceberDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await contasReceberDriftProvider.getList(filter: filter);
    } else {
      return await contasReceberApiProvider.getList(filter: filter);
    }
  }

  Future<ContasReceberModel?>? save({required ContasReceberModel contasReceberModel}) async {
    if (contasReceberModel.id! > 0) {
      if (Constants.usingLocalDatabase) {
        return await contasReceberDriftProvider.update(contasReceberModel);
      } else {
        return await contasReceberApiProvider.update(contasReceberModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await contasReceberDriftProvider.insert(contasReceberModel);
      } else {
        return await contasReceberApiProvider.insert(contasReceberModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await contasReceberDriftProvider.delete(id) ?? false;
    } else {
      return await contasReceberApiProvider.delete(id) ?? false;
    }
  }
}