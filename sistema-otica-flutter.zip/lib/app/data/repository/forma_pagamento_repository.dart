import 'package:otica/app/infra/constants.dart';
import 'package:otica/app/data/provider/api/forma_pagamento_api_provider.dart';
import 'package:otica/app/data/provider/drift/forma_pagamento_drift_provider.dart';
import 'package:otica/app/data/model/model_imports.dart';

class FormaPagamentoRepository {
  final FormaPagamentoApiProvider formaPagamentoApiProvider;
  final FormaPagamentoDriftProvider formaPagamentoDriftProvider;

  FormaPagamentoRepository({required this.formaPagamentoApiProvider, required this.formaPagamentoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await formaPagamentoDriftProvider.getList(filter: filter);
    } else {
      return await formaPagamentoApiProvider.getList(filter: filter);
    }
  }

  Future<FormaPagamentoModel?>? save({required FormaPagamentoModel formaPagamentoModel}) async {
    if (formaPagamentoModel.id! > 0) {
      if (Constants.usingLocalDatabase) {
        return await formaPagamentoDriftProvider.update(formaPagamentoModel);
      } else {
        return await formaPagamentoApiProvider.update(formaPagamentoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await formaPagamentoDriftProvider.insert(formaPagamentoModel);
      } else {
        return await formaPagamentoApiProvider.insert(formaPagamentoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await formaPagamentoDriftProvider.delete(id) ?? false;
    } else {
      return await formaPagamentoApiProvider.delete(id) ?? false;
    }
  }
}