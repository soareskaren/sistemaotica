class PessoaDomain {
	PessoaDomain._();

	static getTipo(String? tipo) { 
		switch (tipo) { 
			case '': 
			case '0': 
				return 'Física'; 
			case '1': 
				return 'Jurídica'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(String? tipo) { 
		switch (tipo) { 
			case 'Física': 
				return '0'; 
			case 'Jurídica': 
				return '1'; 
			default: 
				return null; 
		} 
	}

	static getEhCliente(String? ehCliente) { 
		switch (ehCliente) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setEhCliente(String? ehCliente) { 
		switch (ehCliente) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getEhFornecedor(String? ehFornecedor) { 
		switch (ehFornecedor) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setEhFornecedor(String? ehFornecedor) { 
		switch (ehFornecedor) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}