class AtendimentoDomain {
	AtendimentoDomain._();

	static getAcuidadeVisualLongeOd(String? acuidadeVisualLongeOd) { 
		switch (acuidadeVisualLongeOd) { 
			case '': 
			case '20/20': 
				return '20/20'; 
			case '20/30': 
				return '20/30'; 
			case '20/40': 
				return '20/40'; 
			case '20/80': 
				return '20/80'; 
			case '20/100': 
				return '20/100'; 
			case '20/200': 
				return '20/200'; 
			case '20/400': 
				return '20/400'; 
			default: 
				return null; 
		} 
	} 

	static setAcuidadeVisualLongeOd(String? acuidadeVisualLongeOd) { 
		switch (acuidadeVisualLongeOd) { 
			case '20/20': 
				return '20/20'; 
			case '20/30': 
				return '20/30'; 
			case '20/40': 
				return '20/40'; 
			case '20/80': 
				return '20/80'; 
			case '20/100': 
				return '20/100'; 
			case '20/200': 
				return '20/200'; 
			case '20/400': 
				return '20/400'; 
			default: 
				return null; 
		} 
	}

	static getAcuidadeVisualLongeOe(String? acuidadeVisualLongeOe) { 
		switch (acuidadeVisualLongeOe) { 
			case '': 
			case '20/20': 
				return '20/20'; 
			case '20/30': 
				return '20/30'; 
			case '20/40': 
				return '20/40'; 
			case '20/80': 
				return '20/80'; 
			case '20/100': 
				return '20/100'; 
			case '20/200': 
				return '20/200'; 
			case '20/400': 
				return '20/400'; 
			default: 
				return null; 
		} 
	} 

	static setAcuidadeVisualLongeOe(String? acuidadeVisualLongeOe) { 
		switch (acuidadeVisualLongeOe) { 
			case '20/20': 
				return '20/20'; 
			case '20/30': 
				return '20/30'; 
			case '20/40': 
				return '20/40'; 
			case '20/80': 
				return '20/80'; 
			case '20/100': 
				return '20/100'; 
			case '20/200': 
				return '20/200'; 
			case '20/400': 
				return '20/400'; 
			default: 
				return null; 
		} 
	}

	static getAcuidadeVisualPertoOd(String? acuidadeVisualPertoOd) { 
		switch (acuidadeVisualPertoOd) { 
			case '': 
			case 'J1': 
				return 'J1'; 
			case 'J2': 
				return 'J2'; 
			case 'J3': 
				return 'J3'; 
			case 'J4': 
				return 'J4'; 
			case 'J5': 
				return 'J5'; 
			case 'J6': 
				return 'J6'; 
			default: 
				return null; 
		} 
	} 

	static setAcuidadeVisualPertoOd(String? acuidadeVisualPertoOd) { 
		switch (acuidadeVisualPertoOd) { 
			case 'J1': 
				return 'J1'; 
			case 'J2': 
				return 'J2'; 
			case 'J3': 
				return 'J3'; 
			case 'J4': 
				return 'J4'; 
			case 'J5': 
				return 'J5'; 
			case 'J6': 
				return 'J6'; 
			default: 
				return null; 
		} 
	}

	static getAcuidadeVisualPertoOe(String? acuidadeVisualPertoOe) { 
		switch (acuidadeVisualPertoOe) { 
			case '': 
			case 'J1': 
				return 'J1'; 
			case 'J2': 
				return 'J2'; 
			case 'J3': 
				return 'J3'; 
			case 'J4': 
				return 'J4'; 
			case 'J5': 
				return 'J5'; 
			case 'J6': 
				return 'J6'; 
			default: 
				return null; 
		} 
	} 

	static setAcuidadeVisualPertoOe(String? acuidadeVisualPertoOe) { 
		switch (acuidadeVisualPertoOe) { 
			case 'J1': 
				return 'J1'; 
			case 'J2': 
				return 'J2'; 
			case 'J3': 
				return 'J3'; 
			case 'J4': 
				return 'J4'; 
			case 'J5': 
				return 'J5'; 
			case 'J6': 
				return 'J6'; 
			default: 
				return null; 
		} 
	}

}