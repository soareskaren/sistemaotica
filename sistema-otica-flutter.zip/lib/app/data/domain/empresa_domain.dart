class EmpresaDomain {
	EmpresaDomain._();

	static getTipoRegime(String? tipoRegime) { 
		switch (tipoRegime) { 
			case '': 
			case '1': 
				return '1-lucro real'; 
			case '2': 
				return '2-lucro presumido'; 
			case '3': 
				return '3-simples nacional'; 
			default: 
				return null; 
		} 
	} 

	static setTipoRegime(String? tipoRegime) { 
		switch (tipoRegime) { 
			case '1-lucro real': 
				return '1'; 
			case '2-lucro presumido': 
				return '2'; 
			case '3-simples nacional': 
				return '3'; 
			default: 
				return null; 
		} 
	}

	static getCrt(String? crt) { 
		switch (crt) { 
			case '': 
			case '1': 
				return '1-simples nacional'; 
			case '2': 
				return '2-simples nacional - excesso de sublimite da receita bruta'; 
			case '3': 
				return '3-regime normal'; 
			default: 
				return null; 
		} 
	} 

	static setCrt(String? crt) { 
		switch (crt) { 
			case '1-simples nacional': 
				return '1'; 
			case '2-simples nacional - excesso de sublimite da receita bruta': 
				return '2'; 
			case '3-regime normal': 
				return '3'; 
			default: 
				return null; 
		} 
	}

}