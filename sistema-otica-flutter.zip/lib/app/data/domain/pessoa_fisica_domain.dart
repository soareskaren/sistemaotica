class PessoaFisicaDomain {
	PessoaFisicaDomain._();

	static getSexo(String? sexo) { 
		switch (sexo) { 
			case '': 
			case 'M': 
				return 'Masculino'; 
			case 'F': 
				return 'Feminino'; 
			case 'N': 
				return 'Não Informado'; 
			default: 
				return null; 
		} 
	} 

	static setSexo(String? sexo) { 
		switch (sexo) { 
			case 'Masculino': 
				return 'M'; 
			case 'Feminino': 
				return 'F'; 
			case 'Não Informado': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getRaca(String? raca) { 
		switch (raca) { 
			case '': 
			case 'B': 
				return 'Branco'; 
			case 'N': 
				return 'Negro'; 
			case 'P': 
				return 'Pardo'; 
			case 'A': 
				return 'Amarelo'; 
			case 'I': 
				return 'Indígena'; 
			case 'O': 
				return 'Outro'; 
			default: 
				return null; 
		} 
	} 

	static setRaca(String? raca) { 
		switch (raca) { 
			case 'Branco': 
				return 'B'; 
			case 'Negro': 
				return 'N'; 
			case 'Pardo': 
				return 'P'; 
			case 'Amarelo': 
				return 'A'; 
			case 'Indígena': 
				return 'I'; 
			case 'Outro': 
				return 'O'; 
			default: 
				return null; 
		} 
	}

}