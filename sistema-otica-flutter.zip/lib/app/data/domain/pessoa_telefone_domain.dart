class PessoaTelefoneDomain {
	PessoaTelefoneDomain._();

	static getTipo(String? tipo) { 
		switch (tipo) { 
			case '': 
			case '0': 
				return 'Celular'; 
			case '1': 
				return 'Fixo'; 
			case '2': 
				return 'Trabalho'; 
			case '3': 
				return 'WhatsApp'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(String? tipo) { 
		switch (tipo) { 
			case 'Celular': 
				return '0'; 
			case 'Fixo': 
				return '1'; 
			case 'Trabalho': 
				return '2'; 
			case 'WhatsApp': 
				return '3'; 
			default: 
				return null; 
		} 
	}

}