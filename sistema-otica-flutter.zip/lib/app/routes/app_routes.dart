abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const vendaCabecalhoListPage = '/vendaCabecalhoListPage'; 
	static const vendaCabecalhoTabPage = '/vendaCabecalhoTabPage';
	static const pessoaListPage = '/pessoaListPage'; 
	static const pessoaTabPage = '/pessoaTabPage';
	static const empresaListPage = '/empresaListPage'; 
	static const empresaEditPage = '/empresaEditPage';
	static const formaPagamentoListPage = '/formaPagamentoListPage'; 
	static const formaPagamentoEditPage = '/formaPagamentoEditPage';
	static const nivelFormacaoListPage = '/nivelFormacaoListPage'; 
	static const nivelFormacaoEditPage = '/nivelFormacaoEditPage';
	static const bancoListPage = '/bancoListPage'; 
	static const bancoEditPage = '/bancoEditPage';
	static const usuarioListPage = '/usuarioListPage'; 
	static const usuarioEditPage = '/usuarioEditPage';
	static const contasPagarListPage = '/contasPagarListPage'; 
	static const contasPagarEditPage = '/contasPagarEditPage';
	static const produtoListPage = '/produtoListPage'; 
	static const produtoEditPage = '/produtoEditPage';
	static const bancoContaCaixaListPage = '/bancoContaCaixaListPage'; 
	static const bancoContaCaixaEditPage = '/bancoContaCaixaEditPage';
	static const contasReceberListPage = '/contasReceberListPage'; 
	static const contasReceberEditPage = '/contasReceberEditPage';
	static const produtoUnidadeListPage = '/produtoUnidadeListPage'; 
	static const produtoUnidadeEditPage = '/produtoUnidadeEditPage';
	static const produtoMarcaListPage = '/produtoMarcaListPage'; 
	static const produtoMarcaEditPage = '/produtoMarcaEditPage';
	static const estadoCivilListPage = '/estadoCivilListPage'; 
	static const estadoCivilEditPage = '/estadoCivilEditPage';
	static const bancoAgenciaListPage = '/bancoAgenciaListPage'; 
	static const bancoAgenciaEditPage = '/bancoAgenciaEditPage';
}