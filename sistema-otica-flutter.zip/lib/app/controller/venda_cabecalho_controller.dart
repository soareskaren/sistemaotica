import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/controller/controller_imports.dart';
import 'package:otica/app/data/model/model_imports.dart';
import 'package:otica/app/page/grid_columns/grid_columns_imports.dart';
import 'package:otica/app/page/page_imports.dart';

import 'package:otica/app/routes/app_routes.dart';
import 'package:otica/app/data/repository/venda_cabecalho_repository.dart';
import 'package:otica/app/page/shared_page/shared_page_imports.dart';
import 'package:otica/app/page/shared_widget/message_dialog.dart';

class VendaCabecalhoController extends GetxController with GetSingleTickerProviderStateMixin {
	final VendaCabecalhoRepository vendaCabecalhoRepository;
	VendaCabecalhoController({required this.vendaCabecalhoRepository});

	// general
	final _dbColumns = VendaCabecalhoModel.dbColumns;
	get dbColumns => _dbColumns;

	final _aliasColumns = VendaCabecalhoModel.aliasColumns;
	get aliasColumns => _aliasColumns;

	final gridColumns = vendaCabecalhoGridColumns();
	
	var _vendaCabecalhoModelList = <VendaCabecalhoModel>[];

	var _vendaCabecalhoModelOld = VendaCabecalhoModel();

	final _vendaCabecalhoModel = VendaCabecalhoModel().obs;
	VendaCabecalhoModel get vendaCabecalhoModel => _vendaCabecalhoModel.value;
	set vendaCabecalhoModel(value) => _vendaCabecalhoModel.value = value ?? VendaCabecalhoModel();

	final _filter = Filter().obs;
	Filter get filter => _filter.value;
	set filter(value) => _filter.value = value ?? Filter(); 
	
	var _isInserting = false;

	// tab page
	late TabController tabController;

	List<Tab> tabItems = [
		Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Venda Cabecalho', 
		),
		Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Venda Detalhe', 
		),
	];

	List<Widget> tabPages() {
		return [
			VendaCabecalhoEditPage(),
			const VendaDetalheListPage(),
		];
	}

	// list page
	late StreamSubscription _keyboardListener;
	get keyboardListener => _keyboardListener;
	set keyboardListener(value) => _keyboardListener = value;

	late PlutoGridStateManager _plutoGridStateManager;
	get plutoGridStateManager => _plutoGridStateManager;
	set plutoGridStateManager(value) => _plutoGridStateManager = value;

	final _plutoRow = PlutoRow(cells: {}).obs;
	get plutoRow => _plutoRow.value;
	set plutoRow(value) => _plutoRow.value = value;

	List<PlutoRow> plutoRows() {
		List<PlutoRow> plutoRowList = <PlutoRow>[];
		for (var vendaCabecalhoModel in _vendaCabecalhoModelList) {
			plutoRowList.add(_getPlutoRow(vendaCabecalhoModel));
		}
		return plutoRowList;
	}

	PlutoRow _getPlutoRow(VendaCabecalhoModel vendaCabecalhoModel) {
		return PlutoRow(
			cells: _getPlutoCells(vendaCabecalhoModel: vendaCabecalhoModel),
		);
	}

	Map<String, PlutoCell> _getPlutoCells({ VendaCabecalhoModel? vendaCabecalhoModel}) {
		return {
			"id": PlutoCell(value: vendaCabecalhoModel?.id ?? 0),
			"pessoa": PlutoCell(value: vendaCabecalhoModel?.pessoaModel?.nome ?? ''),
			"codigo": PlutoCell(value: vendaCabecalhoModel?.codigo ?? 0),
			"dataVenda": PlutoCell(value: vendaCabecalhoModel?.dataVenda ?? ''),
			"valorSubtotal": PlutoCell(value: vendaCabecalhoModel?.valorSubtotal ?? 0),
			"valorDesconto": PlutoCell(value: vendaCabecalhoModel?.valorDesconto ?? 0),
			"valorTotal": PlutoCell(value: vendaCabecalhoModel?.valorTotal ?? 0),
			"quantidadeParcelas": PlutoCell(value: vendaCabecalhoModel?.quantidadeParcelas ?? 0),
			"primeiroVencimento": PlutoCell(value: vendaCabecalhoModel?.primeiroVencimento ?? ''),
			"dataPrevistaEntrega": PlutoCell(value: vendaCabecalhoModel?.dataPrevistaEntrega ?? ''),
			"dataEntrega": PlutoCell(value: vendaCabecalhoModel?.dataEntrega ?? ''),
			"idPessoa": PlutoCell(value: vendaCabecalhoModel?.idPessoa ?? 0),
		};
	}

	void plutoRowToObject() {
		final modelFromRow = _vendaCabecalhoModelList.where( ((t) => t.id == plutoRow.cells['id']!.value) ).toList();
		if (modelFromRow.isEmpty) {
			vendaCabecalhoModel.plutoRowToObject(plutoRow);
		} else {
			vendaCabecalhoModel = modelFromRow[0];
			_vendaCabecalhoModelOld = vendaCabecalhoModel.clone();
		}		
	}

	Future callFilter() async {
		final filterController = Get.find<FilterController>();
		filterController.title = '${'filter_page_title'.tr} [Venda Cabecalho]';
		filterController.standardFilter = true;
		filterController.aliasColumns = aliasColumns;
		filterController.dbColumns = dbColumns;
		filterController.filter.field = 'Id';

		filter = await Get.toNamed(Routes.filterPage);
		await loadData();
	}

	Future loadData() async {
		_plutoGridStateManager.setShowLoading(true);
		_plutoGridStateManager.removeAllRows();
		await Get.find<VendaCabecalhoController>().getList(filter: filter);
		_plutoGridStateManager.appendRows(plutoRows());
		_plutoGridStateManager.setShowLoading(false);
	}

	Future getList({Filter? filter}) async {
		await vendaCabecalhoRepository.getList(filter: filter).then( (data){ _vendaCabecalhoModelList = data; } );
	}

	void printReport() {
		Get.dialog(AlertDialog(
			content: ReportPage(
				title: 'Venda Cabecalho',
				columns: gridColumns.map((column) => column.title).toList(),
				plutoRows: plutoRows(),
			),
		));
	}

	void callEditPage() {
		final currentRow = _plutoGridStateManager.currentRow;
		if (currentRow != null) {
			pessoaModelController.text = currentRow.cells['pessoa']?.value ?? '';
			codigoController.text = currentRow.cells['codigo']?.value?.toString() ?? '';
			valorSubtotalController.text = currentRow.cells['valorSubtotal']?.value?.toStringAsFixed(2) ?? '';
			valorDescontoController.text = currentRow.cells['valorDesconto']?.value?.toStringAsFixed(2) ?? '';
			valorTotalController.text = currentRow.cells['valorTotal']?.value?.toStringAsFixed(2) ?? '';
			quantidadeParcelasController.text = currentRow.cells['quantidadeParcelas']?.value?.toString() ?? '';
			plutoRow = currentRow;
			formWasChanged = false;
			plutoRowToObject();

			tabController.animateTo(0);
			
			//Venda Detalhe
			Get.put<VendaDetalheController>(VendaDetalheController()); 
			final vendaDetalheController = Get.find<VendaDetalheController>(); 
			vendaDetalheController.vendaDetalheModelList = vendaCabecalhoModel.vendaDetalheModelList!; 
			vendaDetalheController.userMadeChanges = false; 


			Get.toNamed(Routes.vendaCabecalhoTabPage)!.then((value) {
				if (vendaCabecalhoModel.id == 0) {
					_plutoGridStateManager.removeCurrentRow();
				}
			});
		} else {
			showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
		}
	}

	void callEditPageToInsert() {
		_plutoGridStateManager.prependNewRows(); 
		final cell = _plutoGridStateManager.rows.first.cells.entries.elementAt(0).value;
		_plutoGridStateManager.setCurrentCell(cell, 0); 
		_isInserting = true;
		vendaCabecalhoModel = VendaCabecalhoModel();
		callEditPage();	 
	}

	void handleKeyboard(PlutoKeyManagerEvent event) {
		if (event.isKeyDownEvent && event.event.logicalKey.keyId == LogicalKeyboardKey.enter.keyId) {
			callEditPage();
		}
	} 

	Future delete() async {
		final currentRow = _plutoGridStateManager.currentRow;
		if (currentRow != null) {
			showDeleteDialog(() async {
				if (await vendaCabecalhoRepository.delete(id: currentRow.cells['id']!.value)) {
					_vendaCabecalhoModelList.removeWhere( ((t) => t.id == currentRow.cells['id']!.value) );
					_plutoGridStateManager.removeCurrentRow();
				} else {
					showErrorSnackBar(message: 'message_error_delete'.tr);
				}
			});
		} else {
			showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
		}
	}


	// edit page
	final scrollController = ScrollController();
	final pessoaModelController = TextEditingController();
	final codigoController = TextEditingController();
	final valorSubtotalController = MoneyMaskedTextController();
	final valorDescontoController = MoneyMaskedTextController();
	final valorTotalController = MoneyMaskedTextController();
	final quantidadeParcelasController = TextEditingController();

	final vendaCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();

	final vendaCabecalhoEditPageScaffoldKey = GlobalKey<ScaffoldState>();
	final vendaCabecalhoEditPageFormKey = GlobalKey<FormState>();

	final _formWasChanged = false.obs;
	get formWasChanged => _formWasChanged.value;
	set formWasChanged(value) => _formWasChanged.value = value; 

	void objectToPlutoRow() {
		plutoRow.cells['id']?.value = vendaCabecalhoModel.id;
		plutoRow.cells['idPessoa']?.value = vendaCabecalhoModel.idPessoa;
		plutoRow.cells['pessoa']?.value = vendaCabecalhoModel.pessoaModel?.nome;
		plutoRow.cells['codigo']?.value = vendaCabecalhoModel.codigo;
		plutoRow.cells['dataVenda']?.value = Util.formatDate(vendaCabecalhoModel.dataVenda);
		plutoRow.cells['valorSubtotal']?.value = vendaCabecalhoModel.valorSubtotal;
		plutoRow.cells['valorDesconto']?.value = vendaCabecalhoModel.valorDesconto;
		plutoRow.cells['valorTotal']?.value = vendaCabecalhoModel.valorTotal;
		plutoRow.cells['quantidadeParcelas']?.value = vendaCabecalhoModel.quantidadeParcelas;
		plutoRow.cells['primeiroVencimento']?.value = Util.formatDate(vendaCabecalhoModel.primeiroVencimento);
		plutoRow.cells['dataPrevistaEntrega']?.value = Util.formatDate(vendaCabecalhoModel.dataPrevistaEntrega);
		plutoRow.cells['dataEntrega']?.value = Util.formatDate(vendaCabecalhoModel.dataEntrega);
	}

	Future<void> save() async {
		if (validateForms()) {
			if (userMadeChanges()) {
				final result = await vendaCabecalhoRepository.save(vendaCabecalhoModel: vendaCabecalhoModel); 
				if (result != null) {
					vendaCabecalhoModel = result;
					if (_isInserting) {
						_vendaCabecalhoModelList.add(vendaCabecalhoModel);
						_isInserting = false;
					} else {
            _vendaCabecalhoModelList.removeWhere( ((t) => t.id == plutoRow.cells['id']!.value) );
            _vendaCabecalhoModelList.add(vendaCabecalhoModel);
          }
					objectToPlutoRow();
					Get.back();
				}
			} else {
				Get.back();
			}
		} 
	}

	void preventDataLoss() {
		if (userMadeChanges()) {
			showQuestionDialog('message_data_loss'.tr, () { 
				clearUserChanges();
				Get.back(); 
			});
		} else {
			clearUserChanges();
			Get.back(closeOverlays: true);
		}
	}	

	bool userMadeChanges() {
		return
		formWasChanged 
		|| 
		Get.find<VendaDetalheController>().userMadeChanges
		;
	}

	void clearUserChanges() {
		_vendaCabecalhoModelList.removeWhere( ((t) => t.id == plutoRow.cells['id']!.value) );
		_vendaCabecalhoModelList.add(_vendaCabecalhoModelOld);
	}

	void tabChange(int index) {
		validateForms();
	}

	bool validateForms() {
		final mandatoryMessage = ValidateFormField.validateMandatory(vendaCabecalhoModel.pessoaModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Cliente]'); 
			return false; 
		}
		return true;
	}

	Future callPessoaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(); 
		lookupController.title = '${'lookup_page_title'.tr} [Pessoa]'; 
		lookupController.route = '/pessoa/'; 
		lookupController.gridColumns = pessoaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PessoaModel.aliasColumns; 
		lookupController.dbColumns = PessoaModel.dbColumns; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			vendaCabecalhoModel.idPessoa = plutoRowResult.cells['id']!.value; 
			vendaCabecalhoModel.pessoaModel!.plutoRowToObject(plutoRowResult); 
			pessoaModelController.text = vendaCabecalhoModel.pessoaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


	// override
	@override
	void onInit() {
		bootstrapGridParameters(
			gutterSize: Constants.flutterBootstrapGutterSize,
		);
		tabController = TabController(vsync: this, length: tabItems.length);
		super.onInit();
	}

	@override
	void onClose() {
		keyboardListener.cancel();
		scrollController.dispose(); 
		tabController.dispose();
		pessoaModelController.dispose();
		codigoController.dispose();
		valorSubtotalController.dispose();
		valorDescontoController.dispose();
		valorTotalController.dispose();
		quantidadeParcelasController.dispose();
		super.onClose();
	}
}