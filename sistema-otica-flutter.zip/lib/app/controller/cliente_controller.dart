import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/data/model/model_imports.dart';

class ClienteController extends GetxController {
	// general
	final _dbColumns = ClienteModel.dbColumns;
	get dbColumns => _dbColumns;

	final _aliasColumns = ClienteModel.aliasColumns;
	get aliasColumns => _aliasColumns;

	final _clienteModel = ClienteModel().obs;
	ClienteModel get clienteModel => _clienteModel.value;
	set clienteModel(value) => _clienteModel.value = value ?? ClienteModel();

	// edit page
	final scrollController = ScrollController();
	final taxaDescontoController = MoneyMaskedTextController();
	final limiteCreditoController = MoneyMaskedTextController();
	final ocupacaoController = TextEditingController();
	final observacaoController = TextEditingController();

	var scaffoldKey = GlobalKey<ScaffoldState>();
	var formKey = GlobalKey<FormState>();

	final _formWasChanged = false.obs;
	get formWasChanged => _formWasChanged.value;
	set formWasChanged(value) => _formWasChanged.value = value; 

	void callEditPage() {
		taxaDescontoController.text = clienteModel.taxaDesconto?.toStringAsFixed(2) ?? '';
		limiteCreditoController.text = clienteModel.limiteCredito?.toStringAsFixed(2) ?? '';
		ocupacaoController.text = clienteModel.ocupacao ?? '';
		observacaoController.text = clienteModel.observacao ?? '';
	}


	bool validateForm() {
		return true;
	}

	// override
	@override
	void onInit() {
		bootstrapGridParameters(
			gutterSize: Constants.flutterBootstrapGutterSize,
		);
		super.onInit();
	}

	@override
	void onClose() {
		scrollController.dispose(); 	
		taxaDescontoController.dispose();
		limiteCreditoController.dispose();
		ocupacaoController.dispose();
		observacaoController.dispose();
		super.onClose();
	}

}