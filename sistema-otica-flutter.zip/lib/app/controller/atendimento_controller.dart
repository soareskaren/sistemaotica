import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/data/model/model_imports.dart';
import 'package:otica/app/page/page_imports.dart';
import 'package:otica/app/page/grid_columns/grid_columns_imports.dart';
import 'package:otica/app/page/shared_widget/message_dialog.dart';

class AtendimentoController extends GetxController {

	// general
	final gridColumns = atendimentoGridColumns();
	
	var atendimentoModelList = <AtendimentoModel>[];

	final _atendimentoModel = AtendimentoModel().obs;
	AtendimentoModel get atendimentoModel => _atendimentoModel.value;
	set atendimentoModel(value) => _atendimentoModel.value = value ?? AtendimentoModel();
	
	// list page
	late StreamSubscription _keyboardListener;
	get keyboardListener => _keyboardListener;
	set keyboardListener(value) => _keyboardListener = value;

	late PlutoGridStateManager _plutoGridStateManager;
	get plutoGridStateManager => _plutoGridStateManager;
	set plutoGridStateManager(value) => _plutoGridStateManager = value;

	final _plutoRow = PlutoRow(cells: {}).obs;
	get plutoRow => _plutoRow.value;
	set plutoRow(value) => _plutoRow.value = value;

	List<PlutoRow> plutoRows() {
		List<PlutoRow> plutoRowList = <PlutoRow>[];
		for (var atendimentoModel in atendimentoModelList) {
			plutoRowList.add(_getPlutoRow(atendimentoModel));
		}
		return plutoRowList;
	}

	PlutoRow _getPlutoRow(AtendimentoModel atendimentoModel) {
		return PlutoRow(
			cells: _getPlutoCells(atendimentoModel: atendimentoModel),
		);
	}

	Map<String, PlutoCell> _getPlutoCells({ AtendimentoModel? atendimentoModel}) {
		return {
			"id": PlutoCell(value: atendimentoModel?.id ?? 0),
			"talao": PlutoCell(value: atendimentoModel?.talao ?? 0),
			"dataAtendimento": PlutoCell(value: atendimentoModel?.dataAtendimento ?? ''),
			"dataRetorno": PlutoCell(value: atendimentoModel?.dataRetorno ?? ''),
			"valorEsfericoOd": PlutoCell(value: atendimentoModel?.valorEsfericoOd ?? 0),
			"valorEsfericoOe": PlutoCell(value: atendimentoModel?.valorEsfericoOe ?? 0),
			"valorCilindricoOd": PlutoCell(value: atendimentoModel?.valorCilindricoOd ?? 0),
			"valorCilindricoOe": PlutoCell(value: atendimentoModel?.valorCilindricoOe ?? 0),
			"posicaoEixoOd": PlutoCell(value: atendimentoModel?.posicaoEixoOd ?? 0),
			"posicaoEixoOe": PlutoCell(value: atendimentoModel?.posicaoEixoOe ?? 0),
			"distanciaNasoPupilarOd": PlutoCell(value: atendimentoModel?.distanciaNasoPupilarOd ?? 0),
			"distanciaNasoPupilarOe": PlutoCell(value: atendimentoModel?.distanciaNasoPupilarOe ?? 0),
			"acuidadeVisualLongeOd": PlutoCell(value: atendimentoModel?.acuidadeVisualLongeOd ?? ''),
			"acuidadeVisualLongeOe": PlutoCell(value: atendimentoModel?.acuidadeVisualLongeOe ?? ''),
			"adicao": PlutoCell(value: atendimentoModel?.adicao ?? 0),
			"acuidadeVisualPertoOd": PlutoCell(value: atendimentoModel?.acuidadeVisualPertoOd ?? ''),
			"acuidadeVisualPertoOe": PlutoCell(value: atendimentoModel?.acuidadeVisualPertoOe ?? ''),
			"examinador": PlutoCell(value: atendimentoModel?.examinador ?? ''),
			"observacao": PlutoCell(value: atendimentoModel?.observacao ?? ''),
			"idPessoa": PlutoCell(value: atendimentoModel?.idPessoa ?? 0),
		};
	}

	void plutoRowToObject() {
		atendimentoModel.plutoRowToObject(plutoRow);
	}

	Future loadData() async {
		_plutoGridStateManager.setShowLoading(true);
		_plutoGridStateManager.removeAllRows();
		_plutoGridStateManager.appendRows(plutoRows());
		_plutoGridStateManager.setShowLoading(false);
	}

	Future getList({Filter? filter}) async {
		return atendimentoModelList;
	}

	void callEditPage() {
		final currentRow = _plutoGridStateManager.currentRow;
		if (currentRow != null) {
			talaoController.text = currentRow.cells['talao']?.value?.toString() ?? '';
			valorEsfericoOdController.text = currentRow.cells['valorEsfericoOd']?.value?.toStringAsFixed(2) ?? '';
			valorEsfericoOeController.text = currentRow.cells['valorEsfericoOe']?.value?.toStringAsFixed(2) ?? '';
			valorCilindricoOdController.text = currentRow.cells['valorCilindricoOd']?.value?.toStringAsFixed(2) ?? '';
			valorCilindricoOeController.text = currentRow.cells['valorCilindricoOe']?.value?.toStringAsFixed(2) ?? '';
			posicaoEixoOdController.text = currentRow.cells['posicaoEixoOd']?.value?.toString() ?? '';
			posicaoEixoOeController.text = currentRow.cells['posicaoEixoOe']?.value?.toString() ?? '';
			distanciaNasoPupilarOdController.text = currentRow.cells['distanciaNasoPupilarOd']?.value?.toStringAsFixed(2) ?? '';
			distanciaNasoPupilarOeController.text = currentRow.cells['distanciaNasoPupilarOe']?.value?.toStringAsFixed(2) ?? '';
			adicaoController.text = currentRow.cells['adicao']?.value?.toStringAsFixed(2) ?? '';
			examinadorController.text = currentRow.cells['examinador']?.value ?? '';
			observacaoController.text = currentRow.cells['observacao']?.value ?? '';
			plutoRow = currentRow;
			formWasChanged = false;
			plutoRowToObject();
			Get.to(() => AtendimentoEditPage());
		} else {
			showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
		}
	}

	void callEditPageToInsert() {
		_plutoGridStateManager.prependNewRows(); 
		final cell = _plutoGridStateManager.rows.first.cells.entries.elementAt(0).value;
		_plutoGridStateManager.setCurrentCell(cell, 0); 
		callEditPage();	 
	}

	void handleKeyboard(PlutoKeyManagerEvent event) {
		if (event.isKeyDownEvent && event.event.logicalKey.keyId == LogicalKeyboardKey.enter.keyId) {
			callEditPage();
		}
	} 

	Future delete() async {
		final currentRow = _plutoGridStateManager.currentRow;
		if (currentRow != null) {
			showDeleteDialog(() async {
				_plutoGridStateManager.removeCurrentRow();
				userMadeChanges = true;
				refreshList();
			});
		} else {
			showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
		}
	}

	// edit page
	final scrollController = ScrollController();
	final talaoController = TextEditingController();
	final valorEsfericoOdController = TextEditingController();
	final valorEsfericoOeController = TextEditingController();
	final valorCilindricoOdController = TextEditingController();
	final valorCilindricoOeController = TextEditingController();
	final posicaoEixoOdController = TextEditingController();
	final posicaoEixoOeController = TextEditingController();
	final distanciaNasoPupilarOdController = MoneyMaskedTextController();
	final distanciaNasoPupilarOeController = MoneyMaskedTextController();
	final adicaoController = TextEditingController();
	final examinadorController = TextEditingController();
	final observacaoController = TextEditingController();

	final scaffoldKey = GlobalKey<ScaffoldState>();
	final formKey = GlobalKey<FormState>();

	final _formWasChanged = false.obs;
	get formWasChanged => _formWasChanged.value;
	set formWasChanged(value) => _formWasChanged.value = value; 

	final _userMadeChanges = false.obs;
	get userMadeChanges => _userMadeChanges.value;
	set userMadeChanges(value) => _userMadeChanges.value = value; 

	void objectToPlutoRow() {
		plutoRow.cells['id']?.value = atendimentoModel.id;
		plutoRow.cells['idPessoa']?.value = atendimentoModel.idPessoa;
		plutoRow.cells['talao']?.value = atendimentoModel.talao;
		plutoRow.cells['dataAtendimento']?.value = Util.formatDate(atendimentoModel.dataAtendimento);
		plutoRow.cells['dataRetorno']?.value = Util.formatDate(atendimentoModel.dataRetorno);
		plutoRow.cells['valorEsfericoOd']?.value = atendimentoModel.valorEsfericoOd;
		plutoRow.cells['valorEsfericoOe']?.value = atendimentoModel.valorEsfericoOe;
		plutoRow.cells['valorCilindricoOd']?.value = atendimentoModel.valorCilindricoOd;
		plutoRow.cells['valorCilindricoOe']?.value = atendimentoModel.valorCilindricoOe;
		plutoRow.cells['posicaoEixoOd']?.value = atendimentoModel.posicaoEixoOd;
		plutoRow.cells['posicaoEixoOe']?.value = atendimentoModel.posicaoEixoOe;
		plutoRow.cells['distanciaNasoPupilarOd']?.value = atendimentoModel.distanciaNasoPupilarOd;
		plutoRow.cells['distanciaNasoPupilarOe']?.value = atendimentoModel.distanciaNasoPupilarOe;
		plutoRow.cells['acuidadeVisualLongeOd']?.value = atendimentoModel.acuidadeVisualLongeOd;
		plutoRow.cells['acuidadeVisualLongeOe']?.value = atendimentoModel.acuidadeVisualLongeOe;
		plutoRow.cells['adicao']?.value = atendimentoModel.adicao;
		plutoRow.cells['acuidadeVisualPertoOd']?.value = atendimentoModel.acuidadeVisualPertoOd;
		plutoRow.cells['acuidadeVisualPertoOe']?.value = atendimentoModel.acuidadeVisualPertoOe;
		plutoRow.cells['examinador']?.value = atendimentoModel.examinador;
		plutoRow.cells['observacao']?.value = atendimentoModel.observacao;
	}

	Future<void> save() async {
		final FormState form = formKey.currentState!;
		if (!form.validate()) {
			showErrorSnackBar(message: 'validator_form_message'.tr);
		} else {
			if (formWasChanged) {
				userMadeChanges = true;		 
				objectToPlutoRow();
				refreshList();
				Get.back();
			} else {
				Get.back();
			}
		}
	}

  void refreshList() {
		atendimentoModelList.clear();
		for (var plutoRow in _plutoGridStateManager.rows) {
			var model = AtendimentoModel();
			model.plutoRowToObject(plutoRow);
			atendimentoModelList.add(model);
		}
  }

	void preventDataLoss() {
		if (formWasChanged) {
			showQuestionDialog('message_data_loss'.tr, () => Get.back());
		} else {
			formWasChanged = false;
			Get.back(closeOverlays: true);
		}
	}	

  void printAvaliacao() {
    Get.dialog(const AlertDialog(
      content: ReportAvaliacaoOptometricaPage(
        title: 'Avaliação Optométrica',
      ),
    ));
  }

	// override
	@override
	void onInit() {
		bootstrapGridParameters(
			gutterSize: Constants.flutterBootstrapGutterSize,
		);
		keyboardListener = const Stream.empty().listen((event) { });
		super.onInit();
	}

	@override
	void onClose() {
		keyboardListener.cancel();
		scrollController.dispose();		 
		talaoController.dispose();
		valorEsfericoOdController.dispose();
		valorEsfericoOeController.dispose();
		valorCilindricoOdController.dispose();
		valorCilindricoOeController.dispose();
		posicaoEixoOdController.dispose();
		posicaoEixoOeController.dispose();
		distanciaNasoPupilarOdController.dispose();
		distanciaNasoPupilarOeController.dispose();
		adicaoController.dispose();
		examinadorController.dispose();
		observacaoController.dispose();
		super.onClose();
	}
}