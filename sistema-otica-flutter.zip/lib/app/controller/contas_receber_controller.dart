import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/controller/controller_imports.dart';
import 'package:otica/app/data/model/model_imports.dart';
import 'package:otica/app/page/grid_columns/grid_columns_imports.dart';

import 'package:otica/app/routes/app_routes.dart';
import 'package:otica/app/data/repository/contas_receber_repository.dart';
import 'package:otica/app/page/shared_page/shared_page_imports.dart';
import 'package:otica/app/page/shared_widget/message_dialog.dart';

class ContasReceberController extends GetxController {
  final ContasReceberRepository contasReceberRepository;
  ContasReceberController({required this.contasReceberRepository});

  // general
  final _dbColumns = ContasReceberModel.dbColumns;
  get dbColumns => _dbColumns;

  final _aliasColumns = ContasReceberModel.aliasColumns;
  get aliasColumns => _aliasColumns;

  final gridColumns = contasReceberGridColumns();
  
  var _contasReceberModelList = <ContasReceberModel>[];

  final _contasReceberModel = ContasReceberModel().obs;
  ContasReceberModel get contasReceberModel => _contasReceberModel.value;
  set contasReceberModel(value) => _contasReceberModel.value = value ?? ContasReceberModel();

  final _filter = Filter().obs;
  Filter get filter => _filter.value;
  set filter(value) => _filter.value = value ?? Filter(); 

  var _isInserting = false;

  // list page
  late StreamSubscription _keyboardListener;
  get keyboardListener => _keyboardListener;
  set keyboardListener(value) => _keyboardListener = value;

  late PlutoGridStateManager _plutoGridStateManager;
  get plutoGridStateManager => _plutoGridStateManager;
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final _plutoRow = PlutoRow(cells: {}).obs;
  get plutoRow => _plutoRow.value;
  set plutoRow(value) => _plutoRow.value = value;

  List<PlutoRow> plutoRows() {
    List<PlutoRow> plutoRowList = <PlutoRow>[];
    for (var contasReceberModel in _contasReceberModelList) {
      plutoRowList.add(_getPlutoRow(contasReceberModel));
    }
    return plutoRowList;
  }

  PlutoRow _getPlutoRow(ContasReceberModel contasReceberModel) {
    return PlutoRow(
      cells: _getPlutoCells(contasReceberModel: contasReceberModel),
    );
  }

  Map<String, PlutoCell> _getPlutoCells({ ContasReceberModel? contasReceberModel}) {
    return {
			"id": PlutoCell(value: contasReceberModel?.id ?? 0),
			"pessoa": PlutoCell(value: contasReceberModel?.pessoaModel?.nome ?? ''),
			"formaPagamento": PlutoCell(value: contasReceberModel?.formaPagamentoModel?.nome ?? ''),
			"vendaCabecalho": PlutoCell(value: contasReceberModel?.vendaCabecalhoModel?.codigo ?? ''),
			"bancoContaCaixa": PlutoCell(value: contasReceberModel?.bancoContaCaixaModel?.nome ?? ''),
			"dataLancamento": PlutoCell(value: contasReceberModel?.dataLancamento ?? ''),
			"valorTotal": PlutoCell(value: contasReceberModel?.valorTotal ?? 0),
			"numeroParcela": PlutoCell(value: contasReceberModel?.numeroParcela ?? 0),
			"valorParcela": PlutoCell(value: contasReceberModel?.valorParcela ?? 0),
			"dataVencimento": PlutoCell(value: contasReceberModel?.dataVencimento ?? ''),
			"dataRecebimento": PlutoCell(value: contasReceberModel?.dataRecebimento ?? ''),
			"valorRecebido": PlutoCell(value: contasReceberModel?.valorRecebido ?? 0),
			"observacao": PlutoCell(value: contasReceberModel?.observacao ?? ''),
			"idPessoa": PlutoCell(value: contasReceberModel?.idPessoa ?? 0),
			"idFormaPagamento": PlutoCell(value: contasReceberModel?.idFormaPagamento ?? 0),
			"idVendaCabecalho": PlutoCell(value: contasReceberModel?.idVendaCabecalho ?? 0),
			"idBancoContaCaixa": PlutoCell(value: contasReceberModel?.idBancoContaCaixa ?? 0),
    };
  }

  void plutoRowToObject() {
    final modelFromRow = _contasReceberModelList.where( ((t) => t.id == plutoRow.cells['id']!.value) ).toList();
    if (modelFromRow.isEmpty) {
      contasReceberModel.plutoRowToObject(plutoRow);
    } else {
      contasReceberModel = modelFromRow[0];
    }
  }

  Future callFilter() async {
    final filterController = Get.find<FilterController>();
    filterController.title = '${'filter_page_title'.tr} [Contas Receber]';
    filterController.standardFilter = true;
    filterController.aliasColumns = aliasColumns;
    filterController.dbColumns = dbColumns;
    filterController.filter.field = 'Data Lancamento';

    filter = await Get.toNamed(Routes.filterPage);
    await loadData();
  }

  Future loadData() async {
    _plutoGridStateManager.setShowLoading(true);
    _plutoGridStateManager.removeAllRows();
    await Get.find<ContasReceberController>().getList(filter: filter);
    _plutoGridStateManager.appendRows(plutoRows());
    _plutoGridStateManager.setShowLoading(false);
  }

  Future getList({Filter? filter}) async {
    await contasReceberRepository.getList(filter: filter).then( (data){ _contasReceberModelList = data; } );
  }

  void printReport() {
    Get.dialog(AlertDialog(
      content: ReportPage(
        title: 'Contas Receber',
        columns: gridColumns.map((column) => column.title).toList(),
        plutoRows: plutoRows(),
      ),
    ));
  }

  void callEditPage() {
    final currentRow = _plutoGridStateManager.currentRow;
    if (currentRow != null) {
			pessoaModelController.text = currentRow.cells['pessoa']?.value ?? '';
			formaPagamentoModelController.text = currentRow.cells['formaPagamento']?.value ?? '';
			vendaCabecalhoModelController.text = currentRow.cells['vendaCabecalho']?.value ?? '';
			bancoContaCaixaModelController.text = currentRow.cells['bancoContaCaixa']?.value ?? '';
			valorTotalController.text = currentRow.cells['valorTotal']?.value?.toStringAsFixed(2) ?? '';
			numeroParcelaController.text = currentRow.cells['numeroParcela']?.value?.toString() ?? '';
			valorParcelaController.text = currentRow.cells['valorParcela']?.value?.toStringAsFixed(2) ?? '';
			valorRecebidoController.text = currentRow.cells['valorRecebido']?.value?.toStringAsFixed(2) ?? '';
			observacaoController.text = currentRow.cells['observacao']?.value ?? '';

      plutoRow = currentRow;
      formWasChanged = false;
      plutoRowToObject();
      Get.toNamed(Routes.contasReceberEditPage)!.then((value) {
        if (contasReceberModel.id == 0) {
          _plutoGridStateManager.removeCurrentRow();
        }
      });
    } else {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
    }
  }

  void callEditPageToInsert() {
    _plutoGridStateManager.prependNewRows(); 
    final cell = _plutoGridStateManager.rows.first.cells.entries.elementAt(0).value;
    _plutoGridStateManager.setCurrentCell(cell, 0); 
    _isInserting = true;
    contasReceberModel = ContasReceberModel();
    callEditPage();   
  }

  void handleKeyboard(PlutoKeyManagerEvent event) {
    if (event.isKeyDownEvent && event.event.logicalKey.keyId == LogicalKeyboardKey.enter.keyId) {
      callEditPage();
    }
  } 

  Future delete() async {
    final currentRow = _plutoGridStateManager.currentRow;
    if (currentRow != null) {
      showDeleteDialog(() async {
        if (await contasReceberRepository.delete(id: currentRow.cells['id']!.value)) {
          _contasReceberModelList.removeWhere( ((t) => t.id == currentRow.cells['id']!.value) );
          _plutoGridStateManager.removeCurrentRow();
        } else {
          showErrorSnackBar(message: 'message_error_delete'.tr);
        }
      });
    } else {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
    }
  }


  // edit page
  final scrollController = ScrollController();
	final pessoaModelController = TextEditingController();
	final formaPagamentoModelController = TextEditingController();
	final vendaCabecalhoModelController = TextEditingController();
	final bancoContaCaixaModelController = TextEditingController();
	final valorTotalController = MoneyMaskedTextController();
	final numeroParcelaController = TextEditingController();
	final valorParcelaController = MoneyMaskedTextController();
	final valorRecebidoController = MoneyMaskedTextController();
	final observacaoController = TextEditingController();

  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();

  final _formWasChanged = false.obs;
  get formWasChanged => _formWasChanged.value;
  set formWasChanged(value) => _formWasChanged.value = value; 

  void objectToPlutoRow() {
		plutoRow.cells['id']?.value = contasReceberModel.id;
		plutoRow.cells['idPessoa']?.value = contasReceberModel.idPessoa;
		plutoRow.cells['pessoa']?.value = contasReceberModel.pessoaModel?.nome;
		plutoRow.cells['idFormaPagamento']?.value = contasReceberModel.idFormaPagamento;
		plutoRow.cells['formaPagamento']?.value = contasReceberModel.formaPagamentoModel?.nome;
		plutoRow.cells['idVendaCabecalho']?.value = contasReceberModel.idVendaCabecalho;
		plutoRow.cells['vendaCabecalho']?.value = contasReceberModel.vendaCabecalhoModel?.codigo;
		plutoRow.cells['idBancoContaCaixa']?.value = contasReceberModel.idBancoContaCaixa;
		plutoRow.cells['bancoContaCaixa']?.value = contasReceberModel.bancoContaCaixaModel?.nome;
		plutoRow.cells['dataLancamento']?.value = Util.formatDate(contasReceberModel.dataLancamento);
		plutoRow.cells['valorTotal']?.value = contasReceberModel.valorTotal;
		plutoRow.cells['numeroParcela']?.value = contasReceberModel.numeroParcela;
		plutoRow.cells['valorParcela']?.value = contasReceberModel.valorParcela;
		plutoRow.cells['dataVencimento']?.value = Util.formatDate(contasReceberModel.dataVencimento);
		plutoRow.cells['dataRecebimento']?.value = Util.formatDate(contasReceberModel.dataRecebimento);
		plutoRow.cells['valorRecebido']?.value = contasReceberModel.valorRecebido;
		plutoRow.cells['observacao']?.value = contasReceberModel.observacao;
  }

  Future<void> save() async {
    final FormState form = formKey.currentState!;
    if (!form.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
    } else {
      if (formWasChanged) {
        final result = await contasReceberRepository.save(contasReceberModel: contasReceberModel); 
        if (result != null) {
          contasReceberModel = result;
          if (_isInserting) {
            _contasReceberModelList.add(result);
            _isInserting = false;
          }
          objectToPlutoRow();
          Get.back();
        }
      } else {
        Get.back();
      }
    }
  }

  void preventDataLoss() {
    if (formWasChanged) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      Get.back(closeOverlays: true);
    }
  }  

	Future callPessoaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(); 
		lookupController.title = '${'lookup_page_title'.tr} [Pessoa]'; 
		lookupController.route = '/pessoa/'; 
		lookupController.gridColumns = pessoaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PessoaModel.aliasColumns; 
		lookupController.dbColumns = PessoaModel.dbColumns; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			contasReceberModel.idPessoa = plutoRowResult.cells['id']!.value; 
			contasReceberModel.pessoaModel!.plutoRowToObject(plutoRowResult); 
			pessoaModelController.text = contasReceberModel.pessoaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

	Future callFormaPagamentoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(); 
		lookupController.title = '${'lookup_page_title'.tr} [Forma Pagamento]'; 
		lookupController.route = '/forma-pagamento/'; 
		lookupController.gridColumns = formaPagamentoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FormaPagamentoModel.aliasColumns; 
		lookupController.dbColumns = FormaPagamentoModel.dbColumns; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			contasReceberModel.idFormaPagamento = plutoRowResult.cells['id']!.value; 
			contasReceberModel.formaPagamentoModel!.plutoRowToObject(plutoRowResult); 
			formaPagamentoModelController.text = contasReceberModel.formaPagamentoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

	Future callVendaCabecalhoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(); 
		lookupController.title = '${'lookup_page_title'.tr} [Venda Cabecalho]'; 
		lookupController.route = '/venda-cabecalho/'; 
		lookupController.gridColumns = vendaCabecalhoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = VendaCabecalhoModel.aliasColumns; 
		lookupController.dbColumns = VendaCabecalhoModel.dbColumns; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			contasReceberModel.idVendaCabecalho = plutoRowResult.cells['id']!.value; 
			contasReceberModel.vendaCabecalhoModel!.plutoRowToObject(plutoRowResult); 
			vendaCabecalhoModelController.text = contasReceberModel.vendaCabecalhoModel?.codigo?.toString() ?? ''; 
			formWasChanged = true; 
		}
	}

	Future callBancoContaCaixaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(); 
		lookupController.title = '${'lookup_page_title'.tr} [Banco Conta Caixa]'; 
		lookupController.route = '/banco-conta-caixa/'; 
		lookupController.gridColumns = bancoContaCaixaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = BancoContaCaixaModel.aliasColumns; 
		lookupController.dbColumns = BancoContaCaixaModel.dbColumns; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			contasReceberModel.idBancoContaCaixa = plutoRowResult.cells['id']!.value; 
			contasReceberModel.bancoContaCaixaModel!.plutoRowToObject(plutoRowResult); 
			bancoContaCaixaModelController.text = contasReceberModel.bancoContaCaixaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  // override
  @override
  void onInit() {
    bootstrapGridParameters(
      gutterSize: Constants.flutterBootstrapGutterSize,
    );
    super.onInit();
  }

  @override
  void onClose() {
		pessoaModelController.dispose();
		formaPagamentoModelController.dispose();
		vendaCabecalhoModelController.dispose();
		bancoContaCaixaModelController.dispose();
		valorTotalController.dispose();
		numeroParcelaController.dispose();
		valorParcelaController.dispose();
		valorRecebidoController.dispose();
		observacaoController.dispose();
    keyboardListener.cancel();
    scrollController.dispose(); 
    super.onClose();
  }
}