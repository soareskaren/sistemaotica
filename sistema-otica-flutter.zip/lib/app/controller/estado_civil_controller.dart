import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';

import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/controller/controller_imports.dart';
import 'package:otica/app/data/model/model_imports.dart';
import 'package:otica/app/page/grid_columns/grid_columns_imports.dart';

import 'package:otica/app/routes/app_routes.dart';
import 'package:otica/app/data/repository/estado_civil_repository.dart';
import 'package:otica/app/page/shared_page/shared_page_imports.dart';
import 'package:otica/app/page/shared_widget/message_dialog.dart';

class EstadoCivilController extends GetxController {
  final EstadoCivilRepository estadoCivilRepository;
  EstadoCivilController({required this.estadoCivilRepository});

  // general
  final _dbColumns = EstadoCivilModel.dbColumns;
  get dbColumns => _dbColumns;

  final _aliasColumns = EstadoCivilModel.aliasColumns;
  get aliasColumns => _aliasColumns;

  final gridColumns = estadoCivilGridColumns();
  
  var _estadoCivilModelList = <EstadoCivilModel>[];

  final _estadoCivilModel = EstadoCivilModel().obs;
  EstadoCivilModel get estadoCivilModel => _estadoCivilModel.value;
  set estadoCivilModel(value) => _estadoCivilModel.value = value ?? EstadoCivilModel();

  final _filter = Filter().obs;
  Filter get filter => _filter.value;
  set filter(value) => _filter.value = value ?? Filter(); 

  var _isInserting = false;

  // list page
  late StreamSubscription _keyboardListener;
  get keyboardListener => _keyboardListener;
  set keyboardListener(value) => _keyboardListener = value;

  late PlutoGridStateManager _plutoGridStateManager;
  get plutoGridStateManager => _plutoGridStateManager;
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final _plutoRow = PlutoRow(cells: {}).obs;
  get plutoRow => _plutoRow.value;
  set plutoRow(value) => _plutoRow.value = value;

  List<PlutoRow> plutoRows() {
    List<PlutoRow> plutoRowList = <PlutoRow>[];
    for (var estadoCivilModel in _estadoCivilModelList) {
      plutoRowList.add(_getPlutoRow(estadoCivilModel));
    }
    return plutoRowList;
  }

  PlutoRow _getPlutoRow(EstadoCivilModel estadoCivilModel) {
    return PlutoRow(
      cells: _getPlutoCells(estadoCivilModel: estadoCivilModel),
    );
  }

  Map<String, PlutoCell> _getPlutoCells({ EstadoCivilModel? estadoCivilModel}) {
    return {
			"id": PlutoCell(value: estadoCivilModel?.id ?? 0),
			"nome": PlutoCell(value: estadoCivilModel?.nome ?? ''),
			"descricao": PlutoCell(value: estadoCivilModel?.descricao ?? ''),
    };
  }

  void plutoRowToObject() {
    final modelFromRow = _estadoCivilModelList.where( ((t) => t.id == plutoRow.cells['id']!.value) ).toList();
    if (modelFromRow.isEmpty) {
      estadoCivilModel.plutoRowToObject(plutoRow);
    } else {
      estadoCivilModel = modelFromRow[0];
    }
  }

  Future callFilter() async {
    final filterController = Get.find<FilterController>();
    filterController.title = '${'filter_page_title'.tr} [Estado Civil]';
    filterController.standardFilter = true;
    filterController.aliasColumns = aliasColumns;
    filterController.dbColumns = dbColumns;
    filterController.filter.field = 'Nome';

    filter = await Get.toNamed(Routes.filterPage);
    await loadData();
  }

  Future loadData() async {
    _plutoGridStateManager.setShowLoading(true);
    _plutoGridStateManager.removeAllRows();
    await Get.find<EstadoCivilController>().getList(filter: filter);
    _plutoGridStateManager.appendRows(plutoRows());
    _plutoGridStateManager.setShowLoading(false);
  }

  Future getList({Filter? filter}) async {
    await estadoCivilRepository.getList(filter: filter).then( (data){ _estadoCivilModelList = data; } );
  }

  void printReport() {
    Get.dialog(AlertDialog(
      content: ReportPage(
        title: 'Estado Civil',
        columns: gridColumns.map((column) => column.title).toList(),
        plutoRows: plutoRows(),
      ),
    ));
  }

  void callEditPage() {
    final currentRow = _plutoGridStateManager.currentRow;
    if (currentRow != null) {
			nomeController.text = currentRow.cells['nome']?.value ?? '';
			descricaoController.text = currentRow.cells['descricao']?.value ?? '';

      plutoRow = currentRow;
      formWasChanged = false;
      plutoRowToObject();
      Get.toNamed(Routes.estadoCivilEditPage)!.then((value) {
        if (estadoCivilModel.id == 0) {
          _plutoGridStateManager.removeCurrentRow();
        }
      });
    } else {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
    }
  }

  void callEditPageToInsert() {
    _plutoGridStateManager.prependNewRows(); 
    final cell = _plutoGridStateManager.rows.first.cells.entries.elementAt(0).value;
    _plutoGridStateManager.setCurrentCell(cell, 0); 
    _isInserting = true;
    estadoCivilModel = EstadoCivilModel();
    callEditPage();   
  }

  void handleKeyboard(PlutoKeyManagerEvent event) {
    if (event.isKeyDownEvent && event.event.logicalKey.keyId == LogicalKeyboardKey.enter.keyId) {
      callEditPage();
    }
  } 

  Future delete() async {
    final currentRow = _plutoGridStateManager.currentRow;
    if (currentRow != null) {
      showDeleteDialog(() async {
        if (await estadoCivilRepository.delete(id: currentRow.cells['id']!.value)) {
          _estadoCivilModelList.removeWhere( ((t) => t.id == currentRow.cells['id']!.value) );
          _plutoGridStateManager.removeCurrentRow();
        } else {
          showErrorSnackBar(message: 'message_error_delete'.tr);
        }
      });
    } else {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
    }
  }


  // edit page
  final scrollController = ScrollController();
	final nomeController = TextEditingController();
	final descricaoController = TextEditingController();

  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();

  final _formWasChanged = false.obs;
  get formWasChanged => _formWasChanged.value;
  set formWasChanged(value) => _formWasChanged.value = value; 

  void objectToPlutoRow() {
		plutoRow.cells['id']?.value = estadoCivilModel.id;
		plutoRow.cells['nome']?.value = estadoCivilModel.nome;
		plutoRow.cells['descricao']?.value = estadoCivilModel.descricao;
  }

  Future<void> save() async {
    final FormState form = formKey.currentState!;
    if (!form.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
    } else {
      if (formWasChanged) {
        final result = await estadoCivilRepository.save(estadoCivilModel: estadoCivilModel); 
        if (result != null) {
          estadoCivilModel = result;
          if (_isInserting) {
            _estadoCivilModelList.add(result);
            _isInserting = false;
          }
          objectToPlutoRow();
          Get.back();
        }
      } else {
        Get.back();
      }
    }
  }

  void preventDataLoss() {
    if (formWasChanged) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      Get.back(closeOverlays: true);
    }
  }  


  // override
  @override
  void onInit() {
    bootstrapGridParameters(
      gutterSize: Constants.flutterBootstrapGutterSize,
    );
    super.onInit();
  }

  @override
  void onClose() {
		nomeController.dispose();
		descricaoController.dispose();
    keyboardListener.cancel();
    scrollController.dispose(); 
    super.onClose();
  }
}