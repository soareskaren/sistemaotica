import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/controller/controller_imports.dart';
import 'package:otica/app/data/model/model_imports.dart';
import 'package:otica/app/page/grid_columns/grid_columns_imports.dart';

import 'package:otica/app/routes/app_routes.dart';
import 'package:otica/app/data/repository/contas_pagar_repository.dart';
import 'package:otica/app/page/shared_page/shared_page_imports.dart';
import 'package:otica/app/page/shared_widget/message_dialog.dart';

class ContasPagarController extends GetxController {
  final ContasPagarRepository contasPagarRepository;
  ContasPagarController({required this.contasPagarRepository});

  // general
  final _dbColumns = ContasPagarModel.dbColumns;
  get dbColumns => _dbColumns;

  final _aliasColumns = ContasPagarModel.aliasColumns;
  get aliasColumns => _aliasColumns;

  final gridColumns = contasPagarGridColumns();
  
  var _contasPagarModelList = <ContasPagarModel>[];

  final _contasPagarModel = ContasPagarModel().obs;
  ContasPagarModel get contasPagarModel => _contasPagarModel.value;
  set contasPagarModel(value) => _contasPagarModel.value = value ?? ContasPagarModel();

  final _filter = Filter().obs;
  Filter get filter => _filter.value;
  set filter(value) => _filter.value = value ?? Filter(); 

  var _isInserting = false;

  // list page
  late StreamSubscription _keyboardListener;
  get keyboardListener => _keyboardListener;
  set keyboardListener(value) => _keyboardListener = value;

  late PlutoGridStateManager _plutoGridStateManager;
  get plutoGridStateManager => _plutoGridStateManager;
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final _plutoRow = PlutoRow(cells: {}).obs;
  get plutoRow => _plutoRow.value;
  set plutoRow(value) => _plutoRow.value = value;

  List<PlutoRow> plutoRows() {
    List<PlutoRow> plutoRowList = <PlutoRow>[];
    for (var contasPagarModel in _contasPagarModelList) {
      plutoRowList.add(_getPlutoRow(contasPagarModel));
    }
    return plutoRowList;
  }

  PlutoRow _getPlutoRow(ContasPagarModel contasPagarModel) {
    return PlutoRow(
      cells: _getPlutoCells(contasPagarModel: contasPagarModel),
    );
  }

  Map<String, PlutoCell> _getPlutoCells({ ContasPagarModel? contasPagarModel}) {
    return {
			"id": PlutoCell(value: contasPagarModel?.id ?? 0),
			"pessoa": PlutoCell(value: contasPagarModel?.pessoaModel?.nome ?? ''),
			"formaPagamento": PlutoCell(value: contasPagarModel?.formaPagamentoModel?.nome ?? ''),
			"bancoContaCaixa": PlutoCell(value: contasPagarModel?.bancoContaCaixaModel?.nome ?? ''),
			"dataLancamento": PlutoCell(value: contasPagarModel?.dataLancamento ?? ''),
			"valorTotal": PlutoCell(value: contasPagarModel?.valorTotal ?? 0),
			"numeroParcela": PlutoCell(value: contasPagarModel?.numeroParcela ?? 0),
			"valorParcela": PlutoCell(value: contasPagarModel?.valorParcela ?? 0),
			"dataVencimento": PlutoCell(value: contasPagarModel?.dataVencimento ?? ''),
			"dataRecebimento": PlutoCell(value: contasPagarModel?.dataRecebimento ?? ''),
			"valorRecebido": PlutoCell(value: contasPagarModel?.valorRecebido ?? 0),
			"observacao": PlutoCell(value: contasPagarModel?.observacao ?? ''),
			"idPessoa": PlutoCell(value: contasPagarModel?.idPessoa ?? 0),
			"idFormaPagamento": PlutoCell(value: contasPagarModel?.idFormaPagamento ?? 0),
			"idBancoContaCaixa": PlutoCell(value: contasPagarModel?.idBancoContaCaixa ?? 0),
    };
  }

  void plutoRowToObject() {
    final modelFromRow = _contasPagarModelList.where( ((t) => t.id == plutoRow.cells['id']!.value) ).toList();
    if (modelFromRow.isEmpty) {
      contasPagarModel.plutoRowToObject(plutoRow);
    } else {
      contasPagarModel = modelFromRow[0];
    }
  }

  Future callFilter() async {
    final filterController = Get.find<FilterController>();
    filterController.title = '${'filter_page_title'.tr} [Contas Pagar]';
    filterController.standardFilter = true;
    filterController.aliasColumns = aliasColumns;
    filterController.dbColumns = dbColumns;
    filterController.filter.field = 'Data Lancamento';

    filter = await Get.toNamed(Routes.filterPage);
    await loadData();
  }

  Future loadData() async {
    _plutoGridStateManager.setShowLoading(true);
    _plutoGridStateManager.removeAllRows();
    await Get.find<ContasPagarController>().getList(filter: filter);
    _plutoGridStateManager.appendRows(plutoRows());
    _plutoGridStateManager.setShowLoading(false);
  }

  Future getList({Filter? filter}) async {
    await contasPagarRepository.getList(filter: filter).then( (data){ _contasPagarModelList = data; } );
  }

  void printReport() {
    Get.dialog(AlertDialog(
      content: ReportPage(
        title: 'Contas Pagar',
        columns: gridColumns.map((column) => column.title).toList(),
        plutoRows: plutoRows(),
      ),
    ));
  }

  void callEditPage() {
    final currentRow = _plutoGridStateManager.currentRow;
    if (currentRow != null) {
			pessoaModelController.text = currentRow.cells['pessoa']?.value ?? '';
			formaPagamentoModelController.text = currentRow.cells['formaPagamento']?.value ?? '';
			bancoContaCaixaModelController.text = currentRow.cells['bancoContaCaixa']?.value ?? '';
			valorTotalController.text = currentRow.cells['valorTotal']?.value?.toStringAsFixed(2) ?? '';
			numeroParcelaController.text = currentRow.cells['numeroParcela']?.value?.toString() ?? '';
			valorParcelaController.text = currentRow.cells['valorParcela']?.value?.toStringAsFixed(2) ?? '';
			valorRecebidoController.text = currentRow.cells['valorRecebido']?.value?.toStringAsFixed(2) ?? '';
			observacaoController.text = currentRow.cells['observacao']?.value ?? '';

      plutoRow = currentRow;
      formWasChanged = false;
      plutoRowToObject();
      Get.toNamed(Routes.contasPagarEditPage)!.then((value) {
        if (contasPagarModel.id == 0) {
          _plutoGridStateManager.removeCurrentRow();
        }
      });
    } else {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
    }
  }

  void callEditPageToInsert() {
    _plutoGridStateManager.prependNewRows(); 
    final cell = _plutoGridStateManager.rows.first.cells.entries.elementAt(0).value;
    _plutoGridStateManager.setCurrentCell(cell, 0); 
    _isInserting = true;
    contasPagarModel = ContasPagarModel();
    callEditPage();   
  }

  void handleKeyboard(PlutoKeyManagerEvent event) {
    if (event.isKeyDownEvent && event.event.logicalKey.keyId == LogicalKeyboardKey.enter.keyId) {
      callEditPage();
    }
  } 

  Future delete() async {
    final currentRow = _plutoGridStateManager.currentRow;
    if (currentRow != null) {
      showDeleteDialog(() async {
        if (await contasPagarRepository.delete(id: currentRow.cells['id']!.value)) {
          _contasPagarModelList.removeWhere( ((t) => t.id == currentRow.cells['id']!.value) );
          _plutoGridStateManager.removeCurrentRow();
        } else {
          showErrorSnackBar(message: 'message_error_delete'.tr);
        }
      });
    } else {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
    }
  }


  // edit page
  final scrollController = ScrollController();
	final pessoaModelController = TextEditingController();
	final formaPagamentoModelController = TextEditingController();
	final bancoContaCaixaModelController = TextEditingController();
	final valorTotalController = MoneyMaskedTextController();
	final numeroParcelaController = TextEditingController();
	final valorParcelaController = MoneyMaskedTextController();
	final valorRecebidoController = MoneyMaskedTextController();
	final observacaoController = TextEditingController();

  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();

  final _formWasChanged = false.obs;
  get formWasChanged => _formWasChanged.value;
  set formWasChanged(value) => _formWasChanged.value = value; 

  void objectToPlutoRow() {
		plutoRow.cells['id']?.value = contasPagarModel.id;
		plutoRow.cells['idPessoa']?.value = contasPagarModel.idPessoa;
		plutoRow.cells['pessoa']?.value = contasPagarModel.pessoaModel?.nome;
		plutoRow.cells['idFormaPagamento']?.value = contasPagarModel.idFormaPagamento;
		plutoRow.cells['formaPagamento']?.value = contasPagarModel.formaPagamentoModel?.nome;
		plutoRow.cells['idBancoContaCaixa']?.value = contasPagarModel.idBancoContaCaixa;
		plutoRow.cells['bancoContaCaixa']?.value = contasPagarModel.bancoContaCaixaModel?.nome;
		plutoRow.cells['dataLancamento']?.value = Util.formatDate(contasPagarModel.dataLancamento);
		plutoRow.cells['valorTotal']?.value = contasPagarModel.valorTotal;
		plutoRow.cells['numeroParcela']?.value = contasPagarModel.numeroParcela;
		plutoRow.cells['valorParcela']?.value = contasPagarModel.valorParcela;
		plutoRow.cells['dataVencimento']?.value = Util.formatDate(contasPagarModel.dataVencimento);
		plutoRow.cells['dataRecebimento']?.value = Util.formatDate(contasPagarModel.dataRecebimento);
		plutoRow.cells['valorRecebido']?.value = contasPagarModel.valorRecebido;
		plutoRow.cells['observacao']?.value = contasPagarModel.observacao;
  }

  Future<void> save() async {
    final FormState form = formKey.currentState!;
    if (!form.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
    } else {
      if (formWasChanged) {
        final result = await contasPagarRepository.save(contasPagarModel: contasPagarModel); 
        if (result != null) {
          contasPagarModel = result;
          if (_isInserting) {
            _contasPagarModelList.add(result);
            _isInserting = false;
          }
          objectToPlutoRow();
          Get.back();
        }
      } else {
        Get.back();
      }
    }
  }

  void preventDataLoss() {
    if (formWasChanged) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      Get.back(closeOverlays: true);
    }
  }  

	Future callPessoaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(); 
		lookupController.title = '${'lookup_page_title'.tr} [Pessoa]'; 
		lookupController.route = '/pessoa/'; 
		lookupController.gridColumns = pessoaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PessoaModel.aliasColumns; 
		lookupController.dbColumns = PessoaModel.dbColumns; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			contasPagarModel.idPessoa = plutoRowResult.cells['id']!.value; 
			contasPagarModel.pessoaModel!.plutoRowToObject(plutoRowResult); 
			pessoaModelController.text = contasPagarModel.pessoaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

	Future callFormaPagamentoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(); 
		lookupController.title = '${'lookup_page_title'.tr} [Forma Pagamento]'; 
		lookupController.route = '/forma-pagamento/'; 
		lookupController.gridColumns = formaPagamentoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FormaPagamentoModel.aliasColumns; 
		lookupController.dbColumns = FormaPagamentoModel.dbColumns; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			contasPagarModel.idFormaPagamento = plutoRowResult.cells['id']!.value; 
			contasPagarModel.formaPagamentoModel!.plutoRowToObject(plutoRowResult); 
			formaPagamentoModelController.text = contasPagarModel.formaPagamentoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

	Future callBancoContaCaixaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(); 
		lookupController.title = '${'lookup_page_title'.tr} [Banco Conta Caixa]'; 
		lookupController.route = '/banco-conta-caixa/'; 
		lookupController.gridColumns = bancoContaCaixaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = BancoContaCaixaModel.aliasColumns; 
		lookupController.dbColumns = BancoContaCaixaModel.dbColumns; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			contasPagarModel.idBancoContaCaixa = plutoRowResult.cells['id']!.value; 
			contasPagarModel.bancoContaCaixaModel!.plutoRowToObject(plutoRowResult); 
			bancoContaCaixaModelController.text = contasPagarModel.bancoContaCaixaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  // override
  @override
  void onInit() {
    bootstrapGridParameters(
      gutterSize: Constants.flutterBootstrapGutterSize,
    );
    super.onInit();
  }

  @override
  void onClose() {
		pessoaModelController.dispose();
		formaPagamentoModelController.dispose();
		bancoContaCaixaModelController.dispose();
		valorTotalController.dispose();
		numeroParcelaController.dispose();
		valorParcelaController.dispose();
		valorRecebidoController.dispose();
		observacaoController.dispose();
    keyboardListener.cancel();
    scrollController.dispose(); 
    super.onClose();
  }
}