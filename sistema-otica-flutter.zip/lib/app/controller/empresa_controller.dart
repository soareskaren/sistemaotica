import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:otica/app/infra/infra_imports.dart';
import 'package:otica/app/controller/controller_imports.dart';
import 'package:otica/app/data/model/model_imports.dart';
import 'package:otica/app/page/grid_columns/grid_columns_imports.dart';

import 'package:otica/app/routes/app_routes.dart';
import 'package:otica/app/data/repository/empresa_repository.dart';
import 'package:otica/app/page/shared_page/shared_page_imports.dart';
import 'package:otica/app/page/shared_widget/message_dialog.dart';

class EmpresaController extends GetxController {
  final EmpresaRepository empresaRepository;
  EmpresaController({required this.empresaRepository});

  // general
  final _dbColumns = EmpresaModel.dbColumns;
  get dbColumns => _dbColumns;

  final _aliasColumns = EmpresaModel.aliasColumns;
  get aliasColumns => _aliasColumns;

  final gridColumns = empresaGridColumns();
  
  var _empresaModelList = <EmpresaModel>[];

  final _empresaModel = EmpresaModel().obs;
  EmpresaModel get empresaModel => _empresaModel.value;
  set empresaModel(value) => _empresaModel.value = value ?? EmpresaModel();

  final _filter = Filter().obs;
  Filter get filter => _filter.value;
  set filter(value) => _filter.value = value ?? Filter(); 

  var _isInserting = false;

  // list page
  late StreamSubscription _keyboardListener;
  get keyboardListener => _keyboardListener;
  set keyboardListener(value) => _keyboardListener = value;

  late PlutoGridStateManager _plutoGridStateManager;
  get plutoGridStateManager => _plutoGridStateManager;
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final _plutoRow = PlutoRow(cells: {}).obs;
  get plutoRow => _plutoRow.value;
  set plutoRow(value) => _plutoRow.value = value;

  List<PlutoRow> plutoRows() {
    List<PlutoRow> plutoRowList = <PlutoRow>[];
    for (var empresaModel in _empresaModelList) {
      plutoRowList.add(_getPlutoRow(empresaModel));
    }
    return plutoRowList;
  }

  PlutoRow _getPlutoRow(EmpresaModel empresaModel) {
    return PlutoRow(
      cells: _getPlutoCells(empresaModel: empresaModel),
    );
  }

  Map<String, PlutoCell> _getPlutoCells({ EmpresaModel? empresaModel}) {
    return {
			"id": PlutoCell(value: empresaModel?.id ?? 0),
			"razaoSocial": PlutoCell(value: empresaModel?.razaoSocial ?? ''),
			"nomeFantasia": PlutoCell(value: empresaModel?.nomeFantasia ?? ''),
			"cnpj": PlutoCell(value: empresaModel?.cnpj ?? ''),
			"inscricaoEstadual": PlutoCell(value: empresaModel?.inscricaoEstadual ?? ''),
			"inscricaoMunicipal": PlutoCell(value: empresaModel?.inscricaoMunicipal ?? ''),
			"tipoRegime": PlutoCell(value: empresaModel?.tipoRegime ?? ''),
			"crt": PlutoCell(value: empresaModel?.crt ?? ''),
			"email": PlutoCell(value: empresaModel?.email ?? ''),
			"site": PlutoCell(value: empresaModel?.site ?? ''),
			"contato": PlutoCell(value: empresaModel?.contato ?? ''),
			"dataConstituicao": PlutoCell(value: empresaModel?.dataConstituicao ?? ''),
			"codigoIbgeCidade": PlutoCell(value: empresaModel?.codigoIbgeCidade ?? 0),
			"codigoIbgeUf": PlutoCell(value: empresaModel?.codigoIbgeUf ?? 0),
			"cei": PlutoCell(value: empresaModel?.cei ?? ''),
			"codigoCnaePrincipal": PlutoCell(value: empresaModel?.codigoCnaePrincipal ?? ''),
			"imagemLogotipo": PlutoCell(value: empresaModel?.imagemLogotipo ?? ''),
    };
  }

  void plutoRowToObject() {
    final modelFromRow = _empresaModelList.where( ((t) => t.id == plutoRow.cells['id']!.value) ).toList();
    if (modelFromRow.isEmpty) {
      empresaModel.plutoRowToObject(plutoRow);
    } else {
      empresaModel = modelFromRow[0];
    }
  }

  Future callFilter() async {
    final filterController = Get.find<FilterController>();
    filterController.title = '${'filter_page_title'.tr} [Empresa]';
    filterController.standardFilter = true;
    filterController.aliasColumns = aliasColumns;
    filterController.dbColumns = dbColumns;
    filterController.filter.field = 'Nome Fantasia';

    filter = await Get.toNamed(Routes.filterPage);
    await loadData();
  }

  Future loadData() async {
    _plutoGridStateManager.setShowLoading(true);
    _plutoGridStateManager.removeAllRows();
    await Get.find<EmpresaController>().getList(filter: filter);
    _plutoGridStateManager.appendRows(plutoRows());
    _plutoGridStateManager.setShowLoading(false);
  }

  Future getList({Filter? filter}) async {
    await empresaRepository.getList(filter: filter).then( (data){ _empresaModelList = data; } );
  }

  void printReport() {
    Get.dialog(AlertDialog(
      content: ReportPage(
        title: 'Empresa',
        columns: gridColumns.map((column) => column.title).toList(),
        plutoRows: plutoRows(),
      ),
    ));
  }

  void callEditPage() {
    final currentRow = _plutoGridStateManager.currentRow;
    if (currentRow != null) {
			razaoSocialController.text = currentRow.cells['razaoSocial']?.value ?? '';
			nomeFantasiaController.text = currentRow.cells['nomeFantasia']?.value ?? '';
			cnpjController.text = currentRow.cells['cnpj']?.value ?? '';
			inscricaoEstadualController.text = currentRow.cells['inscricaoEstadual']?.value ?? '';
			inscricaoMunicipalController.text = currentRow.cells['inscricaoMunicipal']?.value ?? '';
			emailController.text = currentRow.cells['email']?.value ?? '';
			siteController.text = currentRow.cells['site']?.value ?? '';
			contatoController.text = currentRow.cells['contato']?.value ?? '';
			codigoIbgeCidadeController.text = currentRow.cells['codigoIbgeCidade']?.value?.toString() ?? '';
			codigoIbgeUfController.text = currentRow.cells['codigoIbgeUf']?.value?.toString() ?? '';
			ceiController.text = currentRow.cells['cei']?.value ?? '';
			codigoCnaePrincipalController.text = currentRow.cells['codigoCnaePrincipal']?.value ?? '';
			imagemLogotipoController.text = currentRow.cells['imagemLogotipo']?.value ?? '';

      plutoRow = currentRow;
      formWasChanged = false;
      plutoRowToObject();
      Get.toNamed(Routes.empresaEditPage)!.then((value) {
        if (empresaModel.id == 0) {
          _plutoGridStateManager.removeCurrentRow();
        }
      });
    } else {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
    }
  }

  void callEditPageToInsert() {
    _plutoGridStateManager.prependNewRows(); 
    final cell = _plutoGridStateManager.rows.first.cells.entries.elementAt(0).value;
    _plutoGridStateManager.setCurrentCell(cell, 0); 
    _isInserting = true;
    empresaModel = EmpresaModel();
    callEditPage();   
  }

  void handleKeyboard(PlutoKeyManagerEvent event) {
    if (event.isKeyDownEvent && event.event.logicalKey.keyId == LogicalKeyboardKey.enter.keyId) {
      callEditPage();
    }
  } 

  Future delete() async {
    final currentRow = _plutoGridStateManager.currentRow;
    if (currentRow != null) {
      showDeleteDialog(() async {
        if (await empresaRepository.delete(id: currentRow.cells['id']!.value)) {
          _empresaModelList.removeWhere( ((t) => t.id == currentRow.cells['id']!.value) );
          _plutoGridStateManager.removeCurrentRow();
        } else {
          showErrorSnackBar(message: 'message_error_delete'.tr);
        }
      });
    } else {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
    }
  }


  // edit page
  final scrollController = ScrollController();
	final razaoSocialController = TextEditingController();
	final nomeFantasiaController = TextEditingController();
	final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
	final inscricaoEstadualController = TextEditingController();
	final inscricaoMunicipalController = TextEditingController();
	final emailController = TextEditingController();
	final siteController = TextEditingController();
	final contatoController = TextEditingController();
	final codigoIbgeCidadeController = TextEditingController();
	final codigoIbgeUfController = TextEditingController();
	final ceiController = TextEditingController();
	final codigoCnaePrincipalController = TextEditingController();
	final imagemLogotipoController = TextEditingController();

  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();

  final _formWasChanged = false.obs;
  get formWasChanged => _formWasChanged.value;
  set formWasChanged(value) => _formWasChanged.value = value; 

  void objectToPlutoRow() {
		plutoRow.cells['id']?.value = empresaModel.id;
		plutoRow.cells['razaoSocial']?.value = empresaModel.razaoSocial;
		plutoRow.cells['nomeFantasia']?.value = empresaModel.nomeFantasia;
		plutoRow.cells['cnpj']?.value = empresaModel.cnpj;
		plutoRow.cells['inscricaoEstadual']?.value = empresaModel.inscricaoEstadual;
		plutoRow.cells['inscricaoMunicipal']?.value = empresaModel.inscricaoMunicipal;
		plutoRow.cells['tipoRegime']?.value = empresaModel.tipoRegime;
		plutoRow.cells['crt']?.value = empresaModel.crt;
		plutoRow.cells['email']?.value = empresaModel.email;
		plutoRow.cells['site']?.value = empresaModel.site;
		plutoRow.cells['contato']?.value = empresaModel.contato;
		plutoRow.cells['dataConstituicao']?.value = Util.formatDate(empresaModel.dataConstituicao);
		plutoRow.cells['codigoIbgeCidade']?.value = empresaModel.codigoIbgeCidade;
		plutoRow.cells['codigoIbgeUf']?.value = empresaModel.codigoIbgeUf;
		plutoRow.cells['cei']?.value = empresaModel.cei;
		plutoRow.cells['codigoCnaePrincipal']?.value = empresaModel.codigoCnaePrincipal;
		plutoRow.cells['imagemLogotipo']?.value = empresaModel.imagemLogotipo;
  }

  Future<void> save() async {
    final FormState form = formKey.currentState!;
    if (!form.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
    } else {
      if (formWasChanged) {
        final result = await empresaRepository.save(empresaModel: empresaModel); 
        if (result != null) {
          empresaModel = result;
          if (_isInserting) {
            _empresaModelList.add(result);
            _isInserting = false;
          }
          objectToPlutoRow();
          Get.back();
        }
      } else {
        Get.back();
      }
    }
  }

  void preventDataLoss() {
    if (formWasChanged) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      Get.back(closeOverlays: true);
    }
  }  


  // override
  @override
  void onInit() {
    bootstrapGridParameters(
      gutterSize: Constants.flutterBootstrapGutterSize,
    );
    super.onInit();
  }

  @override
  void onClose() {
		razaoSocialController.dispose();
		nomeFantasiaController.dispose();
		cnpjController.dispose();
		inscricaoEstadualController.dispose();
		inscricaoMunicipalController.dispose();
		emailController.dispose();
		siteController.dispose();
		contatoController.dispose();
		codigoIbgeCidadeController.dispose();
		codigoIbgeUfController.dispose();
		ceiController.dispose();
		codigoCnaePrincipalController.dispose();
		imagemLogotipoController.dispose();
    keyboardListener.cancel();
    scrollController.dispose(); 
    super.onClose();
  }
}