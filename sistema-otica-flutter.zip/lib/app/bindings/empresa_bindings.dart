import 'package:get/get.dart';
import 'package:otica/app/controller/empresa_controller.dart';
import 'package:otica/app/data/provider/api/empresa_api_provider.dart';
import 'package:otica/app/data/provider/drift/empresa_drift_provider.dart';
import 'package:otica/app/data/repository/empresa_repository.dart';

class EmpresaBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<EmpresaController>(() => EmpresaController(
					empresaRepository:
							EmpresaRepository(empresaApiProvider: EmpresaApiProvider(), empresaDriftProvider: EmpresaDriftProvider()))),
		];
	}
}
