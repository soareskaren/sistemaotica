import 'package:get/get.dart';
import 'package:otica/app/controller/forma_pagamento_controller.dart';
import 'package:otica/app/data/provider/api/forma_pagamento_api_provider.dart';
import 'package:otica/app/data/provider/drift/forma_pagamento_drift_provider.dart';
import 'package:otica/app/data/repository/forma_pagamento_repository.dart';

class FormaPagamentoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<FormaPagamentoController>(() => FormaPagamentoController(
					formaPagamentoRepository:
							FormaPagamentoRepository(formaPagamentoApiProvider: FormaPagamentoApiProvider(), formaPagamentoDriftProvider: FormaPagamentoDriftProvider()))),
		];
	}
}
