import 'package:get/get.dart';
import 'package:otica/app/controller/contas_pagar_controller.dart';
import 'package:otica/app/data/provider/api/contas_pagar_api_provider.dart';
import 'package:otica/app/data/provider/drift/contas_pagar_drift_provider.dart';
import 'package:otica/app/data/repository/contas_pagar_repository.dart';

class ContasPagarBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<ContasPagarController>(() => ContasPagarController(
					contasPagarRepository:
							ContasPagarRepository(contasPagarApiProvider: ContasPagarApiProvider(), contasPagarDriftProvider: ContasPagarDriftProvider()))),
		];
	}
}
