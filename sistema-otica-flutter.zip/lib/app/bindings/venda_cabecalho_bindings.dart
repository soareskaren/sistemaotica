import 'package:get/get.dart';
import 'package:otica/app/controller/venda_cabecalho_controller.dart';
import 'package:otica/app/data/provider/api/venda_cabecalho_api_provider.dart';
import 'package:otica/app/data/provider/drift/venda_cabecalho_drift_provider.dart';
import 'package:otica/app/data/repository/venda_cabecalho_repository.dart';

class VendaCabecalhoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<VendaCabecalhoController>(() => VendaCabecalhoController(
					vendaCabecalhoRepository:
							VendaCabecalhoRepository(vendaCabecalhoApiProvider: VendaCabecalhoApiProvider(), vendaCabecalhoDriftProvider: VendaCabecalhoDriftProvider()))),
		];
	}
}
