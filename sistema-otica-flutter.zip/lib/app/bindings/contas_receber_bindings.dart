import 'package:get/get.dart';
import 'package:otica/app/controller/contas_receber_controller.dart';
import 'package:otica/app/data/provider/api/contas_receber_api_provider.dart';
import 'package:otica/app/data/provider/drift/contas_receber_drift_provider.dart';
import 'package:otica/app/data/repository/contas_receber_repository.dart';

class ContasReceberBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<ContasReceberController>(() => ContasReceberController(
					contasReceberRepository:
							ContasReceberRepository(contasReceberApiProvider: ContasReceberApiProvider(), contasReceberDriftProvider: ContasReceberDriftProvider()))),
		];
	}
}
