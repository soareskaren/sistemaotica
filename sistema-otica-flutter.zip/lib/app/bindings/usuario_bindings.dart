import 'package:get/get.dart';
import 'package:otica/app/controller/usuario_controller.dart';
import 'package:otica/app/data/provider/api/usuario_api_provider.dart';
import 'package:otica/app/data/provider/drift/usuario_drift_provider.dart';
import 'package:otica/app/data/repository/usuario_repository.dart';

class UsuarioBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<UsuarioController>(() => UsuarioController(
					usuarioRepository:
							UsuarioRepository(usuarioApiProvider: UsuarioApiProvider(), usuarioDriftProvider: UsuarioDriftProvider()))),
		];
	}
}
