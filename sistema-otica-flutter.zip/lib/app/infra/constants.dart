
import 'package:encrypt/encrypt.dart';

class Constants {
	Constants._();

  static String chave = '#===1234__otica-romana4321___==='; 
  static Key key = Key.fromUtf8(chave);
  static IV iv = IV.fromUtf8('#abc-vector-1234');
  static Encrypter encrypter = Encrypter(AES(key, mode: AESMode.ctr, padding: null));

	static const String appName =	'Ótica Romana';
	static const String appVersion =	'version 1.0.1';
	
	static const double flutterBootstrapGutterSize = 10.0;
	static const int gridRowsPerPage = 10;

	static const String imageDir = 'assets/images';
	static const String dialogQuestionIcon = '$imageDir/dialog-question-icon.png';
	static const String dialogInfoIcon = '$imageDir/dialog-info-icon.png';
	static const String dialogErrorIcon = '$imageDir/dialog-error-icon.png';	
	static const String logotipo = '$imageDir/logotipo.png';
	static const String backgroundImage = '$imageDir/background.png';
	static const String loginImage = '$imageDir/login.jpg';
	static const String profileImage = '$imageDir/profile.png';

	// local database
	static const bool usingLocalDatabase = true;
	static const sqlGetSettings = "SELECT * FROM HIDDEN_SETTINGS WHERE ID=1";

	// server
	static String sentryDns = '';
	static String serverAddress = 'http://localhost';
	static String serverAddressComplement = '/otica';
	static String serverPort = '80';		
  
}

enum DialogType {
	info,
	warning,
	error,
	success,
	question,
	noHeader
}