import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:otica/app/infra/constants.dart';

class Util {
  Util._();

  /// remove mask from a string
  static String? removeMask(dynamic value) {
    if (value != null) {
      return value.replaceAll(RegExp(r'[^\w\s]+'), '');
    } else {
      return null;
    }
  }

  /// sets the distance between columns in case there is a line break
	static EdgeInsets? distanceBetweenColumnsLineBreak(BuildContext context) { 
    return bootStrapValueBasedOnSize(
      sizes: {
        "xl": EdgeInsets.zero,
        "lg": EdgeInsets.zero,
        "md": EdgeInsets.zero,
        "sm": EdgeInsets.zero,
        "": const EdgeInsets.only(top: 5.0, bottom: 10.0),
      },
      context: context,
    );
  }  

  static String formatDate(DateTime? date) {
    if (date == null) {
      return '';
    } else {
      var formatter = DateFormat('dd/MM/yyyy');
      String dataFormatada = formatter.format(date);
      return dataFormatada;
    }
  }
 
  static DateTime? stringToDate(String? date) {
    if (date == null || date == '') {
      return null;
    } else {
      var formatter = DateFormat('dd/MM/yyyy');
      return formatter.parseStrict(date);
    }
  }

  static String moneyFormat(dynamic value) {
    final formatter = NumberFormat.simpleCurrency(locale: Get.locale.toString());
    final result = formatter.format(value);
    return result;
  }

  static String decimalFormat(dynamic value) {
    final formatter = NumberFormat.decimalPattern(Get.locale.toString());
    final result = formatter.format(value);
    return result;
  }

  static String stringFormat(dynamic value) {
    return value ?? "";
  }

  static num stringToNumberWithLocale(String value) {
    final formatter = NumberFormat.simpleCurrency(locale: Get.locale.toString());
    value = value.isEmpty ? '0' : value;
    final result = formatter.parse(value);
    return result;    
  }

  static String crypt(String value) {
    return Constants.encrypter.encrypt(value, iv: Constants.iv).base64;
  }

  static String decrypt(String value) {
    return Constants.encrypter.decrypt64(value, iv: Constants.iv);
  }  

  static String toJsonString(List<dynamic> driftList) {	 
		String jsonString = "[";
		for (var i = 0; i < driftList.length; i++) {
			jsonString += "{";
			for (var j = 0; j < driftList[i].data.length; j++) {
				String fieldName = driftList[i].data.keys.toList()[j];
				final value = driftList[i].data.values.toList()[j];
				jsonString += '"${fieldName.camelCase}": "$value",';
			}		
			jsonString = jsonString.substring(0, jsonString.length - 1);
			jsonString += "},";
		}
		if (driftList.isNotEmpty) {
			jsonString = jsonString.substring(0, jsonString.length - 1);
		}
		jsonString += "]";
		return jsonString;
	}

  static String dataPorExtenso(DateTime? date) {
    date ??= DateTime.now();
    final dia = DateFormat("d").format(date);
    final mes = mesEmPortugues(DateFormat("MMMM").format(date));
    final ano = DateFormat("y").format(date);
    return "Fortaleza/CE, $dia de $mes de $ano";
  }

  static String mesEmPortugues(String mes) {
    switch (mes) {
      case 'January':
        return 'Janeiro';
      case 'February':
        return 'Fevereiro';
      case 'March':
        return 'Março';
      case 'April':
        return 'Abril';
      case 'May':
        return 'Maio';
      case 'June':
        return 'Junho';
      case 'July':
        return 'Julho';
      case 'August':
        return 'Agosto';
      case 'September':
        return 'Setembro';
      case 'October':
        return 'Outurbro';
      case 'November':
        return 'Novembro';
      case 'December':
        return 'Dezembro';
      default:
      return '';
    }
  }

  static int calcularIdade(DateTime? date) {
    if (date == null) {
      return 0;
    } else {
      return DateTime.now().year - date.year;
    }

  }
}